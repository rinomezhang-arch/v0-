-- SQLite Schema for 又见炊烟私房菜 宴会预定系统
-- 使用 IF NOT EXISTS 支持重复执行

CREATE TABLE IF NOT EXISTS dish_master (
    dish_id VARCHAR(20) NOT NULL,
    store_id INTEGER NOT NULL DEFAULT 1,
    dish_name VARCHAR(100) NOT NULL,
    dish_category VARCHAR(50),
    spicy_level INTEGER DEFAULT 0,
    main_ingredient_type VARCHAR(50),
    main_ingredient VARCHAR(100),
    english_name VARCHAR(200),
    cost_price REAL DEFAULT 0.00,
    sale_price REAL DEFAULT 0.00,
    cost_rate REAL DEFAULT 0.00,
    cooking_time INTEGER DEFAULT 15,
    birthday_name VARCHAR(100),
    wedding_name VARCHAR(100),
    house_move_name VARCHAR(100),
    promotion_name VARCHAR(100),
    reunion_name VARCHAR(100),
    thanksgiving_name VARCHAR(100),
    year_end_name VARCHAR(100),
    baby_born_name VARCHAR(100),
    is_active INTEGER DEFAULT 1,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (dish_id, store_id)
);

CREATE TABLE IF NOT EXISTS dish_occasion_names (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    dish_id VARCHAR(20) NOT NULL,
    occasion_type VARCHAR(20) NOT NULL,
    custom_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dish_recipe (
    recipe_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    dish_id VARCHAR(20) NOT NULL,
    ingredient_id VARCHAR(50) NOT NULL,
    ingredient_name VARCHAR(100),
    unit VARCHAR(20),
    unit_price REAL DEFAULT 0.0000,
    quantity REAL DEFAULT 0.000,
    total_cost REAL DEFAULT 0.00,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ingredient_master (
    ingredient_id VARCHAR(50) NOT NULL,
    store_id INTEGER NOT NULL DEFAULT 1,
    ingredient_name VARCHAR(100) NOT NULL,
    ingredient_category VARCHAR(50),
    brand VARCHAR(100),
    purchase_unit VARCHAR(20),
    usage_unit VARCHAR(20),
    conversion_rate REAL DEFAULT 1.000,
    primary_supplier_id INTEGER,
    current_stock REAL DEFAULT 0.000,
    warning_threshold REAL DEFAULT 0.000,
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ingredient_id, store_id)
);

CREATE TABLE IF NOT EXISTS ingredient_purchase (
    purchase_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    ingredient_id VARCHAR(50) NOT NULL,
    supplier_id INTEGER,
    purchase_date DATE,
    purchase_quantity REAL DEFAULT 0.000,
    purchase_price REAL DEFAULT 0.00,
    usage_quantity REAL DEFAULT 0.000,
    usage_price REAL DEFAULT 0.00,
    processing_note TEXT,
    operator_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ingredient_inventory_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    ingredient_id VARCHAR(50) NOT NULL,
    log_type VARCHAR(20) NOT NULL,
    log_quantity REAL DEFAULT 0.000,
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    related_order_id VARCHAR(50),
    operator_id INTEGER,
    note TEXT
);

CREATE TABLE IF NOT EXISTS package_master (
    package_id VARCHAR(20) NOT NULL,
    store_id INTEGER NOT NULL DEFAULT 1,
    package_name VARCHAR(100) NOT NULL,
    package_total_price REAL DEFAULT 0.00,
    package_cost_price REAL DEFAULT 0.00,
    cost_rate REAL DEFAULT 0.00,
    dish_count INTEGER DEFAULT 0,
    suggest_guests INTEGER DEFAULT 10,
    occasion_type VARCHAR(20),
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (package_id, store_id)
);

CREATE TABLE IF NOT EXISTS package_dish_detail (
    detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    package_id VARCHAR(20) NOT NULL,
    dish_id VARCHAR(20) NOT NULL,
    dish_quantity INTEGER DEFAULT 1,
    dish_order INTEGER DEFAULT 0,
    custom_name VARCHAR(100),
    note TEXT
);

CREATE TABLE IF NOT EXISTS customer_master (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    customer_name VARCHAR(50) NOT NULL,
    customer_phone VARCHAR(20),
    customer_preference TEXT,
    total_amount REAL DEFAULT 0.00,
    member_level VARCHAR(10) DEFAULT 'v1',
    booking_count INTEGER DEFAULT 0,
    last_booking_date DATE,
    remark TEXT,
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS staff_master (
    staff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    staff_name VARCHAR(20) NOT NULL,
    staff_account VARCHAR(20) UNIQUE,
    staff_password VARCHAR(100),
    staff_gender VARCHAR(2),
    staff_age INTEGER,
    staff_phone VARCHAR(20),
    staff_position VARCHAR(20),
    department VARCHAR(50),
    role VARCHAR(20) DEFAULT 'staff',
    employment_status VARCHAR(10) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS booking_master (
    booking_id VARCHAR(20) NOT NULL,
    store_id INTEGER NOT NULL DEFAULT 1,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    customer_id INTEGER,
    staff_id INTEGER,
    deposit REAL DEFAULT 0.00,
    guest_count INTEGER DEFAULT 0,
    table_count INTEGER DEFAULT 0,
    booking_status VARCHAR(20) DEFAULT 'confirmed',
    banquet_name VARCHAR(100),
    occasion_type VARCHAR(20),
    special_request TEXT,
    total_amount REAL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (booking_id, store_id)
);

CREATE TABLE IF NOT EXISTS booking_table (
    table_booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    booking_id VARCHAR(20) NOT NULL,
    table_id INTEGER,
    table_number VARCHAR(10),
    guest_count INTEGER DEFAULT 0,
    package_id VARCHAR(20),
    open_table_type VARCHAR(50),
    table_note TEXT
);

CREATE TABLE IF NOT EXISTS booking_dish_detail (
    dish_booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    table_booking_id INTEGER NOT NULL,
    dish_id VARCHAR(20),
    dish_quantity INTEGER DEFAULT 1,
    custom_name VARCHAR(100),
    dish_note TEXT
);

CREATE TABLE IF NOT EXISTS table_master (
    table_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    table_number VARCHAR(10) NOT NULL,
    table_name VARCHAR(20),
    table_location VARCHAR(50),
    table_area VARCHAR(20),
    table_capacity INTEGER DEFAULT 10,
    table_type VARCHAR(20),
    table_status VARCHAR(20) DEFAULT 'available',
    min_capacity INTEGER DEFAULT 6,
    max_capacity INTEGER DEFAULT 12,
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    remark TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS supplier_master (
    supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER NOT NULL DEFAULT 1,
    supplier_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(50),
    contact_phone VARCHAR(20),
    bank_account VARCHAR(50),
    platform_account VARCHAR(100),
    main_products TEXT,
    wechat_account VARCHAR(50),
    alipay_account VARCHAR(50),
    taobao_account VARCHAR(50),
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_dm_store ON dish_master(store_id);
CREATE INDEX IF NOT EXISTS idx_dm_active ON dish_master(is_active);
CREATE INDEX IF NOT EXISTS idx_bm_store ON booking_master(store_id);
CREATE INDEX IF NOT EXISTS idx_bm_date ON booking_master(booking_date);
CREATE INDEX IF NOT EXISTS idx_bm_status ON booking_master(booking_status);
CREATE INDEX IF NOT EXISTS idx_cm_phone ON customer_master(customer_phone);
CREATE INDEX IF NOT EXISTS idx_cm_store ON customer_master(store_id);
CREATE INDEX IF NOT EXISTS idx_sm_store ON staff_master(store_id);
CREATE INDEX IF NOT EXISTS idx_tm_store ON table_master(store_id);

-- 示例数据
INSERT OR IGNORE INTO staff_master (staff_id, store_id, staff_name, staff_account, staff_password, staff_phone, staff_position, role, employment_status)
VALUES (1, 1, '张婧', 'zhangjing', '$2a$10$UqrnREXBPrtL8VgtTMs05eyhGzDPIU1AiKvFEpUguCfsfC42buY2a', '15905638866', '经理', 'admin', 'active');

INSERT OR IGNORE INTO staff_master (staff_id, store_id, staff_name, staff_account, staff_password, staff_phone, staff_position, role, employment_status)
VALUES (2, 1, '李丽', 'lili', 'e10adc3949ba59abbe56e057f20f883e', '13856332211', '服务员', 'staff', 'active');

INSERT OR IGNORE INTO staff_master (staff_id, store_id, staff_name, staff_account, staff_password, staff_phone, staff_position, role, employment_status)
VALUES (3, 1, '王芳', 'wangfang', 'e10adc3949ba59abbe56e057f20f883e', '18656332299', '收银', 'staff', 'active');

-- 桌台数据 (宁国店13张)
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (1, 1, 'A01', 'A01', '大厅A区', 'A区', 8, '大厅', 1);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (2, 1, 'A02', 'A02', '大厅A区', 'A区', 8, '大厅', 2);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (3, 1, 'A03', 'A03', '大厅A区', 'A区', 6, '大厅', 3);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (4, 1, 'A05', 'A05', '大厅A区', 'A区', 10, '大厅', 4);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (5, 1, 'A06', 'A06', '大厅A区', 'A区', 10, '大厅', 5);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (6, 1, 'B01', 'B01', '大厅B区', 'B区', 6, '大厅', 6);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (7, 1, 'B02', 'B02', '大厅B区', 'B区', 6, '大厅', 7);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (8, 1, 'B03', 'B03', '大厅B区', 'B区', 8, '大厅', 8);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (9, 1, 'B05', 'B05', '大厅B区', 'B区', 8, '大厅', 9);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (10, 1, '包1', '包1', '包厢', '包厢', 10, '包厢', 10);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (11, 1, '包2', '包2', '包厢', '包厢', 12, '包厢', 11);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (12, 1, '包3', '包3', '包厢', '包厢', 12, '包厢', 12);
INSERT OR IGNORE INTO table_master (table_id, store_id, table_number, table_name, table_location, table_area, table_capacity, table_type, sort_order) VALUES (13, 1, '包5', '包5', '包厢', '包厢', 16, '包厢', 13);

-- 客户示例数据
INSERT OR IGNORE INTO customer_master (customer_id, store_id, customer_name, customer_phone, total_amount, member_level, booking_count)
VALUES (1, 1, '张三', '13800138001', 5680.00, 'v1', 5);
INSERT OR IGNORE INTO customer_master (customer_id, store_id, customer_name, customer_phone, total_amount, member_level, booking_count)
VALUES (2, 1, '李四', '13900139002', 3200.00, 'v1', 3);
INSERT OR IGNORE INTO customer_master (customer_id, store_id, customer_name, customer_phone, total_amount, member_level, booking_count)
VALUES (3, 1, '王五', '13700137003', 8800.00, 'v2', 8);

-- 测试预订
INSERT OR IGNORE INTO booking_master (booking_id, store_id, booking_date, booking_time, customer_id, staff_id, deposit, guest_count, table_count, booking_status, banquet_name)
VALUES ('BK20260627001', 1, '2026-06-27', '18:00', 1, 1, 500.00, 20, 2, 'confirmed', '生日宴');

INSERT OR IGNORE INTO booking_table (table_booking_id, store_id, booking_id, table_id, table_number, guest_count)
VALUES (1, 1, 'BK20260627001', 10, '包1', 10);

INSERT OR IGNORE INTO booking_table (table_booking_id, store_id, booking_id, table_id, table_number, guest_count)
VALUES (2, 1, 'BK20260627001', 11, '包2', 10);

INSERT OR IGNORE INTO booking_master (booking_id, store_id, booking_date, booking_time, customer_id, staff_id, deposit, guest_count, table_count, booking_status, banquet_name)
VALUES ('BK20260627002', 1, '2026-06-27', '18:30', 2, 1, 1000.00, 10, 1, 'confirmed', '家庭聚餐');

INSERT OR IGNORE INTO booking_table (table_booking_id, store_id, booking_id, table_id, table_number, guest_count)
VALUES (3, 1, 'BK20260627002', 1, 'A01', 10);

-- 菜品示例数据
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00001', 1, '红烧肉', '热菜', 18.50, 58.00, 31.90, 20, 1, 1);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00002', 1, '清蒸鲈鱼', '热菜', 22.00, 68.00, 32.35, 15, 1, 2);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00003', 1, '宫保鸡丁', '热菜', 12.00, 38.00, 31.58, 12, 1, 3);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00004', 1, '麻婆豆腐', '热菜', 5.00, 18.00, 27.78, 10, 1, 4);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00005', 1, '糖醋排骨', '热菜', 20.00, 62.00, 32.26, 20, 1, 5);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00006', 1, '凉拌黄瓜', '凉菜', 2.50, 12.00, 20.83, 5, 1, 6);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00007', 1, '口水鸡', '凉菜', 8.00, 28.00, 28.57, 10, 1, 7);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00008', 1, '酸菜鱼', '热菜', 15.00, 48.00, 31.25, 18, 1, 8);
INSERT OR IGNORE INTO dish_master (dish_id, store_id, dish_name, dish_category, cost_price, sale_price, cost_rate, cooking_time, is_active, sort_order)
VALUES ('CY00009', 1, '蒜蓉粉丝蒸扇贝', '海鲜', 25.00, 78.00, 32.05, 15, 1, 9);

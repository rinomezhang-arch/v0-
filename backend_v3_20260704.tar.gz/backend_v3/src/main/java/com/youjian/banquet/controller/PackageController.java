package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Package;
import com.youjian.banquet.repository.PackageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/packages")
public class PackageController {

    @Autowired
    private PackageRepository packageRepository;

    @GetMapping
    public Result<List<Package>> getPackages(
            @RequestParam(required = false) String occasionType) {
        Long storeId = StoreContext.get();
        List<Package> packages = packageRepository.findByStoreIdAndIsActive(storeId, 1);
        return Result.success(packages);
    }

    @GetMapping("/{id}")
    public Result<Package> getPackageDetail(@PathVariable String id) {
        return packageRepository.findById(id)
                .map(pkg -> Result.success(pkg))
                .orElseGet(() -> Result.error(404, "套餐不存在"));
    }
}

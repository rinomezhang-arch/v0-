package com.youjian.banquet.service;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.ChangeLog;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class ChangeLogService {

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(String operatorName, Integer operatorId, String operationType,
                    String targetType, String targetId, String summary,
                    String detail, String oldValue, String newValue) {
        // 直接使用 EntityManager 执行原生SQL
        String oid = operatorId != null ? operatorId.toString() : "0";
        String oname = operatorName != null ? operatorName.replace("'", "''") : "系统";
        String ot = operationType != null ? operationType.replace("'", "''") : "";
        String tt = targetType != null ? targetType.replace("'", "''") : "";
        String tid = targetId != null ? targetId.replace("'", "''") : "";
        String sum = summary != null ? summary.replace("'", "''") : "";
        String det = detail != null ? detail.replace("'", "''") : null;
        String ov = oldValue != null ? oldValue.replace("'", "''") : null;
        String nv = newValue != null ? newValue.replace("'", "''") : null;

        if (det != null && det.length() > 5000) det = det.substring(0, 5000);

        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO change_log (store_id, operator_id, operator_name, operation_type,");
        sql.append(" target_type, target_id, summary");
        if (det != null) sql.append(", detail");
        if (ov != null) sql.append(", old_value");
        if (nv != null) sql.append(", new_value");
        sql.append(", created_at) VALUES (1, ").append(oid);
        sql.append(", '").append(oname).append("'");
        sql.append(", '").append(ot).append("'");
        sql.append(", '").append(tt).append("'");
        sql.append(", '").append(tid).append("'");
        sql.append(", '").append(sum).append("'");
        if (det != null) sql.append(", '").append(det).append("'");
        if (ov != null) sql.append(", '").append(ov).append("'");
        if (nv != null) sql.append(", '").append(nv).append("'");
        sql.append(", NOW())");

        entityManager.createNativeQuery(sql.toString()).executeUpdate();
    }

    public void logCreate(String operatorName, Integer operatorId,
                          String targetType, String targetId, String summary) {
        log(operatorName, operatorId, "create", targetType, targetId, summary, null, null, null);
    }

    public void logUpdate(String operatorName, Integer operatorId,
                          String targetType, String targetId, String summary,
                          String oldValue, String newValue) {
        log(operatorName, operatorId, "update", targetType, targetId, summary, null, oldValue, newValue);
    }

    public void logDelete(String operatorName, Integer operatorId,
                          String targetType, String targetId, String summary) {
        log(operatorName, operatorId, "delete", targetType, targetId, summary, null, null, null);
    }

    public void logLogin(String operatorName, Integer operatorId) {
        log(operatorName, operatorId, "login", "staff",
                operatorId != null ? operatorId.toString() : "0",
                operatorName + " 登录系统", null, null, null);
    }

    public Result<List<ChangeLog>> list(int page, int pageSize,
                                        String operationType, String targetType, String keyword) {
        StringBuilder where = new StringBuilder(" WHERE 1=1");
        if (operationType != null && !operationType.isEmpty()) {
            where.append(" AND operation_type = '").append(operationType.replace("'", "''")).append("'");
        }
        if (targetType != null && !targetType.isEmpty()) {
            where.append(" AND target_type = '").append(targetType.replace("'", "''")).append("'");
        }
        if (keyword != null && !keyword.isEmpty()) {
            String kw = keyword.replace("'", "''");
            where.append(" AND (summary LIKE '%").append(kw).append("%'")
                 .append(" OR operator_name LIKE '%").append(kw).append("%'")
                 .append(" OR target_id LIKE '%").append(kw).append("%')");
        }

        long total = ((Number) entityManager.createNativeQuery(
                "SELECT COUNT(*) FROM change_log" + where).getSingleResult()).longValue();

        int offset = (page - 1) * pageSize;
        @SuppressWarnings("unchecked")
        List<Object[]> rows = entityManager.createNativeQuery(
                "SELECT log_id, store_id, operator_id, operator_name, operation_type, " +
                "target_type, target_id, summary, created_at " +
                "FROM change_log" + where +
                " ORDER BY created_at DESC LIMIT " + pageSize + " OFFSET " + offset
        ).getResultList();

        List<ChangeLog> list = new ArrayList<>();
        for (Object[] r : rows) {
            ChangeLog cl = new ChangeLog();
            cl.setLogId(toLong(r[0]));
            cl.setStoreId(r[1] != null ? ((Number) r[1]).intValue() : 1);
            cl.setOperatorId(r[2] != null ? ((Number) r[2]).intValue() : null);
            cl.setOperatorName((String) r[3]);
            cl.setOperationType((String) r[4]);
            cl.setTargetType((String) r[5]);
            cl.setTargetId((String) r[6]);
            cl.setSummary((String) r[7]);
            cl.setCreatedAt(r[8] != null ? ((java.sql.Timestamp) r[8]).toLocalDateTime() : null);
            list.add(cl);
        }

        Map<String, Object> extra = new HashMap<>();
        extra.put("total", total);
        extra.put("page", page);
        extra.put("pageSize", pageSize);
        return Result.success(list, extra);
    }

    public Result<ChangeLog> detail(Long id) {
        @SuppressWarnings("unchecked")
        List<Object[]> rows = entityManager.createNativeQuery(
                "SELECT * FROM change_log WHERE log_id = " + id
        ).getResultList();
        if (rows.isEmpty()) return Result.error(404, "日志不存在");

        Object[] r = rows.get(0);
        ChangeLog cl = new ChangeLog();
        cl.setLogId(toLong(r[0]));
        cl.setStoreId(r[1] != null ? ((Number) r[1]).intValue() : 1);
        cl.setOperatorId(r[2] != null ? ((Number) r[2]).intValue() : null);
        cl.setOperatorName((String) r[3]);
        cl.setOperationType((String) r[4]);
        cl.setTargetType((String) r[5]);
        cl.setTargetId((String) r[6]);
        cl.setSummary((String) r[7]);
        cl.setDetail((String) r[8]);
        cl.setOldValue((String) r[9]);
        cl.setNewValue((String) r[10]);
        cl.setIpAddress((String) r[11]);
        cl.setCreatedAt(r[12] != null ? ((java.sql.Timestamp) r[12]).toLocalDateTime() : null);
        return Result.success(cl);
    }

    private Long toLong(Object v) {
        return v != null ? ((Number) v).longValue() : null;
    }
}

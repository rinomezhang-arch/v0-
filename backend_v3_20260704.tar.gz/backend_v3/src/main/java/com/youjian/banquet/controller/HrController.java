package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.*;
import com.youjian.banquet.service.HrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hr")
public class HrController {

    @Autowired
    private HrService hrService;

    // ===== 部门管理 =====
    @GetMapping("/departments")
    public Result<List<Department>> listDepartments() {
        return hrService.listDepartments();
    }

    @GetMapping("/departments/{id}")
    public Result<Department> getDepartment(@PathVariable Integer id) {
        return hrService.getDepartment(id);
    }

    @PostMapping("/departments")
    public Result<Department> createDepartment(@RequestBody Department department) {
        return hrService.createDepartment(department);
    }

    @PutMapping("/departments/{id}")
    public Result<Department> updateDepartment(@PathVariable Integer id, @RequestBody Department department) {
        return hrService.updateDepartment(id, department);
    }

    @DeleteMapping("/departments/{id}")
    public Result<Void> deleteDepartment(@PathVariable Integer id) {
        return hrService.deleteDepartment(id);
    }

    // ===== 员工管理 =====
    @GetMapping("/staff")
    public Result<List<Map<String, Object>>> listStaffWithDept() {
        return hrService.listStaffWithDept();
    }

    @GetMapping("/staff/stats")
    public Result<Map<String, Object>> getStaffStats() {
        return Result.success(hrService.getStaffStats());
    }

    // ===== 考勤管理 =====
    @GetMapping("/attendance")
    public Result<List<Map<String, Object>>> listAttendance(
            @RequestParam(defaultValue = "") String startDate,
            @RequestParam(defaultValue = "") String endDate) {
        String today = java.time.LocalDate.now().toString();
        String start = startDate.isEmpty() ? today : startDate;
        String end = endDate.isEmpty() ? today : endDate;
        return hrService.listAttendance(start, end);
    }

    @PostMapping("/attendance")
    public Result<Attendance> createAttendance(@RequestBody Attendance attendance) {
        return hrService.createAttendance(attendance);
    }

    @PutMapping("/attendance/{id}")
    public Result<Attendance> updateAttendance(@PathVariable Integer id, @RequestBody Attendance attendance) {
        return hrService.updateAttendance(id, attendance);
    }

    // ===== 请假管理 =====
    @GetMapping("/leave")
    public Result<List<Map<String, Object>>> listLeave(@RequestParam(required = false) String status) {
        return hrService.listLeave(status);
    }

    @PostMapping("/leave")
    public Result<Leave> createLeave(@RequestBody Leave leave) {
        return hrService.createLeave(leave);
    }

    @PutMapping("/leave/{id}/approve")
    public Result<Leave> approveLeave(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> params) {
        Integer approverId = params.get("approverId") != null ? ((Number) params.get("approverId")).intValue() : null;
        String status = (String) params.get("status");
        String remark = (String) params.get("remark");
        return hrService.approveLeave(id, approverId, status, remark);
    }

    // ===== 加班管理 =====
    @GetMapping("/overtime")
    public Result<List<Map<String, Object>>> listOvertime(@RequestParam(required = false) String status) {
        return hrService.listOvertime(status);
    }

    @PostMapping("/overtime")
    public Result<Overtime> createOvertime(@RequestBody Overtime overtime) {
        return hrService.createOvertime(overtime);
    }

    @PutMapping("/overtime/{id}/approve")
    public Result<Overtime> approveOvertime(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> params) {
        Integer approverId = params.get("approverId") != null ? ((Number) params.get("approverId")).intValue() : null;
        String status = (String) params.get("status");
        String remark = (String) params.get("remark");
        return hrService.approveOvertime(id, approverId, status, remark);
    }

    // ===== 排班管理 =====
    @GetMapping("/schedule")
    public Result<List<Map<String, Object>>> listSchedule(@RequestParam(defaultValue = "") String date) {
        String today = java.time.LocalDate.now().toString();
        String d = date.isEmpty() ? today : date;
        return hrService.listSchedule(d);
    }

    @PostMapping("/schedule")
    public Result<Schedule> createSchedule(@RequestBody Schedule schedule) {
        return hrService.createSchedule(schedule);
    }

    @PostMapping("/schedule/batch")
    public Result<Void> batchCreateSchedule(@RequestBody List<Schedule> schedules) {
        return hrService.batchCreateSchedule(schedules);
    }

    @DeleteMapping("/schedule/{id}")
    public Result<Void> deleteSchedule(@PathVariable Integer id) {
        return hrService.deleteSchedule(id);
    }

    // ===== 报表中心 =====
    @GetMapping("/report")
    public Result<Map<String, Object>> getHrReport(
            @RequestParam(defaultValue = "") String startDate,
            @RequestParam(defaultValue = "") String endDate) {
        String today = java.time.LocalDate.now().toString();
        String start = startDate.isEmpty() ? today : startDate;
        String end = endDate.isEmpty() ? today : endDate;
        return Result.success(hrService.getHrReport(start, end));
    }

    // ===== 员工 CRUD（供前端 Staff.vue 调用） =====
    @PostMapping("/staff")
    public Result<Map<String, Object>> createStaff(@RequestBody Map<String, Object> params) {
        return hrService.createStaff(params);
    }

    @PutMapping("/staff/{id}")
    public Result<Map<String, Object>> updateStaff(@PathVariable Integer id, @RequestBody Map<String, Object> params) {
        return hrService.updateStaff(id, params);
    }

    @PutMapping("/staff/{id}/permissions")
    public Result<Map<String, Object>> updateStaffPermissions(@PathVariable Integer id, @RequestBody Map<String, Object> params) {
        return hrService.updateStaffPermissions(id, params);
    }

    @DeleteMapping("/staff/{id}")
    public Result<Void> deleteStaff(@PathVariable Integer id) {
        return hrService.deleteStaff(id);
    }
}
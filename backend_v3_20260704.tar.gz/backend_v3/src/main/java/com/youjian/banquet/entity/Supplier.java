package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "supplier_master")
public class Supplier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "supplier_id")
    private Integer supplierId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "supplier_code", length = 20)
    private String supplierCode;

    @Column(name = "supplier_name", length = 100, nullable = false)
    private String supplierName;

    @Column(name = "contact_person", length = 50)
    private String contactPerson;

    @Column(name = "contact_phone", length = 20)
    private String contactPhone;

    @Column(name = "bank_account", length = 50)
    private String bankAccount;

    @Column(name = "platform_account", length = 100)
    private String platformAccount;

    @Column(name = "main_products", columnDefinition = "TEXT")
    private String mainProducts;

    @Column(name = "wechat_account", length = 50)
    private String wechatAccount;

    @Column(name = "alipay_account", length = 50)
    private String alipayAccount;

    @Column(name = "taobao_account", length = 50)
    private String taobaoAccount;

    @Column(name = "supplier_rating")
    private Integer supplierRating = 5;

    @Column(name = "is_active")
    private Integer isActive = 1;

    @Column(name = "remark", columnDefinition = "TEXT")
    private String remark;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

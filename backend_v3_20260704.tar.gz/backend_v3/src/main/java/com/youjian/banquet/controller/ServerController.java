package com.youjian.banquet.controller;

import com.youjian.banquet.security.JwtUtil;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.*;
import java.io.*;

@RestController
@RequestMapping("/api/server")
@RequiredArgsConstructor
public class ServerController {

    private final JwtUtil jwtUtil;

    /**
     * 执行服务器命令（仅超管可用）
     */
    @PostMapping("/exec")
    public ResponseEntity<Map<String, Object>> exec(@RequestBody Map<String, Object> body, HttpServletRequest req) {
        String command = (String) body.get("command");
        
        Map<String, Object> response = new HashMap<>();
        
        // 验证权限
        int permLevel = 0;
        if (req.getCookies() != null) {
            for (var cookie : req.getCookies()) {
                if ("banquet_token".equals(cookie.getName())) {
                    try {
                        Claims claims = jwtUtil.getClaims(cookie.getValue());
                        if (jwtUtil.validateToken(cookie.getValue())) {
                            permLevel = claims.get("permissionLevel", Integer.class);
                        }
                    } catch (Exception e) {}
                    break;
                }
            }
        }
        
        if (permLevel < 99) {
            response.put("code", 403);
            response.put("data", "权限不足，仅超管可执行服务器命令");
            return ResponseEntity.ok(response);
        }
        
        if (command == null || command.trim().isEmpty()) {
            response.put("code", 400);
            response.put("data", "命令不能为空");
            return ResponseEntity.ok(response);
        }
        
        // 安全限制：禁止危险命令
        String lowerCmd = command.toLowerCase();
        if (lowerCmd.contains("rm -rf /") || lowerCmd.contains("mkfs") || lowerCmd.contains("dd if=")) {
            response.put("code", 400);
            response.put("data", "禁止执行危险命令");
            return ResponseEntity.ok(response);
        }
        
        try {
            ProcessBuilder pb = new ProcessBuilder("/bin/bash", "-c", command);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            int exitCode = process.waitFor();
            
            response.put("code", 200);
            response.put("data", Map.of(
                "output", output.toString(),
                "exitCode", exitCode
            ));
        } catch (Exception e) {
            response.put("code", 500);
            response.put("data", "命令执行失败：" + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 读取文件内容（仅超管可用）
     */
    @PostMapping("/read-file")
    public ResponseEntity<Map<String, Object>> readFile(@RequestBody Map<String, Object> body, HttpServletRequest req) {
        String path = (String) body.get("path");
        
        Map<String, Object> response = new HashMap<>();
        
        // 验证权限
        int permLevel = 0;
        if (req.getCookies() != null) {
            for (var cookie : req.getCookies()) {
                if ("banquet_token".equals(cookie.getName())) {
                    try {
                        Claims claims = jwtUtil.getClaims(cookie.getValue());
                        if (jwtUtil.validateToken(cookie.getValue())) {
                            permLevel = claims.get("permissionLevel", Integer.class);
                        }
                    } catch (Exception e) {}
                    break;
                }
            }
        }
        
        if (permLevel < 99) {
            response.put("code", 403);
            response.put("data", "权限不足，仅超管可读取文件");
            return ResponseEntity.ok(response);
        }
        
        if (path == null || path.trim().isEmpty()) {
            response.put("code", 400);
            response.put("data", "文件路径不能为空");
            return ResponseEntity.ok(response);
        }
        
        // 安全限制：只能读取特定目录
        if (!path.startsWith("/home/ubuntu/banquet-system/") && 
            !path.startsWith("/www/wwwroot/banquet/") &&
            !path.startsWith("/tmp/")) {
            response.put("code", 400);
            response.put("data", "只能读取项目相关目录的文件");
            return ResponseEntity.ok(response);
        }
        
        try {
            File file = new File(path);
            if (!file.exists()) {
                response.put("code", 404);
                response.put("data", "文件不存在");
                return ResponseEntity.ok(response);
            }
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            reader.close();
            
            response.put("code", 200);
            response.put("data", Map.of(
                "content", content.toString(),
                "path", path
            ));
        } catch (Exception e) {
            response.put("code", 500);
            response.put("data", "文件读取失败：" + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }

    /**
     * 列出目录内容（仅超管可用）
     */
    @PostMapping("/list-dir")
    public ResponseEntity<Map<String, Object>> listDir(@RequestBody Map<String, Object> body, HttpServletRequest req) {
        String path = (String) body.get("path");
        
        Map<String, Object> response = new HashMap<>();
        
        // 验证权限
        int permLevel = 0;
        if (req.getCookies() != null) {
            for (var cookie : req.getCookies()) {
                if ("banquet_token".equals(cookie.getName())) {
                    try {
                        Claims claims = jwtUtil.getClaims(cookie.getValue());
                        if (jwtUtil.validateToken(cookie.getValue())) {
                            permLevel = claims.get("permissionLevel", Integer.class);
                        }
                    } catch (Exception e) {}
                    break;
                }
            }
        }
        
        if (permLevel < 99) {
            response.put("code", 403);
            response.put("data", "权限不足，仅超管可列出目录");
            return ResponseEntity.ok(response);
        }
        
        if (path == null || path.trim().isEmpty()) {
            path = "/home/ubuntu/banquet-system/";
        }
        
        // 安全限制
        if (!path.startsWith("/home/ubuntu/banquet-system/") && 
            !path.startsWith("/www/wwwroot/banquet/") &&
            !path.startsWith("/tmp/")) {
            response.put("code", 400);
            response.put("data", "只能列出项目相关目录");
            return ResponseEntity.ok(response);
        }
        
        try {
            File dir = new File(path);
            if (!dir.exists() || !dir.isDirectory()) {
                response.put("code", 404);
                response.put("data", "目录不存在");
                return ResponseEntity.ok(response);
            }
            
            File[] files = dir.listFiles();
            List<Map<String, Object>> fileList = new ArrayList<>();
            
            if (files != null) {
                for (File f : files) {
                    fileList.add(Map.of(
                        "name", f.getName(),
                        "isDir", f.isDirectory(),
                        "size", f.length()
                    ));
                }
            }
            
            response.put("code", 200);
            response.put("data", Map.of(
                "path", path,
                "files", fileList
            ));
        } catch (Exception e) {
            response.put("code", 500);
            response.put("data", "目录列出失败：" + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }
}

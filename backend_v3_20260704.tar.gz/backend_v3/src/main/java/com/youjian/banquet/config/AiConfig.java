package com.youjian.banquet.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "ai")
public class AiConfig {
    private String apiKey = "sk-xxxxxxxxxxxxxxxxxxxxxxxx";
    private String baseUrl = "https://dashscope.aliyuncs.com";
    private int timeout = 60000;

    /** 默认对话模型 */
    private String chatModel = "qwen3.7-plus";

    /** 视觉模型（图片识别） */
    private String visionModel = "qwen3-vl-flash";

    /** 文案/创意生成模型 */
    private String creativeModel = "deepseek-v4-pro";

    /** 快速回答用的轻量模型 */
    private String lightweightModel = "qwen3.6-flash";
}

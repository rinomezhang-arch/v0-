package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {
    List<Attendance> findByStoreIdAndAttendanceDateBetween(Long storeId, LocalDate startDate, LocalDate endDate);
    List<Attendance> findByStoreIdAndStaffIdAndAttendanceDateBetween(Long storeId, Integer staffId, LocalDate startDate, LocalDate endDate);
    Optional<Attendance> findByStoreIdAndStaffIdAndAttendanceDate(Long storeId, Integer staffId, LocalDate attendanceDate);
    
    @Query("SELECT a FROM Attendance a WHERE a.storeId = :storeId AND a.attendanceDate BETWEEN :startDate AND :endDate AND a.status = 'late'")
    List<Attendance> findLateRecords(@Param("storeId") Long storeId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT a FROM Attendance a WHERE a.storeId = :storeId AND a.attendanceDate BETWEEN :startDate AND :endDate AND a.absent = true")
    List<Attendance> findAbsentRecords(@Param("storeId") Long storeId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT a.staffId, COUNT(a) FROM Attendance a WHERE a.storeId = :storeId AND a.attendanceDate BETWEEN :startDate AND :endDate GROUP BY a.staffId")
    List<Object[]> countAttendanceByStaff(@Param("storeId") Long storeId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
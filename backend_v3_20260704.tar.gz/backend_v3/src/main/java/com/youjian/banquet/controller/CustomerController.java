package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Booking;
import com.youjian.banquet.entity.BookingDishDetail;
import com.youjian.banquet.entity.Customer;
import com.youjian.banquet.repository.BookingDishDetailRepository;
import com.youjian.banquet.repository.BookingRepository;
import com.youjian.banquet.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingDishDetailRepository bookingDishDetailRepository;

    // 客户列表（分页+搜索）
    @GetMapping
    public Result<Map<String, Object>> listCustomers(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        Long storeId = StoreContext.get();
        List<Customer> all;
        if (keyword != null && !keyword.isEmpty()) {
            all = customerRepository.searchByNameOrPhone(storeId, keyword);
        } else {
            all = customerRepository.findAll();
        }
        int total = all.size();
        int from = (page - 1) * pageSize;
        int to = Math.min(from + pageSize, total);
        List<Customer> pageData = from < total ? all.subList(from, to) : List.of();
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("content", pageData);
        result.put("total", total);
        result.put("page", page);
        result.put("pageSize", pageSize);
        return Result.success(result);
    }

    // 新增客户
    @PostMapping
    public Result<Customer> addCustomer(@RequestBody Customer customer) {
        customer.setStoreId(StoreContext.get());
        return Result.success(customerRepository.save(customer));
    }

    // 编辑客户
    @PutMapping("/{id}")
    public Result<Customer> updateCustomer(@PathVariable Integer id, @RequestBody Customer customer) {
        Customer existing = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("客户不存在"));
        if (customer.getCustomerName() != null) existing.setCustomerName(customer.getCustomerName());
        if (customer.getCustomerPhone() != null) existing.setCustomerPhone(customer.getCustomerPhone());
        if (customer.getCustomerPreference() != null) existing.setCustomerPreference(customer.getCustomerPreference());
        if (customer.getMemberLevel() != null) existing.setMemberLevel(customer.getMemberLevel());
        if (customer.getRemark() != null) existing.setRemark(customer.getRemark());
        return Result.success(customerRepository.save(existing));
    }

    // 删除客户
    @DeleteMapping("/{id}")
    public Result<String> deleteCustomer(@PathVariable Integer id) {
        if (!customerRepository.existsById(id)) {
            return Result.error(404, "客户不存在");
        }
        customerRepository.deleteById(id);
        return Result.success("删除成功");
    }

    @GetMapping("/search")
    public Result<List<Customer>> searchCustomers(@RequestParam String q) {
        Long storeId = StoreContext.get();
        List<Customer> customers = customerRepository.searchByNameOrPhone(storeId, q);
        return Result.success(customers);
    }

    @GetMapping("/{id}/history")
    public Result<List<Map<String, Object>>> getCustomerHistory(@PathVariable Integer id) {
        Long storeId = StoreContext.get();
        List<Booking> bookings = bookingRepository.findByStoreIdAndCustomerId(storeId, id);
        List<Booking> sortedBookings = bookings.stream()
                .sorted((a, b) -> b.getBookingDate().compareTo(a.getBookingDate()))
                .collect(Collectors.toList());

        List<Map<String, Object>> result = new ArrayList<>();
        for (Booking booking : sortedBookings) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("booking_id", booking.getBookingId());
            item.put("booking_date", booking.getBookingDate());
            item.put("booking_time", booking.getBookingTime());
            item.put("table_count", booking.getTableCount());
            item.put("guest_count", booking.getGuestCount());
            item.put("booking_status", booking.getBookingStatus());
            item.put("banquet_name", booking.getBanquetName());
            item.put("occasion_type", booking.getOccasionType());
            item.put("total_amount", booking.getTotalAmount());
            item.put("deposit", booking.getDeposit());

            List<BookingDishDetail> dishes = bookingDishDetailRepository.findByStoreIdAndBookingId(storeId, booking.getBookingId());
            List<Map<String, Object>> dishList = new ArrayList<>();
            for (BookingDishDetail dish : dishes) {
                Map<String, Object> d = new LinkedHashMap<>();
                d.put("dish_id", dish.getDishId());
                d.put("dish_name", dish.getDishName());
                d.put("dish_quantity", dish.getDishQuantity());
                d.put("unit_price", dish.getUnitPrice());
                d.put("subtotal", dish.getSubtotal());
                d.put("custom_name", dish.getCustomName());
                d.put("dish_note", dish.getDishNote());
                dishList.add(d);
            }
            item.put("dishes", dishList);
            result.add(item);
        }

        return Result.success(result);
    }

    @GetMapping("/history")
    public Result<List<Map<String, Object>>> getCustomerHistoryByNamePhone(
            @RequestParam(required = false) String customerName,
            @RequestParam(required = false) String customerPhone) {
        Long storeId = StoreContext.get();
        List<Booking> bookings;

        if (customerName != null && !customerName.isEmpty() && customerPhone != null && !customerPhone.isEmpty()) {
            bookings = bookingRepository.findByStoreIdAndCustomerNameContainingAndCustomerPhoneContaining(storeId, customerName, customerPhone);
        } else if (customerName != null && !customerName.isEmpty()) {
            bookings = bookingRepository.findByStoreIdAndCustomerNameContaining(storeId, customerName);
        } else if (customerPhone != null && !customerPhone.isEmpty()) {
            bookings = bookingRepository.findByStoreIdAndCustomerPhoneContaining(storeId, customerPhone);
        } else {
            return Result.success(Collections.emptyList());
        }

        List<Booking> sortedBookings = bookings.stream()
                .sorted((a, b) -> b.getBookingDate().compareTo(a.getBookingDate()))
                .collect(Collectors.toList());

        List<Map<String, Object>> result = new ArrayList<>();
        for (Booking booking : sortedBookings) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("booking_id", booking.getBookingId());
            item.put("booking_date", booking.getBookingDate());
            item.put("booking_time", booking.getBookingTime());
            item.put("table_count", booking.getTableCount());
            item.put("guest_count", booking.getGuestCount());
            item.put("booking_status", booking.getBookingStatus());
            item.put("banquet_name", booking.getBanquetName());
            item.put("occasion_type", booking.getOccasionType());
            item.put("total_amount", booking.getTotalAmount());
            item.put("deposit", booking.getDeposit());

            List<BookingDishDetail> dishes = bookingDishDetailRepository.findByStoreIdAndBookingId(storeId, booking.getBookingId());
            List<Map<String, Object>> dishList = new ArrayList<>();
            for (BookingDishDetail dish : dishes) {
                Map<String, Object> d = new LinkedHashMap<>();
                d.put("dish_id", dish.getDishId());
                d.put("dish_name", dish.getDishName());
                d.put("dish_quantity", dish.getDishQuantity());
                d.put("unit_price", dish.getUnitPrice());
                d.put("subtotal", dish.getSubtotal());
                d.put("custom_name", dish.getCustomName());
                d.put("dish_note", dish.getDishNote());
                dishList.add(d);
            }
            item.put("dishes", dishList);
            result.add(item);
        }

        return Result.success(result);
    }
}

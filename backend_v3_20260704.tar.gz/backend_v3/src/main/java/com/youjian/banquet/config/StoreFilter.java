package com.youjian.banquet.config;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

@Component
public class StoreFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws java.io.IOException, jakarta.servlet.ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        String storeIdHeader = req.getHeader("X-Store-Id");
        try {
            if (storeIdHeader != null && !storeIdHeader.isEmpty()) {
                StoreContext.set(Long.parseLong(storeIdHeader));
            } else {
                StoreContext.set(1L);
            }
            chain.doFilter(request, response);
        } finally {
            StoreContext.clear();
        }
    }
}

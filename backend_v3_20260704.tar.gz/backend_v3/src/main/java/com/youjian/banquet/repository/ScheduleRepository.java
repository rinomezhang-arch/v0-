package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Integer> {
    List<Schedule> findByStoreIdAndScheduleDate(Long storeId, LocalDate scheduleDate);
    List<Schedule> findByStoreIdAndStaffId(Long storeId, Integer staffId);
    List<Schedule> findByStoreIdAndScheduleDateBetween(Long storeId, LocalDate startDate, LocalDate endDate);
    Optional<Schedule> findByStoreIdAndStaffIdAndScheduleDate(Long storeId, Integer staffId, LocalDate scheduleDate);
    List<Schedule> findByStoreId(Long storeId);
}
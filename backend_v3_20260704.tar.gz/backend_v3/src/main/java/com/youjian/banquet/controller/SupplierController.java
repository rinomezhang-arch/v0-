package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Supplier;
import com.youjian.banquet.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {

    @Autowired
    private SupplierRepository supplierRepository;

    @GetMapping
    public Result<List<Supplier>> getSuppliers(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<Supplier> suppliers = supplierRepository.findByStoreIdAndIsActive(storeId, 1);
        return Result.success(suppliers);
    }

    @GetMapping("/{id}")
    public Result<Supplier> getSupplier(@PathVariable Integer id) {
        return supplierRepository.findById(id)
                .map(Result::success)
                .orElseGet(() -> Result.error(404, "供应商不存在"));
    }

    @PostMapping
    public Result<Supplier> createSupplier(@RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();

        Supplier supplier = new Supplier();
        supplier.setStoreId(storeId);

        if (params.get("supplier_name") != null) {
            supplier.setSupplierName(params.get("supplier_name").toString());
        }
        if (params.get("contact_person") != null) {
            supplier.setContactPerson(params.get("contact_person").toString());
        }
        if (params.get("contact_phone") != null) {
            supplier.setContactPhone(params.get("contact_phone").toString());
        }
        if (params.get("bank_account") != null) {
            supplier.setBankAccount(params.get("bank_account").toString());
        }
        if (params.get("platform_account") != null) {
            supplier.setPlatformAccount(params.get("platform_account").toString());
        }
        if (params.get("main_products") != null) {
            supplier.setMainProducts(params.get("main_products").toString());
        }
        if (params.get("wechat_account") != null) {
            supplier.setWechatAccount(params.get("wechat_account").toString());
        }
        if (params.get("alipay_account") != null) {
            supplier.setAlipayAccount(params.get("alipay_account").toString());
        }
        if (params.get("taobao_account") != null) {
            supplier.setTaobaoAccount(params.get("taobao_account").toString());
        }

        supplier = supplierRepository.save(supplier);
        return Result.success(supplier);
    }

    @PutMapping("/{id}")
    public Result<Supplier> updateSupplier(@PathVariable Integer id, @RequestBody Map<String, Object> params) {
        Optional<Supplier> opt = supplierRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "供应商不存在");
        }

        Supplier supplier = opt.get();

        if (params.get("supplier_name") != null) {
            supplier.setSupplierName(params.get("supplier_name").toString());
        }
        if (params.get("contact_person") != null) {
            supplier.setContactPerson(params.get("contact_person").toString());
        }
        if (params.get("contact_phone") != null) {
            supplier.setContactPhone(params.get("contact_phone").toString());
        }
        if (params.get("bank_account") != null) {
            supplier.setBankAccount(params.get("bank_account").toString());
        }
        if (params.get("platform_account") != null) {
            supplier.setPlatformAccount(params.get("platform_account").toString());
        }
        if (params.get("main_products") != null) {
            supplier.setMainProducts(params.get("main_products").toString());
        }
        if (params.get("wechat_account") != null) {
            supplier.setWechatAccount(params.get("wechat_account").toString());
        }
        if (params.get("alipay_account") != null) {
            supplier.setAlipayAccount(params.get("alipay_account").toString());
        }
        if (params.get("taobao_account") != null) {
            supplier.setTaobaoAccount(params.get("taobao_account").toString());
        }

        supplier = supplierRepository.save(supplier);
        return Result.success(supplier);
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteSupplier(@PathVariable Integer id) {
        Optional<Supplier> opt = supplierRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "供应商不存在");
        }

        Supplier supplier = opt.get();
        supplier.setIsActive(0);
        supplierRepository.save(supplier);
        return Result.success("删除成功");
    }
}

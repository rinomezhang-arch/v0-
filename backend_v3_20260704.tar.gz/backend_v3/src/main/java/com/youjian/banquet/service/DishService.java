package com.youjian.banquet.service;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.DishMaster;
import com.youjian.banquet.entity.DishMaster.DishMasterId;
import com.youjian.banquet.repository.DishRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class DishService {

    @Autowired
    private DishRepository dishRepository;

    public Result<List<DishMaster>> getDishList(Long storeId, String usageType) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<DishMaster> dishes;
        if (usageType != null && !usageType.isEmpty()) {
            dishes = dishRepository.findByStoreIdAndIsActiveAndUsageType(storeId, 1, usageType);
        } else {
            dishes = dishRepository.findByStoreIdAndIsActive(storeId, 1);
        }
        return Result.success(dishes);
    }

    public Result<DishMaster> createDish(Map<String, Object> params) {
        Long storeId = StoreContext.get();
        String dishId = generateDishId(storeId);

        DishMaster dish = new DishMaster();
        dish.setDishId(dishId);
        dish.setStoreId(storeId);

        applyParams(dish, params);

        // Auto-calculate cost rate if both prices are provided
        if (dish.getCostPrice() != null && dish.getSalePrice() != null
                && dish.getSalePrice().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal rate = dish.getCostPrice()
                    .multiply(BigDecimal.valueOf(100))
                    .divide(dish.getSalePrice(), 2, BigDecimal.ROUND_HALF_UP);
            dish.setCostRate(rate);
        }

        dish = dishRepository.save(dish);
        return Result.success(dish);
    }

    public Result<DishMaster> updateDish(String dishId, Map<String, Object> params) {
        Long storeId = StoreContext.get();
        DishMasterId id = new DishMasterId();
        id.setDishId(dishId);
        id.setStoreId(storeId);

        Optional<DishMaster> opt = dishRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "菜品不存在");
        }

        DishMaster dish = opt.get();
        applyParams(dish, params);

        // Recalculate cost rate
        if (dish.getCostPrice() != null && dish.getSalePrice() != null
                && dish.getSalePrice().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal rate = dish.getCostPrice()
                    .multiply(BigDecimal.valueOf(100))
                    .divide(dish.getSalePrice(), 2, BigDecimal.ROUND_HALF_UP);
            dish.setCostRate(rate);
        }

        dish = dishRepository.save(dish);
        return Result.success(dish);
    }

    private void applyParams(DishMaster dish, Map<String, Object> params) {
        if (params.get("dish_name") != null) dish.setDishName(params.get("dish_name").toString());
        if (params.get("dish_category") != null) dish.setDishCategory(params.get("dish_category").toString());
        if (params.get("spicy_level") != null) dish.setSpicyLevel(toInt(params.get("spicy_level")));
        if (params.get("main_ingredient_type") != null) dish.setMainIngredientType(params.get("main_ingredient_type").toString());
        if (params.get("main_ingredient") != null) dish.setMainIngredient(params.get("main_ingredient").toString());
        if (params.get("english_name") != null) dish.setEnglishName(params.get("english_name").toString());
        if (params.get("image_url") != null) dish.setImageUrl(params.get("image_url").toString());
        if (params.get("cost_price") != null) dish.setCostPrice(new BigDecimal(params.get("cost_price").toString()));
        if (params.get("sale_price") != null) dish.setSalePrice(new BigDecimal(params.get("sale_price").toString()));
        if (params.get("cooking_time") != null) dish.setCookingTime(toInt(params.get("cooking_time")));
        if (params.get("sort_order") != null) dish.setSortOrder(toInt(params.get("sort_order")));
        // 吉庆名
        if (params.get("festive_name") != null) dish.setFestiveName(params.get("festive_name").toString());
    }

    private int toInt(Object v) {
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }

    public Result<String> deleteDish(String dishId) {
        Long storeId = StoreContext.get();
        DishMasterId id = new DishMasterId();
        id.setDishId(dishId);
        id.setStoreId(storeId);

        Optional<DishMaster> opt = dishRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "菜品不存在");
        }

        DishMaster dish = opt.get();
        dish.setIsActive(0);
        dishRepository.save(dish);
        return Result.success("删除成功");
    }

    public Result<List<String>> getCategories(Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<String> categories = dishRepository.findDistinctCategoriesByStoreId(storeId);
        return Result.success(categories);
    }

    public Result<List<DishMaster>> searchDishes(String query, String usageType) {
        Long storeId = StoreContext.get();
        List<DishMaster> dishes;
        if (usageType != null && !usageType.isEmpty()) {
            dishes = dishRepository.searchByStoreIdAndUsageTypeAndName(storeId, usageType, query);
        } else {
            dishes = dishRepository.searchByStoreIdAndName(storeId, query);
        }
        return Result.success(dishes);
    }

    private String generateDishId(Long storeId) {
        // Get count of existing dishes and generate next ID
        List<DishMaster> existing = dishRepository.findByStoreIdAndIsActive(storeId, 1);
        int count = existing.size() + 1;
        return String.format("CY%05d", count);
    }
}

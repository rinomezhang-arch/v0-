package com.youjian.banquet.config;

import com.youjian.banquet.common.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public Result<?> handleAll(Exception e) {
        log.error("未捕获异常: {}", e.getMessage(), e);
        return Result.error(500, "服务器内部错误: " + e.getMessage());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public Result<?> handleDataIntegrity(DataIntegrityViolationException e) {
        String msg = e.getMessage();
        if (msg != null && msg.contains("Duplicate entry") && msg.contains("table_date_time")) {
            return Result.error(409, "该桌台在该时段已被预订，请选择其他时间");
        }
        if (msg != null && msg.contains("Duplicate entry")) {
            return Result.error(409, "数据重复，请检查后重试");
        }
        return Result.error(500, "操作失败");
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Leave;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LeaveRepository extends JpaRepository<Leave, Integer> {
    List<Leave> findByStoreIdAndStaffId(Long storeId, Integer staffId);
    List<Leave> findByStoreIdAndStatus(Long storeId, String status);
    List<Leave> findByStoreIdAndStartDateBetween(Long storeId, LocalDate startDate, LocalDate endDate);
    List<Leave> findByStoreId(Long storeId);
}
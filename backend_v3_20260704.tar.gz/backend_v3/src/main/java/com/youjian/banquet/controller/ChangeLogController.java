package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.ChangeLog;
import com.youjian.banquet.service.ChangeLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/change-logs")
public class ChangeLogController {

    @Autowired
    private ChangeLogService changeLogService;

    @GetMapping
    public Result<List<ChangeLog>> list(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "50") int pageSize,
            @RequestParam(required = false) String operationType,
            @RequestParam(required = false) String targetType,
            @RequestParam(required = false) String keyword) {
        return changeLogService.list(page, pageSize, operationType, targetType, keyword);
    }

    @GetMapping("/{id}")
    public Result<ChangeLog> detail(@PathVariable Long id) {
        return changeLogService.detail(id);
    }
}

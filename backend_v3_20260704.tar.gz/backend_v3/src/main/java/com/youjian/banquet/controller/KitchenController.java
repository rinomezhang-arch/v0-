package com.youjian.banquet.controller;

import com.youjian.banquet.service.KitchenService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/kitchen")
@RequiredArgsConstructor
public class KitchenController {

    private final KitchenService kitchenService;

    /** 今日厨房看板 — 按宴会列出所有待做菜品 */
    @GetMapping("/board")
    public ResponseEntity<Map<String, Object>> board(
            @RequestParam(defaultValue = "") String date) {
        return ResponseEntity.ok(kitchenService.getBoard(date));
    }

    /** 更新订单厨房状态 */
    @PostMapping("/order-status")
    public ResponseEntity<Map<String, Object>> updateOrderStatus(@RequestBody Map<String, Object> body) {
        String bookingId = (String) body.get("bookingId");
        String status = (String) body.get("status");
        return ResponseEntity.ok(kitchenService.updateOrderStatus(bookingId, status));
    }

    /** 更新单道菜品备菜状态 */
    @PostMapping("/dish-status")
    public ResponseEntity<Map<String, Object>> updateDishStatus(@RequestBody Map<String, Object> body) {
        Long dishBookingId = Long.valueOf(body.get("dishBookingId").toString());
        String status = (String) body.get("status");
        String station = (String) body.getOrDefault("station", null);
        String note = (String) body.getOrDefault("note", null);
        return ResponseEntity.ok(kitchenService.updateDishStatus(dishBookingId, status, station, note));
    }

    /** 工序日志 */
    @GetMapping("/log")
    public ResponseEntity<Map<String, Object>> log(@RequestParam(defaultValue = "50") int limit) {
        return ResponseEntity.ok(kitchenService.getRecentLog(limit));
    }
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "package_master")
public class Package {
    @Id
    @Column(name = "package_id", length = 20, nullable = false)
    private String packageId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "package_name", length = 100, nullable = false)
    private String packageName;

    @Column(name = "package_total_price", precision = 10, scale = 2)
    private BigDecimal packageTotalPrice = BigDecimal.ZERO;

    @Column(name = "package_cost_price", precision = 10, scale = 2)
    private BigDecimal packageCostPrice = BigDecimal.ZERO;

    @Column(name = "cost_rate", precision = 5, scale = 2)
    private BigDecimal costRate = BigDecimal.ZERO;

    @Column(name = "dish_count")
    private Integer dishCount = 0;

    @Column(name = "suggest_guests")
    private Integer suggestGuests = 10;

    @Column(name = "occasion_type", length = 20)
    private String occasionType;

    @Column(name = "package_series", length = 20)
    private String packageSeries;

    @Column(name = "is_active")
    private Integer isActive = 1;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

package com.youjian.banquet.service;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Booking;
import com.youjian.banquet.entity.BookingDishDetail;
import com.youjian.banquet.entity.BookingTable;
import com.youjian.banquet.repository.BookingDishDetailRepository;
import com.youjian.banquet.repository.BookingRepository;
import com.youjian.banquet.repository.BookingTableRepository;
import com.youjian.banquet.repository.TableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingTableRepository bookingTableRepository;

    @Autowired
    private BookingDishDetailRepository bookingDishDetailRepository;

    @Autowired
    private TableRepository tableRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ChangeLogService changeLogService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Result<Map<String, Object>> getBookingDetail(String id) {
        Long storeId = StoreContext.get();
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isEmpty()) {
            return Result.error(404, "预订不存在");
        }
        Booking b = booking.get();
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("bookingId", b.getBookingId());
        result.put("storeId", b.getStoreId());
        result.put("bookingDate", b.getBookingDate());
        result.put("bookingTime", b.getBookingTime());
        result.put("customerId", b.getCustomerId());
        result.put("customerName", b.getCustomerName());
        result.put("customerPhone", b.getCustomerPhone());
        result.put("staffId", b.getStaffId());
        result.put("staffName", b.getStaffName());
        result.put("deposit", b.getDeposit());
        result.put("guestCount", b.getGuestCount());
        result.put("tableCount", b.getTableCount());
        result.put("spareTables", b.getSpareTables());
        result.put("bookingStatus", b.getBookingStatus());
        result.put("banquetName", b.getBanquetName());
        result.put("occasionType", b.getOccasionType());
        result.put("totalAmount", b.getTotalAmount());
        result.put("finalAmount", b.getFinalAmount());
        result.put("paymentStatus", b.getPaymentStatus());
        result.put("specialRequest", b.getSpecialRequest());
        result.put("remark", b.getRemark());
        result.put("createdAt", b.getCreatedAt());
        result.put("updatedAt", b.getUpdatedAt());

        // 查询桌台信息
        List<BookingTable> tables = bookingTableRepository.findByStoreIdAndBookingId(storeId, id);
        List<Map<String, Object>> tableList = new ArrayList<>();
        for (BookingTable bt : tables) {
            Map<String, Object> tm = new LinkedHashMap<>();
            tm.put("tableBookingId", bt.getTableBookingId());
            tm.put("tableId", bt.getTableId());
            tm.put("tableNumber", bt.getTableNumber());
            tm.put("tableName", bt.getTableName());
            tm.put("guestCount", bt.getGuestCount());
            tableList.add(tm);
        }
        result.put("bookingTables", tableList);

        return Result.success(result);
    }

    public Result<Map<String, Object>> getBookingList(LocalDate date, Integer page, Integer size) {
        Long storeId = StoreContext.get();
        List<Booking> bookings;
        if (date != null) {
            bookings = bookingRepository.findByStoreIdAndBookingDate(storeId, date);
        } else {
            bookings = bookingRepository.findAll().stream()
                    .filter(b -> b.getStoreId().equals(storeId))
                    .collect(java.util.stream.Collectors.toList());
        }

        Map<String, Object> result = new HashMap<>();
        result.put("list", bookings);
        result.put("total", bookings.size());
        return Result.success(result);
    }

    public Result<Map<String, Object>> listBookings(LocalDate date, String time, String keyword, String status, Integer page, Integer pageSize) {
        Long storeId = StoreContext.get();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT b.booking_id, b.booking_date, b.booking_time, b.customer_name, b.customer_phone, ");
        sql.append("b.guest_count, b.table_count, b.spare_tables, b.occasion_type, b.booking_status, ");
        sql.append("b.deposit, b.total_amount, b.remark, b.created_at, b.staff_name, ");
        sql.append("GROUP_CONCAT(DISTINCT bt.table_number ORDER BY bt.table_booking_id SEPARATOR ',') as table_names, ");
        sql.append("GROUP_CONCAT(DISTINCT tm.table_area ORDER BY bt.table_booking_id SEPARATOR ',') as table_area, ");
        sql.append("COUNT(DISTINCT bd.dish_id) as dish_count, ");
        sql.append("COALESCE(SUM(bd.dish_quantity * bd.unit_price), 0) as dish_total ");
        sql.append("FROM booking_master b ");
        sql.append("LEFT JOIN booking_table bt ON b.booking_id = bt.booking_id AND bt.store_id = b.store_id ");
        sql.append("LEFT JOIN table_master tm ON bt.table_id = tm.table_id AND tm.store_id = b.store_id ");
        sql.append("LEFT JOIN booking_dish_detail bd ON b.booking_id = bd.booking_id AND bd.store_id = b.store_id ");
        sql.append("WHERE b.store_id = :storeId ");

        if (date != null) {
            sql.append("AND b.booking_date = :date ");
        }
        if (status != null && !status.isEmpty()) {
            sql.append("AND b.booking_status = :status ");
        }
        if (keyword != null && !keyword.isEmpty()) {
            sql.append("AND (b.customer_name LIKE :keyword OR b.customer_phone LIKE :keyword) ");
        }

        sql.append("GROUP BY b.booking_id ");

        String countSql = "SELECT COUNT(DISTINCT b.booking_id) FROM booking_master b LEFT JOIN booking_table bt ON b.booking_id = bt.booking_id WHERE b.store_id = :storeId ";
        if (date != null) countSql += "AND b.booking_date = :date ";
        if (status != null && !status.isEmpty()) countSql += "AND b.booking_status = :status ";
        if (keyword != null && !keyword.isEmpty()) countSql += "AND (b.customer_name LIKE :keyword OR b.customer_phone LIKE :keyword) ";

        Query countQuery = entityManager.createNativeQuery(countSql);
        countQuery.setParameter("storeId", storeId);
        if (date != null) countQuery.setParameter("date", date);
        if (status != null && !status.isEmpty()) countQuery.setParameter("status", status);
        if (keyword != null && !keyword.isEmpty()) countQuery.setParameter("keyword", "%" + keyword + "%");

        Long total = ((Number) countQuery.getSingleResult()).longValue();

        Query query = entityManager.createNativeQuery(sql.toString());
        query.setParameter("storeId", storeId);
        if (date != null) query.setParameter("date", date);
        if (status != null && !status.isEmpty()) query.setParameter("status", status);
        if (keyword != null && !keyword.isEmpty()) query.setParameter("keyword", "%" + keyword + "%");

        query.setFirstResult((page - 1) * pageSize);
        query.setMaxResults(pageSize);

        List<Object[]> results = query.getResultList();
        List<Map<String, Object>> rows = new ArrayList<>();

        for (Object[] row : results) {
            Map<String, Object> map = new HashMap<>();
            map.put("bookingId", row[0]);
            map.put("bookingDate", row[1]);
            map.put("bookingTime", row[2]);
            map.put("customerName", row[3]);
            map.put("customerPhone", row[4]);
            map.put("guestCount", row[5]);
            map.put("tableCount", row[6]);
            map.put("spareTables", row[7]);
            map.put("occasionType", row[8]);
            map.put("bookingStatus", row[9]);
            map.put("deposit", row[10]);
            map.put("totalAmount", row[11]);
            map.put("remark", row[12]);
            map.put("createdAt", row[13]);
            map.put("staffName", row[14]);
            map.put("tableNames", row[15]);
            map.put("tableArea", row[16]);
            map.put("dishCount", row[17]);
            map.put("dishTotal", row[18]);

            String bookingTimeStr = row[2] != null ? row[2].toString() : "";
            String timeLabel = bookingTimeStr.startsWith("11") || bookingTimeStr.startsWith("12") ? "午餐" : "晚餐";
            map.put("timeLabel", timeLabel);

            rows.add(map);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("total", total);
        return Result.success(result);
    }

    /**
     * 创建预订（事务管理）
     * 1. 保存 booking_master（主表）
     * 2. 保存 booking_table（桌台分配）
     * 3. 保存 booking_dish_detail（菜品明细）
     * 4. 计算总金额
     */
    @Transactional
    public Result<Booking> createBooking(Map<String, Object> params) {
        Long storeId = StoreContext.get();
        String bookingId = generateBookingId();

        LocalDate bookingDate = null;
        LocalTime bookingTime = null;

        if (params.get("booking_date") != null) {
            bookingDate = LocalDate.parse(params.get("booking_date").toString());
        }
        if (params.get("booking_time") != null) {
            bookingTime = LocalTime.parse(params.get("booking_time").toString());
        }

        // 1. 保存主表
        Booking booking = new Booking();
        booking.setBookingId(bookingId);
        booking.setStoreId(storeId);
        booking.setBookingDate(bookingDate);
        booking.setBookingTime(bookingTime);

        // 自动填充预定员（当前登录用户）
        try {
            var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
            System.out.println("[DEBUG] createBooking auth=" + auth + ", principal=" + (auth != null ? auth.getPrincipal() : "null") + ", details=" + (auth != null ? auth.getDetails() : "null"));
            if (auth != null && auth.getDetails() instanceof java.util.Map) {
                @SuppressWarnings("unchecked")
                var details = (java.util.Map<String, Object>) auth.getDetails();
                Integer staffId = (Integer) details.get("staffId");
                String staffName = (String) details.get("staffName");
                System.out.println("[DEBUG] staffId=" + staffId + ", staffName=" + staffName);
                if (staffId != null) booking.setStaffId(staffId);
                if (staffName != null) booking.setStaffName(staffName);
            }
        } catch (Exception e) {
            System.out.println("[DEBUG] 预定员填充异常: " + e.getMessage());
        }

        if (params.get("customer_name") != null) {
            booking.setCustomerName(params.get("customer_name").toString());
        }
        if (params.get("customer_phone") != null) {
            booking.setCustomerPhone(params.get("customer_phone").toString());
        }
        if (params.get("customer_id") != null) {
            booking.setCustomerId(Integer.parseInt(params.get("customer_id").toString()));
        }
        if (params.get("occasion_type") != null) {
            booking.setOccasionType(params.get("occasion_type").toString());
        }
        if (params.get("guest_count") != null) {
            booking.setGuestCount(Integer.parseInt(params.get("guest_count").toString()));
        }
        if (params.get("table_count") != null) {
            booking.setTableCount(Integer.parseInt(params.get("table_count").toString()));
        }
        if (params.get("spare_tables") != null) {
            booking.setSpareTables(Integer.parseInt(params.get("spare_tables").toString()));
        }
        if (params.get("deposit") != null) {
            booking.setDeposit(new BigDecimal(params.get("deposit").toString()));
        }
        if (params.get("booking_status") != null) {
            booking.setBookingStatus(params.get("booking_status").toString());
        } else {
            booking.setBookingStatus("confirmed");
        }
        if (params.get("remark") != null) {
            booking.setRemark(params.get("remark").toString());
        }

        booking = bookingRepository.save(booking);

        // 2. 保存桌台分配
        saveBookingTables(storeId, bookingId, bookingDate, bookingTime, params);

        // 3. 保存菜品明细 + 计算总金额
        BigDecimal totalAmount = saveBookingDishes(storeId, bookingId, params);

        // 4. 更新总金额
        booking.setTotalAmount(totalAmount);
        bookingRepository.save(booking);

        // 记录日志
        try {
            String op = "系统";
            Integer oid = 0;
            var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getDetails() instanceof java.util.Map) {
                @SuppressWarnings("unchecked")
                var details = (java.util.Map<String, Object>) auth.getDetails();
                op = (String) details.getOrDefault("staffName", "系统");
                oid = (Integer) details.get("staffId");
            }
            String cus = params.getOrDefault("customer_name", "") + " " + params.getOrDefault("customer_phone", "");
            jdbcTemplate.update(
                "INSERT INTO change_log(store_id,operator_id,operator_name,operation_type,target_type,target_id,summary,created_at) VALUES(1,?,?,'create','booking',?,?,NOW())",
                oid != null ? oid : 0,
                op,
                bookingId,
                "创建预订 " + cus
            );
        } catch (Exception ignored) {}

        return Result.success(booking);
    }

    /**
     * 更新预订（事务管理）
     * 1. 更新主表字段
     * 2. 重新分配桌台（先删后插）
     * 3. 重新保存菜品（先删后插）
     * 4. 重新计算总金额
     */
    @Transactional
    public Result<Booking> updateBooking(String id, Map<String, Object> params) {
        Long storeId = StoreContext.get();
        Optional<Booking> opt = bookingRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "预订不存在");
        }
        Booking booking = opt.get();

        // 记录变更前的快照（用于字段级日志）
        Map<String, String> changes = new LinkedHashMap<>();
        String oldDate = booking.getBookingDate() != null ? booking.getBookingDate().toString() : "";
        String oldTime = booking.getBookingTime() != null ? booking.getBookingTime().toString() : "";
        String oldName = booking.getCustomerName() != null ? booking.getCustomerName() : "";
        String oldPhone = booking.getCustomerPhone() != null ? booking.getCustomerPhone() : "";
        String oldOccasion = booking.getOccasionType() != null ? booking.getOccasionType() : "";
        String oldStatus = booking.getBookingStatus() != null ? booking.getBookingStatus() : "";
        int oldGuest = booking.getGuestCount() != null ? booking.getGuestCount() : 0;
        int oldTable = booking.getTableCount() != null ? booking.getTableCount() : 0;
        int oldSpare = booking.getSpareTables() != null ? booking.getSpareTables() : 0;
        BigDecimal oldDeposit = booking.getDeposit() != null ? booking.getDeposit() : BigDecimal.ZERO;
        String oldRemark = booking.getRemark() != null ? booking.getRemark() : "";

        // 更新所有可变更字段
        if (params.get("booking_date") != null) {
            String nv = params.get("booking_date").toString();
            if (!nv.equals(oldDate)) changes.put("日期", oldDate + " → " + nv);
            booking.setBookingDate(LocalDate.parse(nv));
        }
        if (params.get("booking_time") != null) {
            String nv = params.get("booking_time").toString();
            if (!nv.equals(oldTime)) changes.put("时段", oldTime + " → " + nv);
            booking.setBookingTime(LocalTime.parse(nv));
        }
        if (params.get("customer_name") != null) {
            String nv = params.get("customer_name").toString();
            if (!nv.equals(oldName)) changes.put("客户姓名", oldName + " → " + nv);
            booking.setCustomerName(nv);
        }
        if (params.get("customer_phone") != null) {
            String nv = params.get("customer_phone").toString();
            if (!nv.equals(oldPhone)) changes.put("联系电话", oldPhone + " → " + nv);
            booking.setCustomerPhone(nv);
        }
        if (params.get("occasion_type") != null) {
            String nv = params.get("occasion_type").toString();
            if (!nv.equals(oldOccasion)) changes.put("宴席类型", oldOccasion + " → " + nv);
            booking.setOccasionType(nv);
        }
        if (params.get("guest_count") != null) {
            int nv = Integer.parseInt(params.get("guest_count").toString());
            if (nv != oldGuest) changes.put("人数", oldGuest + " → " + nv);
            booking.setGuestCount(nv);
        }
        if (params.get("table_count") != null) {
            int nv = Integer.parseInt(params.get("table_count").toString());
            if (nv != oldTable) changes.put("桌数", oldTable + " → " + nv);
            booking.setTableCount(nv);
        }
        if (params.get("spare_tables") != null) {
            int nv = Integer.parseInt(params.get("spare_tables").toString());
            if (nv != oldSpare) changes.put("备桌", oldSpare + " → " + nv);
            booking.setSpareTables(nv);
        }
        if (params.get("deposit") != null) {
            BigDecimal nv = new BigDecimal(params.get("deposit").toString());
            if (nv.compareTo(oldDeposit) != 0) changes.put("定金", oldDeposit + " → " + nv);
            booking.setDeposit(nv);
        }
        if (params.get("booking_status") != null) {
            String nv = params.get("booking_status").toString();
            if (!nv.equals(oldStatus)) changes.put("状态", oldStatus + " → " + nv);
            booking.setBookingStatus(nv);
        }
        if (params.get("remark") != null) {
            String nv = params.get("remark").toString();
            if (!nv.equals(oldRemark)) changes.put("备注", oldRemark + " → " + nv);
            booking.setRemark(nv);
        }

        // 重新分配桌台（先删旧记录，再插新的）
        List<BookingTable> oldTables = bookingTableRepository.findByStoreIdAndBookingId(storeId, id);
        String oldTableNames = oldTables.stream().map(t -> t.getTableNumber() != null ? t.getTableNumber() : t.getTableName()).reduce((a, b) -> a + "," + b).orElse("");
        if (!oldTables.isEmpty()) {
            bookingTableRepository.deleteAll(oldTables);
        }
        saveBookingTables(storeId, id, booking.getBookingDate(), booking.getBookingTime(), params);

        // 重新保存菜品（先删旧记录，再插新的）
        List<BookingDishDetail> oldDishes = bookingDishDetailRepository.findByStoreIdAndBookingId(storeId, id);
        if (!oldDishes.isEmpty()) {
            bookingDishDetailRepository.deleteAll(oldDishes);
        }
        BigDecimal totalAmount = saveBookingDishes(storeId, id, params);

        // 更新总金额
        booking.setTotalAmount(totalAmount);
        booking = bookingRepository.save(booking);

        // 记录字段级变更日志
        try {
            String cus = booking.getCustomerName() != null ? booking.getCustomerName() : "";
            String op = "系统";
            Integer oid = 0;
            var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getDetails() instanceof java.util.Map) {
                @SuppressWarnings("unchecked")
                var details = (java.util.Map<String, Object>) auth.getDetails();
                op = (String) details.getOrDefault("staffName", "系统");
                oid = (Integer) details.get("staffId");
            }

            if (!changes.isEmpty()) {
                StringBuilder detail = new StringBuilder();
                for (Map.Entry<String, String> e : changes.entrySet()) {
                    detail.append(e.getKey()).append(": ").append(e.getValue()).append("; ");
                }
                String detailStr = detail.toString();
                String summary = "修改预订 " + cus + " (" + String.join(", ", changes.keySet()) + ")";
                changeLogService.log(op, oid != null ? oid : 0,
                    "update", "booking", id, summary, detailStr, null, null);
            }
        } catch (Exception ignored) {}

        return Result.success(booking);
    }

    /**
     * 取消预订（事务管理）
     * 1. 软删除主表（状态改为cancelled）
     * 2. 删除桌台关联记录（释放桌台）
     * 3. 菜品明细保留用于历史查询
     */
    @Transactional
    public Result<String> deleteBooking(String id) {
        Long storeId = StoreContext.get();
        Optional<Booking> opt = bookingRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "预订不存在");
        }
        Booking booking = opt.get();

        // 释放桌台：删除关联记录
        List<BookingTable> tables = bookingTableRepository.findByStoreIdAndBookingId(storeId, id);
        if (!tables.isEmpty()) {
            bookingTableRepository.deleteAll(tables);
        }

        // 软删除主表
        booking.setBookingStatus("cancelled");
        bookingRepository.save(booking);

        // 记录日志
        try {
            String cus = booking.getCustomerName() != null ? booking.getCustomerName() : "";
            jdbcTemplate.update(
                "INSERT INTO change_log(store_id,operator_id,operator_name,operation_type,target_type,target_id,summary,created_at) VALUES(1,0,'系统','delete','booking',?,?,NOW())",
                id,
                "取消预订 " + cus
            );
        } catch (Exception ignored) {}

        return Result.success("取消成功");
    }

    // ==================== 私有辅助方法 ====================

    /**
     * 保存桌台分配
     */
    private void saveBookingTables(Long storeId, String bookingId, LocalDate bookingDate, LocalTime bookingTime, Map<String, Object> params) {
        Object tableIdsObj = params.get("table_ids");
        Object tableNamesObj = params.get("table_names");
        List<Integer> tableIds = new ArrayList<>();
        List<String> tableNames = new ArrayList<>();

        if (tableIdsObj instanceof List) {
            for (Object id : (List<?>) tableIdsObj) {
                if (id instanceof Number) {
                    tableIds.add(((Number) id).intValue());
                } else {
                    tableIds.add(Integer.parseInt(id.toString()));
                }
            }
        }
        if (tableNamesObj instanceof List) {
            for (Object name : (List<?>) tableNamesObj) {
                tableNames.add(name.toString());
            }
        }

        // 校验台号是否存在
        if (!tableIds.isEmpty()) {
            List<Integer> validTableIds = tableRepository.findValidTableIds(storeId, tableIds);
            List<Integer> invalidTableIds = new ArrayList<>(tableIds);
            invalidTableIds.removeAll(validTableIds);
            if (!invalidTableIds.isEmpty()) {
                throw new RuntimeException("以下台号不存在: " + invalidTableIds);
            }
        }

        for (int i = 0; i < tableIds.size(); i++) {
            Integer tableId = tableIds.get(i);
            String tableNumber = i < tableNames.size() ? tableNames.get(i) : "";

            BookingTable bt = new BookingTable();
            bt.setStoreId(storeId);
            bt.setBookingId(bookingId);
            bt.setTableId(tableId);
            bt.setTableNumber(tableNumber);
            bt.setBookingDate(bookingDate);
            bt.setBookingTime(bookingTime);
            bt.setCreatedAt(LocalDateTime.now());

            bookingTableRepository.save(bt);
        }
    }

    /**
     * 保存菜品明细并计算总金额
     */
    private BigDecimal saveBookingDishes(Long storeId, String bookingId, Map<String, Object> params) {
        Object dishesObj = params.get("dishes");
        BigDecimal totalAmount = BigDecimal.ZERO;
        int order = 0;

        if (dishesObj instanceof List) {
            for (Object item : (List<?>) dishesObj) {
                if (!(item instanceof Map)) continue;
                @SuppressWarnings("unchecked")
                Map<String, Object> dish = (Map<String, Object>) item;

                String dishId = dish.getOrDefault("dishId", "").toString();
                String dishName = dish.getOrDefault("dishName", "").toString();
                int qty = 1;
                BigDecimal price = BigDecimal.ZERO;

                if (dish.get("qty") != null) {
                    qty = Integer.parseInt(dish.get("qty").toString());
                }
                if (dish.get("price") != null) {
                    price = new BigDecimal(dish.get("price").toString());
                }

                BigDecimal subtotal = price.multiply(BigDecimal.valueOf(qty));
                totalAmount = totalAmount.add(subtotal);

                BookingDishDetail detail = new BookingDishDetail();
                detail.setStoreId(storeId);
                detail.setBookingId(bookingId);
                detail.setDishId(dishId);
                detail.setDishName(dishName);
                detail.setDishQuantity(qty);
                detail.setUnitPrice(price);
                detail.setSubtotal(subtotal);
                detail.setDishOrder(order++);

                bookingDishDetailRepository.save(detail);
            }
        }

        return totalAmount;
    }

    private String getPeriod(LocalTime time) {
        int hour = time.getHour();
        if (hour >= 9 && hour < 12) return "morning";
        if (hour >= 11 && hour < 14) return "lunch";
        if (hour >= 14 && hour < 17) return "afternoon";
        if (hour >= 17 && hour < 21) return "dinner";
        return "other";
    }

    private String getPeriodName(String period) {
        Map<String, String> names = new HashMap<>();
        names.put("morning", "上午");
        names.put("lunch", "午餐");
        names.put("afternoon", "下午");
        names.put("dinner", "晚餐");
        names.put("other", "该");
        return names.getOrDefault(period, "该");
    }

    public Result<Map<String, Object>> getTodayOverview() {
        Long storeId = StoreContext.get();
        LocalDate today = LocalDate.now();
        List<Booking> bookings = bookingRepository.findActiveBookingsByDate(storeId, today);

        Map<String, Object> data = new HashMap<>();
        data.put("bookingCount", bookings.size());
        data.put("totalGuests", bookings.stream().mapToInt(b -> b.getGuestCount() != null ? b.getGuestCount() : 0).sum());
        data.put("totalAmount", bookings.stream()
                .map(b -> b.getTotalAmount() != null ? b.getTotalAmount() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        data.put("depositTotal", bookings.stream()
                .map(b -> b.getDeposit() != null ? b.getDeposit() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add));

        return Result.success(data);
    }

    private String generateBookingId() {
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        // 用系统纳秒+随机数提高唯一性
        long nano = System.nanoTime() % 100000;
        String random = String.format("%05d", Math.abs((int) (nano % 100000)));
        return "BK" + date + random;
    }
}

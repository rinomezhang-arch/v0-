package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "dish_recipe")
public class DishRecipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recipe_id")
    private Long recipeId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "dish_id", length = 20, nullable = false)
    private String dishId;

    @Column(name = "ingredient_id", length = 50, nullable = false)
    private String ingredientId;

    @Column(name = "ingredient_name", length = 100)
    private String ingredientName;

    @Column(name = "unit", length = 20)
    private String unit;

    @Column(name = "unit_price", precision = 10, scale = 4)
    private BigDecimal unitPrice = BigDecimal.ZERO;

    @Column(name = "quantity", precision = 10, scale = 3)
    private BigDecimal quantity = BigDecimal.ZERO;

    @Column(name = "total_cost", precision = 10, scale = 2)
    private BigDecimal totalCost = BigDecimal.ZERO;

    @Column(name = "wastage_rate", precision = 5, scale = 2)
    private BigDecimal wastageRate = BigDecimal.ZERO;

    @Column(name = "yield_rate", precision = 5, scale = 2)
    private BigDecimal yieldRate = BigDecimal.ZERO;

    @Column(name = "net_unit_price", precision = 10, scale = 4)
    private BigDecimal netUnitPrice = BigDecimal.ZERO;

    @Column(name = "last_entry_date")
    private java.time.LocalDate lastEntryDate;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

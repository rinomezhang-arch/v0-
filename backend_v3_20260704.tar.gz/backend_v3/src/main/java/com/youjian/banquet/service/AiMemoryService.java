package com.youjian.banquet.service;

import com.youjian.banquet.entity.AiMemory;
import com.youjian.banquet.repository.AiMemoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AiMemoryService {
    
    private final AiMemoryRepository memoryRepository;
    
    /**
     * 获取用户的所有记忆
     */
    public List<AiMemory> getUserMemories(Long userId) {
        return memoryRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
    
    /**
     * 添加记忆
     */
    public AiMemory addMemory(Long userId, String content) {
        AiMemory memory = new AiMemory();
        memory.setUserId(userId);
        memory.setContent(content);
        return memoryRepository.save(memory);
    }
    
    /**
     * 删除记忆
     */
    public void deleteMemory(Long userId, Long memoryId) {
        memoryRepository.deleteByUserIdAndId(userId, memoryId);
    }
    
    /**
     * 获取记忆上下文（用于注入到AI prompt）
     */
    public String getMemoryContext(Long userId) {
        List<AiMemory> memories = getUserMemories(userId);
        if (memories.isEmpty()) {
            return "";
        }
        
        String memoryText = memories.stream()
                .limit(10) // 最多取最近10条
                .map(m -> "- " + m.getContent())
                .collect(Collectors.joining("\n"));
        
        return "\n【用户记忆】\n" + memoryText + "\n";
    }
}

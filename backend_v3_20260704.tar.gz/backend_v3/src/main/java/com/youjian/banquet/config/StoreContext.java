package com.youjian.banquet.config;

public class StoreContext {
    private static final ThreadLocal<Long> STORE_ID = new ThreadLocal<>();

    public static void set(Long storeId) {
        STORE_ID.set(storeId);
    }

    public static Long get() {
        Long id = STORE_ID.get();
        return id != null ? id : 1L;
    }

    public static void clear() {
        STORE_ID.remove();
    }
}

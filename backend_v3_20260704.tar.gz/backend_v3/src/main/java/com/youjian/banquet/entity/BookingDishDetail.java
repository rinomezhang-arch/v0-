package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "booking_dish_detail")
public class BookingDishDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dish_booking_id")
    private Long dishBookingId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "table_booking_id")
    private Long tableBookingId;

    @Column(name = "booking_id", length = 20)
    private String bookingId;

    @Column(name = "dish_id", length = 20, nullable = false)
    private String dishId;

    @Column(name = "dish_name", length = 100)
    private String dishName;

    @Column(name = "dish_quantity")
    private Integer dishQuantity = 1;

    @Column(name = "unit_price", precision = 10, scale = 2)
    private BigDecimal unitPrice = BigDecimal.ZERO;

    @Column(name = "subtotal", precision = 10, scale = 2)
    private BigDecimal subtotal = BigDecimal.ZERO;

    @Column(name = "custom_name", length = 100)
    private String customName;

    @Column(name = "dish_note", length = 255)
    private String dishNote;

    @Column(name = "dish_order")
    private Integer dishOrder = 0;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}

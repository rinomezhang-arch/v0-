package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.DishMaster;
import com.youjian.banquet.entity.DishRecipe;
import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.repository.DishRecipeRepository;
import com.youjian.banquet.repository.DishRepository;
import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.repository.IngredientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    @Autowired
    private DishRecipeRepository recipeRepository;

    @Autowired
    private DishRepository dishRepository;

    @Autowired
    private IngredientRepository ingredientRepository;

    /**
     * 获取菜品的配方列表（成本卡）
     */
    @GetMapping("/{dishId}")
    public Result<List<DishRecipe>> getRecipe(@PathVariable String dishId) {
        Long storeId = StoreContext.get();
        List<DishRecipe> list = recipeRepository.findByStoreIdAndDishIdOrderBySortOrderAsc(storeId, dishId);
        return Result.success(list);
    }

    /**
     * 保存菜品配方（全量替换）
     * 接收 [{ ingredientId, ingredientName, unit, unitPrice, quantity, wastageRate }]
     * 后端自动计算: netUnitPrice = unitPrice / (1 - wastageRate/100)
     *             totalCost = quantity * netUnitPrice
     */
    @PostMapping("/{dishId}")
    public Result<String> saveRecipe(@PathVariable String dishId, @RequestBody List<Map<String, Object>> items) {
        Long storeId = StoreContext.get();

        // 删除旧配方
        recipeRepository.deleteByStoreIdAndDishId(storeId, dishId);

        BigDecimal totalDishCost = BigDecimal.ZERO;

        for (int i = 0; i < items.size(); i++) {
            Map<String, Object> item = items.get(i);
            DishRecipe recipe = new DishRecipe();
            recipe.setStoreId(storeId);
            recipe.setDishId(dishId);
            recipe.setSortOrder(i);

            String ingredientId = (String) item.get("ingredientId");
            recipe.setIngredientId(ingredientId);
            recipe.setIngredientName((String) item.getOrDefault("ingredientName", ""));

            // 用量
            BigDecimal quantity = toDecimal(item.get("quantity"));
            recipe.setQuantity(quantity);

            // 采购单价(使用单位单价)
            BigDecimal unitPrice = toDecimal(item.get("unitPrice"));
            recipe.setUnitPrice(unitPrice);

            recipe.setUnit((String) item.getOrDefault("unit", ""));

            // 损耗率
            BigDecimal wastageRate = toDecimal(item.get("wastageRate"));
            recipe.setWastageRate(wastageRate);

            // 出成率
            BigDecimal yieldRate = toDecimal(item.get("yieldRate"));
            recipe.setYieldRate(yieldRate);

            // 计算净料单价: unitPrice / (1 - wastageRate/100)
            BigDecimal rate = BigDecimal.ONE.subtract(wastageRate.divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP));
            BigDecimal netUnitPrice = BigDecimal.ZERO;
            if (rate.compareTo(BigDecimal.ZERO) > 0) {
                netUnitPrice = unitPrice.divide(rate, 4, RoundingMode.HALF_UP);
            }
            recipe.setNetUnitPrice(netUnitPrice);

            // 小计: quantity * netUnitPrice
            BigDecimal totalCost = quantity.multiply(netUnitPrice).setScale(2, RoundingMode.HALF_UP);
            recipe.setTotalCost(totalCost);

            // last entry date
            String lastDate = (String) item.getOrDefault("lastEntryDate", "");
            if (lastDate != null && !lastDate.isEmpty()) {
                try { recipe.setLastEntryDate(java.time.LocalDate.parse(lastDate)); } catch (Exception ignored) {}
            }

            recipeRepository.save(recipe);
            totalDishCost = totalDishCost.add(totalCost);
        }

        // 更新菜品总成本
        DishMaster.DishMasterId id = new DishMaster.DishMasterId();
        id.setDishId(dishId);
        id.setStoreId(storeId);
        DishMaster dish = dishRepository.findById(id).orElse(null);
        if (dish != null) {
            dish.setCostPrice(totalDishCost);
            if (dish.getSalePrice() != null && dish.getSalePrice().compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal costRate = totalDishCost.divide(dish.getSalePrice(), 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP);
                dish.setCostRate(costRate);
            }
            dishRepository.save(dish);
        }

        return Result.success("保存成功，总成本: ¥" + totalDishCost);
    }

    /**
     * 获取已配置配方的菜品列表
     */
    @GetMapping("/dishes-with-recipe")
    public Result<List<String>> getDishesWithRecipe() {
        Long storeId = StoreContext.get();
        return Result.success(recipeRepository.findDistinctDishIdsByStoreId(storeId));
    }

    /**
     * 原料价格变动后，重算所有关联菜品的成本
     */
    @PostMapping("/recalc-all")
    public Result<String> recalcAllDishCosts() {
        Long storeId = StoreContext.get();
        List<String> dishIds = recipeRepository.findDistinctDishIdsByStoreId(storeId);
        int count = 0;
        for (String dishId : dishIds) {
            List<DishRecipe> recipes = recipeRepository.findByStoreIdAndDishIdOrderBySortOrderAsc(storeId, dishId);
            BigDecimal totalCost = BigDecimal.ZERO;
            for (DishRecipe r : recipes) {
                // 从 ingredient_master 取最新价格
                Ingredient.IngredientId ingId = new Ingredient.IngredientId();
                ingId.setIngredientId(r.getIngredientId());
                ingId.setStoreId(storeId);
                Ingredient ing = ingredientRepository.findById(ingId).orElse(null);
                if (ing != null && ing.getAvgPrice() != null) {
                    r.setUnitPrice(ing.getAvgPrice());
                }
                // 重算净料单价和小计
                BigDecimal rate = BigDecimal.ONE.subtract(
                    r.getWastageRate().divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP));
                BigDecimal netPrice = BigDecimal.ZERO;
                if (rate.compareTo(BigDecimal.ZERO) > 0) {
                    netPrice = r.getUnitPrice().divide(rate, 4, RoundingMode.HALF_UP);
                }
                r.setNetUnitPrice(netPrice);
                BigDecimal cost = r.getQuantity().multiply(netPrice).setScale(2, RoundingMode.HALF_UP);
                r.setTotalCost(cost);
                recipeRepository.save(r);
                totalCost = totalCost.add(cost);
            }
            // 更新菜品
            DishMaster.DishMasterId dmId = new DishMaster.DishMasterId();
            dmId.setDishId(dishId);
            dmId.setStoreId(storeId);
            DishMaster dish = dishRepository.findById(dmId).orElse(null);
            if (dish != null) {
                dish.setCostPrice(totalCost);
                if (dish.getSalePrice() != null && dish.getSalePrice().compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal costRate = totalCost.divide(dish.getSalePrice(), 4, RoundingMode.HALF_UP)
                            .multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP);
                    dish.setCostRate(costRate);
                }
                dishRepository.save(dish);
                count++;
            }
        }
        return Result.success("已重算 " + count + " 道菜品成本");
    }

    private BigDecimal toDecimal(Object val) {
        if (val == null) return BigDecimal.ZERO;
        try {
            return new BigDecimal(val.toString());
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }
}

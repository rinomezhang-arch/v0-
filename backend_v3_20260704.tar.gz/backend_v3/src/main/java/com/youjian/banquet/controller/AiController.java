package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.service.AiService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiController {

    private final AiService aiService;

    @PostMapping("/banquet/suggest")
    public Result<String> generateBanquetSuggestion(@RequestBody Map<String, Object> request) {
        String occasion = (String) request.get("occasion");
        int guestCount = ((Number) request.get("guestCount")).intValue();
        String preferences = (String) request.get("preferences");
        String result = aiService.generateBanquetSuggestion(occasion, guestCount, preferences);
        return Result.success(result);
    }

    @PostMapping("/dish/recommend")
    public Result<String> generateDishRecommendation(@RequestBody Map<String, Object> request) {
        String occasion = (String) request.get("occasion");
        int guestCount = ((Number) request.get("guestCount")).intValue();
        String dietaryRestrictions = (String) request.get("dietaryRestrictions");
        String result = aiService.generateDishRecommendation(occasion, guestCount, dietaryRestrictions);
        return Result.success(result);
    }

    @PostMapping("/copy/generate")
    public Result<String> generateCopywriting(@RequestBody Map<String, Object> request) {
        String type = (String) request.get("type");
        String keywords = (String) request.get("keywords");
        String result = aiService.generateCopywriting(type, keywords);
        return Result.success(result);
    }

    @PostMapping("/image/analyze")
    public Result<String> analyzeImage(@RequestBody Map<String, Object> request) {
        String imageBase64 = (String) request.get("image");
        String prompt = (String) request.get("prompt");
        String result = aiService.analyzeImage(imageBase64, prompt);
        return Result.success(result);
    }
}

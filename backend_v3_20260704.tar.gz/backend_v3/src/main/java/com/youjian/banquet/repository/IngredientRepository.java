package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.entity.Ingredient.IngredientId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IngredientRepository extends JpaRepository<Ingredient, IngredientId> {

    List<Ingredient> findByStoreIdAndIsActive(Long storeId, Integer isActive);

    List<Ingredient> findByStoreId(Long storeId);

    @Query("SELECT i FROM Ingredient i WHERE i.storeId = :storeId AND i.isActive = 1 AND i.currentStock <= i.warningThreshold")
    List<Ingredient> findLowStockWarnings(@Param("storeId") Long storeId);
}

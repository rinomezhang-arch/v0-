package com.youjian.banquet.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 优先从 Authorization header 读，其次从 cookie 读
        String token = null;
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
        } else if (request.getCookies() != null) {
            for (jakarta.servlet.http.Cookie c : request.getCookies()) {
                if ("banquet_token".equals(c.getName())) {
                    token = c.getValue();
                    break;
                }
            }
        }

        if (token == null) {
            // 设置游客身份
            com.youjian.banquet.config.StoreContext.set(1L);
            request.setAttribute("visitor", true);
            UsernamePasswordAuthenticationToken guest = new UsernamePasswordAuthenticationToken(
                    "guest", null, List.of(new SimpleGrantedAuthority("ROLE_VISITOR")));
            guest.setDetails(Map.of("permissionLevel", 0, "storeId", 1L));
            SecurityContextHolder.getContext().setAuthentication(guest);
            filterChain.doFilter(request, response);
            return;
        }

        try {
            if (jwtUtil.validateToken(token)) {
                var claims = jwtUtil.getClaims(token);
                Integer staffId = Integer.parseInt(claims.getSubject());
                String staffName = claims.get("staffName", String.class);
                Long storeId = claims.get("storeId", Long.class);
                String role = claims.get("role", String.class);
                if (role == null) role = "staff";
                int permLevel = claims.get("permissionLevel", Integer.class) != null
                        ? claims.get("permissionLevel", Integer.class) : 1;
                String department = claims.get("department", String.class);
                Integer deptId = claims.get("deptId", Integer.class);

                com.youjian.banquet.config.StoreContext.set(storeId);

                List<SimpleGrantedAuthority> authorities = new ArrayList<>();
                authorities.add(new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()));
                if (permLevel >= 99) authorities.add(new SimpleGrantedAuthority("ROLE_SUPER_ADMIN"));

                Map<String, Object> details = new HashMap<>();
                details.put("staffId", staffId);
                details.put("staffName", staffName);
                details.put("storeId", storeId);
                details.put("role", role);
                details.put("permissionLevel", permLevel);
                details.put("department", department);
                details.put("deptId", deptId);

                UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                        staffId, null, authorities);
                auth.setDetails(details);
                auth.setAuthenticated(true);
                SecurityContextHolder.getContext().setAuthentication(auth);
                request.setAttribute("visitor", false);
            }
        } catch (Exception e) {
            SecurityContextHolder.clearContext();
        }

        filterChain.doFilter(request, response);
    }
}

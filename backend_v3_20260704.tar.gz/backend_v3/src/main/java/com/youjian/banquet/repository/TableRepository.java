package com.youjian.banquet.repository;

import com.youjian.banquet.entity.TableMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TableRepository extends JpaRepository<TableMaster, Integer> {
    List<TableMaster> findByStoreIdAndIsActive(Long storeId, Integer isActive);
    
    @Query("SELECT t.tableId FROM TableMaster t WHERE t.storeId = :storeId AND t.tableId IN :tableIds")
    List<Integer> findValidTableIds(@Param("storeId") Long storeId, @Param("tableIds") List<Integer> tableIds);
}

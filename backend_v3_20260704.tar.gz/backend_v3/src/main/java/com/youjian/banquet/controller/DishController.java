package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.DishMaster;
import com.youjian.banquet.service.DishService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dishes")
public class DishController {

    @Autowired
    private DishService dishService;

    @GetMapping
    public Result<List<DishMaster>> getDishes(
        @RequestParam(required = false) Long storeId,
        @RequestParam(required = false) String usageType
    ) {
        return dishService.getDishList(storeId, usageType);
    }

    @PostMapping
    public Result<DishMaster> createDish(@RequestBody Map<String, Object> params) {
        return dishService.createDish(params);
    }

    @PutMapping("/{id}")
    public Result<DishMaster> updateDish(@PathVariable String id, @RequestBody Map<String, Object> params) {
        return dishService.updateDish(id, params);
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteDish(@PathVariable String id) {
        return dishService.deleteDish(id);
    }

    @GetMapping("/categories")
    public Result<List<String>> getCategories(@RequestParam(required = false) Long storeId) {
        return dishService.getCategories(storeId);
    }

    @GetMapping("/search")
    public Result<List<DishMaster>> searchDishes(
        @RequestParam String q,
        @RequestParam(required = false) String usageType
    ) {
        return dishService.searchDishes(q, usageType);
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer> {
    List<Department> findByStoreIdAndStatus(Long storeId, String status);
    List<Department> findByStoreId(Long storeId);
    List<Department> findByParentId(Integer parentId);
    boolean existsByDeptNameAndStoreId(String deptName, Long storeId);
}
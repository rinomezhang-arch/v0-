package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.Booking;
import com.youjian.banquet.entity.ChangeLog;
import com.youjian.banquet.service.BookingService;
import com.youjian.banquet.service.ChangeLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private ChangeLogService changeLogService;

    @GetMapping
    public Result<Map<String, Object>> getBookings(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer size) {
        return bookingService.getBookingList(date, page, size);
    }

    @GetMapping("/list")
    public Result<Map<String, Object>> listBookings(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        return bookingService.listBookings(date, time, keyword, status, page, pageSize);
    }

    @GetMapping("/{id}")
    public Result<Map<String, Object>> getBooking(@PathVariable String id) {
        return bookingService.getBookingDetail(id);
    }

    @PostMapping
    public Result<Booking> createBooking(@RequestBody Map<String, Object> params) {
        return bookingService.createBooking(params);
    }

    @PutMapping("/{id}")
    public Result<Booking> updateBooking(@PathVariable String id, @RequestBody Map<String, Object> params) {
        return bookingService.updateBooking(id, params);
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteBooking(@PathVariable String id) {
        return bookingService.deleteBooking(id);
    }

    @GetMapping("/{id}/logs")
    public Result<List<ChangeLog>> getBookingLogs(@PathVariable String id) {
        return changeLogService.list(1, 100, "update", "booking", id);
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.PurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {

    List<PurchaseOrder> findByStoreIdOrderByPurchaseDateDesc(Long storeId);

    List<PurchaseOrder> findByStoreIdAndIngredientIdOrderByPurchaseDateDesc(Long storeId, String ingredientId);

    List<PurchaseOrder> findByStoreIdAndStatusOrderByPurchaseDateDesc(Long storeId, String status);
}

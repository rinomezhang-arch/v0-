package com.youjian.banquet.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private long expiration;

    private SecretKey getSigningKey() {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /** 完整 token：包含职位、权限等级、部门 */
    public String generateToken(Integer staffId, String staffName, Long storeId,
                                String role, int permissionLevel, Integer deptId, String department) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expiration);

        return Jwts.builder()
                .subject(String.valueOf(staffId))
                .claim("staffName", staffName)
                .claim("storeId", storeId)
                .claim("role", role)
                .claim("permissionLevel", permissionLevel)
                .claim("deptId", deptId)
                .claim("department", department)
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(getSigningKey())
                .compact();
    }

    /** 兼容旧版（带默认值） */
    public String generateToken(Integer staffId, String staffName, Long storeId, String role) {
        return generateToken(staffId, staffName, storeId, role, 1, null, null);
    }

    public Claims getClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public Integer getStaffIdFromToken(String token) {
        Claims claims = getClaims(token);
        return Integer.parseInt(claims.getSubject());
    }

    public Long getStoreIdFromToken(String token) {
        Claims claims = getClaims(token);
        Number storeId = claims.get("storeId", Number.class);
        return storeId != null ? storeId.longValue() : 1L;
    }

    public int getPermissionLevel(String token) {
        Claims claims = getClaims(token);
        Number p = claims.get("permissionLevel", Number.class);
        return p != null ? p.intValue() : 1;
    }

    public boolean validateToken(String token) {
        try {
            getClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.io.Serializable;

@Data
@Entity
@Table(name = "ingredient_master")
@IdClass(Ingredient.IngredientId.class)
public class Ingredient {
    @Data
    public static class IngredientId implements Serializable {
        private String ingredientId;
        private Long storeId;
    }

    @Id
    @Column(name = "ingredient_id", length = 50, nullable = false)
    private String ingredientId;

    @Id
    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "ingredient_name", length = 100, nullable = false)
    private String ingredientName;

    @Column(name = "ingredient_category", length = 50)
    private String ingredientCategory;

    @Column(name = "brand", length = 100)
    private String brand;

    @Column(name = "purchase_unit", length = 20)
    private String purchaseUnit;

    @Column(name = "usage_unit", length = 20)
    private String usageUnit;

    @Column(name = "conversion_rate", precision = 10, scale = 3)
    private BigDecimal conversionRate = BigDecimal.ONE;

    @Column(name = "primary_supplier_id")
    private Integer primarySupplierId;

    @Column(name = "current_stock", precision = 10, scale = 3)
    private BigDecimal currentStock = BigDecimal.ZERO;

    @Column(name = "warning_threshold", precision = 10, scale = 3)
    private BigDecimal warningThreshold = BigDecimal.ZERO;

    @Column(name = "avg_price", precision = 10, scale = 4)
    private java.math.BigDecimal avgPrice = BigDecimal.ZERO;

    @Column(name = "yield_rate", precision = 5, scale = 2)
    private java.math.BigDecimal yieldRate = BigDecimal.ZERO;

    @Column(name = "last_entry_date")
    private java.time.LocalDate lastEntryDate;

    @Column(name = "is_active")
    private Integer isActive = 1;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

package com.youjian.banquet.service;

import com.youjian.banquet.entity.AiChatHistory;
import com.youjian.banquet.repository.AiChatHistoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AiChatHistoryService {
    
    private final AiChatHistoryRepository chatHistoryRepository;
    
    /**
     * 保存对话消息
     */
    public void saveMessage(Long staffId, String role, String content, String imageUrl) {
        if (staffId == null) return;
        
        AiChatHistory history = new AiChatHistory();
        history.setStaffId(staffId);
        history.setRole(role);
        history.setContent(content);
        history.setImageUrl(imageUrl);
        chatHistoryRepository.save(history);
    }
    
    /**
     * 获取用户的对话历史
     */
    public List<AiChatHistory> getChatHistory(Long staffId) {
        if (staffId == null) return List.of();
        return chatHistoryRepository.findByStaffIdOrderByCreatedAtAsc(staffId);
    }
    
    /**
     * 清空用户的对话历史
     */
    public void clearChatHistory(Long staffId) {
        if (staffId == null) return;
        chatHistoryRepository.deleteByStaffId(staffId);
    }
    
    /**
     * 转换为前端格式
     */
    public List<java.util.Map<String, Object>> toFrontendFormat(List<AiChatHistory> histories) {
        return histories.stream()
                .map(h -> {
                    java.util.Map<String, Object> msg = new java.util.HashMap<>();
                    msg.put("role", h.getRole());
                    msg.put("content", h.getContent());
                    if (h.getImageUrl() != null) {
                        msg.put("image", h.getImageUrl());
                    }
                    return msg;
                })
                .collect(Collectors.toList());
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.InventoryLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryLogRepository extends JpaRepository<InventoryLog, Integer> {

    List<InventoryLog> findByStoreIdOrderByLogTimeDesc(Long storeId);

    List<InventoryLog> findByStoreIdAndIngredientIdOrderByLogTimeDesc(Long storeId, String ingredientId);
}

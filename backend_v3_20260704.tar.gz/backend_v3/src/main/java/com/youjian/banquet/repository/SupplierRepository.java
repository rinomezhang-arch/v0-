package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, Integer> {

    List<Supplier> findByStoreIdAndIsActive(Long storeId, Integer isActive);

    List<Supplier> findByStoreId(Long storeId);
}

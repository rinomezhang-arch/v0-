package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {

    Optional<Staff> findByStaffAccount(String staffAccount);

    Optional<Staff> findByStaffAccountAndStoreId(String staffAccount, Long storeId);

    List<Staff> findByStoreId(Long storeId);

    List<Staff> findByStoreIdAndEmploymentStatus(Long storeId, String status);

    List<Staff> findByDepartment(String department);

    Optional<Staff> findByStaffAccountAndStaffPassword(String staffAccount, String staffPassword);

    @Query("SELECT s FROM Staff s WHERE s.staffAccount = :account AND s.role = :role")
    Optional<Staff> findByAccountAndRole(@Param("account") String account, @Param("role") String role);

    @Query("SELECT s FROM Staff s WHERE s.staffAccount = :account")
    Optional<Staff> findByAccount(@Param("account") String account);
}

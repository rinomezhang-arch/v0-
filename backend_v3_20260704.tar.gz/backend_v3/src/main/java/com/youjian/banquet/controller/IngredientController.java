package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.entity.Ingredient.IngredientId;
import com.youjian.banquet.repository.IngredientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/ingredients")
public class IngredientController {

    @Autowired
    private IngredientRepository ingredientRepository;

    @GetMapping
    public Result<List<Ingredient>> getIngredients(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<Ingredient> ingredients = ingredientRepository.findByStoreIdAndIsActive(storeId, 1);
        return Result.success(ingredients);
    }

    @GetMapping("/inventory")
    public Result<List<Ingredient>> getInventory(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        // Return all ingredients including inactive ones for inventory view
        List<Ingredient> ingredients = ingredientRepository.findByStoreId(storeId);
        return Result.success(ingredients);
    }

    @GetMapping("/{id}")
    public Result<Ingredient> getIngredient(@PathVariable String id) {
        Long storeId = StoreContext.get();
        IngredientId ingredientId = new IngredientId();
        ingredientId.setIngredientId(id);
        ingredientId.setStoreId(storeId);

        return ingredientRepository.findById(ingredientId)
                .map(Result::success)
                .orElseGet(() -> Result.error(404, "原料不存在"));
    }

    @PostMapping
    public Result<Ingredient> createIngredient(@RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();

        Ingredient ingredient = new Ingredient();
        ingredient.setStoreId(storeId);

        if (params.get("ingredient_id") != null) {
            ingredient.setIngredientId(params.get("ingredient_id").toString());
        }
        if (params.get("ingredient_name") != null) {
            ingredient.setIngredientName(params.get("ingredient_name").toString());
        }
        if (params.get("ingredient_category") != null) {
            ingredient.setIngredientCategory(params.get("ingredient_category").toString());
        }
        if (params.get("brand") != null) {
            ingredient.setBrand(params.get("brand").toString());
        }
        if (params.get("purchase_unit") != null) {
            ingredient.setPurchaseUnit(params.get("purchase_unit").toString());
        }
        if (params.get("usage_unit") != null) {
            ingredient.setUsageUnit(params.get("usage_unit").toString());
        }
        if (params.get("conversion_rate") != null) {
            ingredient.setConversionRate(new BigDecimal(params.get("conversion_rate").toString()));
        }
        if (params.get("primary_supplier_id") != null) {
            ingredient.setPrimarySupplierId(Integer.parseInt(params.get("primary_supplier_id").toString()));
        }
        if (params.get("current_stock") != null) {
            ingredient.setCurrentStock(new BigDecimal(params.get("current_stock").toString()));
        }
        if (params.get("warning_threshold") != null) {
            ingredient.setWarningThreshold(new BigDecimal(params.get("warning_threshold").toString()));
        }

        ingredient = ingredientRepository.save(ingredient);
        return Result.success(ingredient);
    }

    @PutMapping("/{id}")
    public Result<Ingredient> updateIngredient(@PathVariable String id, @RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();
        IngredientId ingredientId = new IngredientId();
        ingredientId.setIngredientId(id);
        ingredientId.setStoreId(storeId);

        Optional<Ingredient> opt = ingredientRepository.findById(ingredientId);
        if (opt.isEmpty()) {
            return Result.error(404, "原料不存在");
        }

        Ingredient ingredient = opt.get();

        if (params.get("ingredient_name") != null) {
            ingredient.setIngredientName(params.get("ingredient_name").toString());
        }
        if (params.get("ingredient_category") != null) {
            ingredient.setIngredientCategory(params.get("ingredient_category").toString());
        }
        if (params.get("brand") != null) {
            ingredient.setBrand(params.get("brand").toString());
        }
        if (params.get("purchase_unit") != null) {
            ingredient.setPurchaseUnit(params.get("purchase_unit").toString());
        }
        if (params.get("usage_unit") != null) {
            ingredient.setUsageUnit(params.get("usage_unit").toString());
        }
        if (params.get("conversion_rate") != null) {
            ingredient.setConversionRate(new BigDecimal(params.get("conversion_rate").toString()));
        }
        if (params.get("primary_supplier_id") != null) {
            ingredient.setPrimarySupplierId(Integer.parseInt(params.get("primary_supplier_id").toString()));
        }
        if (params.get("current_stock") != null) {
            ingredient.setCurrentStock(new BigDecimal(params.get("current_stock").toString()));
        }
        if (params.get("warning_threshold") != null) {
            ingredient.setWarningThreshold(new BigDecimal(params.get("warning_threshold").toString()));
        }

        ingredient = ingredientRepository.save(ingredient);
        return Result.success(ingredient);
    }

    @DeleteMapping("/{id}")
    public Result<String> deleteIngredient(@PathVariable String id) {
        Long storeId = StoreContext.get();
        IngredientId ingredientId = new IngredientId();
        ingredientId.setIngredientId(id);
        ingredientId.setStoreId(storeId);

        Optional<Ingredient> opt = ingredientRepository.findById(ingredientId);
        if (opt.isEmpty()) {
            return Result.error(404, "原料不存在");
        }

        Ingredient ingredient = opt.get();
        ingredient.setIsActive(0);
        ingredientRepository.save(ingredient);
        return Result.success("删除成功");
    }
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "table_master")
public class TableMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "table_id")
    private Integer tableId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "table_number", length = 10, nullable = false)
    private String tableNumber;

    @Column(name = "table_name", length = 20)
    private String tableName;

    @Column(name = "table_location", length = 50)
    private String tableLocation;

    @Column(name = "table_area", length = 20)
    private String tableArea;

    @Column(name = "table_capacity")
    private Integer tableCapacity = 10;

    @Column(name = "table_type", length = 20)
    private String tableType;

    @Column(name = "table_status", length = 20)
    private String tableStatus = "available";

    @Column(name = "min_capacity")
    private Integer minCapacity = 6;

    @Column(name = "max_capacity")
    private Integer maxCapacity = 12;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @Column(name = "is_active")
    private Integer isActive = 1;

    @Column(name = "remark", columnDefinition = "TEXT")
    private String remark;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @CreationTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Transient
    private Object booking;

    @Transient
    private String status;
}

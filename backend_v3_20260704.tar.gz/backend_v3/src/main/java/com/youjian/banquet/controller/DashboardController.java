package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private BookingService bookingService;

    @GetMapping("/today")
    public Result<Map<String, Object>> getTodayOverview(
            @RequestParam(required = false, defaultValue = "1") Long storeId) { 
        return bookingService.getTodayOverview();
    }

    @GetMapping("/backups")
    public Result<List<Map<String, Object>>> getBackupList() {
        return Result.success(java.util.Collections.<Map<String,Object>>emptyList());
    }
}

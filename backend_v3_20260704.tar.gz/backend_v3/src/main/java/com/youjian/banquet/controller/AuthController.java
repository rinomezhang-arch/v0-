package com.youjian.banquet.controller;

import jakarta.servlet.http.HttpServletResponse;
import com.youjian.banquet.common.Result;
import com.youjian.banquet.service.AuthService;
import com.youjian.banquet.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private StaffRepository staffRepository;

    @PostMapping("/auth/login")
    public Result<Map<String, Object>> login(@RequestBody Map<String, String> params, HttpServletResponse response) {
        String account = params.get("account");
        if (account == null || account.isEmpty()) {
            account = params.get("username");
        }
        String password = params.get("password");
        Result<Map<String, Object>> result = authService.login(account, password);
        if (result.getCode() == 200 && result.getData() != null) {
            String token = (String) result.getData().get("token");
            if (token != null) {
                jakarta.servlet.http.Cookie cookie = new jakarta.servlet.http.Cookie("banquet_token", token);
                cookie.setHttpOnly(true);
                cookie.setSecure(false);
                cookie.setPath("/");
                cookie.setMaxAge(24 * 60 * 60);
                cookie.setAttribute("SameSite", "Lax");
                response.addCookie(cookie);
            }
        }
        return result;
    }

    @GetMapping("/auth/debug/staff/{account}")
    public Object debugStaff(@PathVariable String account) {
        var s1 = staffRepository.findByStaffAccount(account);
        var s2 = staffRepository.findByAccount(account);
        var s3 = staffRepository.findByStaffAccountAndStoreId(account, 1L);
        return Map.of(
            "account", account,
            "findByStaffAccount", s1.isPresent(),
            "findByAccount", s2.isPresent(),
            "findByStaffAccountAndStoreId", s3.isPresent()
        );
    }

    @GetMapping("/auth/me")
    public Result<Map<String, Object>> me(jakarta.servlet.http.HttpServletRequest request) {
        return authService.getCurrentUser(request);
    }

    @PostMapping("/auth/logout")
    public Result<Void> logout(jakarta.servlet.http.HttpServletResponse response) {
        jakarta.servlet.http.Cookie cookie = new jakarta.servlet.http.Cookie("banquet_token", "");
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        cookie.setAttribute("SameSite", "Lax");
        response.addCookie(cookie);
        return Result.success();
    }

    @GetMapping("/stores")
    public Result<java.util.List<Map<String, Object>>> getStores() {
        return authService.getStoreList();
    }
}

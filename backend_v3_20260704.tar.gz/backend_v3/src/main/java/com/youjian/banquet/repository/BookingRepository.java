package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, String> {
    List<Booking> findByStoreIdAndBookingDate(Long storeId, LocalDate bookingDate);

    List<Booking> findByStoreIdAndCustomerId(Long storeId, Integer customerId);

    @Query("SELECT b FROM Booking b WHERE b.storeId = :storeId AND b.bookingDate = :date AND b.bookingStatus != 'cancelled'")
    List<Booking> findActiveBookingsByDate(@Param("storeId") Long storeId, @Param("date") LocalDate date);

    List<Booking> findByStoreIdAndCustomerNameContaining(Long storeId, String customerName);

    List<Booking> findByStoreIdAndCustomerPhoneContaining(Long storeId, String customerPhone);

    List<Booking> findByStoreIdAndCustomerNameContainingAndCustomerPhoneContaining(Long storeId, String customerName, String customerPhone);
}

package com.youjian.banquet.service;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Booking;
import com.youjian.banquet.entity.BookingTable;
import com.youjian.banquet.entity.TableMaster;
import com.youjian.banquet.repository.BookingRepository;
import com.youjian.banquet.repository.BookingTableRepository;
import com.youjian.banquet.repository.TableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TableService {

    @Autowired
    private TableRepository tableRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingTableRepository bookingTableRepository;

    public Result<List<Map<String, Object>>> getTableStatus(String date, String timeType) {
        Long storeId = StoreContext.get();
        LocalDate bookingDate = date != null ? LocalDate.parse(date) : LocalDate.now();

        List<TableMaster> tables = tableRepository.findByStoreIdAndIsActive(storeId, 1);
        List<Booking> bookings = bookingRepository.findActiveBookingsByDate(storeId, bookingDate);

        Map<Integer, Booking> tableBookingMap = new HashMap<>();
        for (Booking booking : bookings) {
            List<BookingTable> bookingTables = bookingTableRepository.findByStoreIdAndBookingId(storeId, booking.getBookingId());
            for (BookingTable bt : bookingTables) {
                tableBookingMap.put(bt.getTableId(), booking);
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (TableMaster table : tables) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("table_id", table.getTableId());
            map.put("table_number", table.getTableNumber());
            map.put("table_name", table.getTableName());
            map.put("table_area", table.getTableArea());
            map.put("table_capacity", table.getTableCapacity());
            map.put("table_type", table.getTableType());

            Booking booking = tableBookingMap.get(table.getTableId());
            if (booking != null) {
                map.put("status", "booked");
                Map<String, Object> bookingInfo = new LinkedHashMap<>();
                bookingInfo.put("booking_id", booking.getBookingId());
                bookingInfo.put("customer_name", booking.getCustomerName());
                bookingInfo.put("customer_phone", booking.getCustomerPhone());
                bookingInfo.put("booking_time", booking.getBookingTime().toString());
                bookingInfo.put("guest_count", booking.getGuestCount());
                bookingInfo.put("table_count", booking.getTableCount());
                bookingInfo.put("spare_tables", booking.getSpareTables());
                bookingInfo.put("banquet_name", booking.getBanquetName());
                bookingInfo.put("occasion_type", booking.getOccasionType());
                bookingInfo.put("deposit", booking.getDeposit());
                bookingInfo.put("booking_status", booking.getBookingStatus());
                bookingInfo.put("remark", booking.getRemark());
                bookingInfo.put("package_name", "");
                bookingInfo.put("total_amount", booking.getTotalAmount());
                bookingInfo.put("created_at", booking.getCreatedAt() != null ? booking.getCreatedAt().toString() : "");
                map.put("booking", bookingInfo);
            } else {
                map.put("status", "available");
                map.put("booking", null);
            }

            result.add(map);
        }

        return Result.success(result);
    }
}

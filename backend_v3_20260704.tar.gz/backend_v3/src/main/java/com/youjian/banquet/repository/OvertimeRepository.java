package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Overtime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface OvertimeRepository extends JpaRepository<Overtime, Integer> {
    List<Overtime> findByStoreIdAndStaffId(Long storeId, Integer staffId);
    List<Overtime> findByStoreIdAndStatus(Long storeId, String status);
    List<Overtime> findByStoreIdAndOvertimeDateBetween(Long storeId, LocalDate startDate, LocalDate endDate);
    List<Overtime> findByStoreId(Long storeId);
}
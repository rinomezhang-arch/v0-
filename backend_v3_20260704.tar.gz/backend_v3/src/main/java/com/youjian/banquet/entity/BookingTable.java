package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "booking_table")
public class BookingTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "table_booking_id")
    private Long tableBookingId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "booking_id", length = 20, nullable = false)
    private String bookingId;

    @Column(name = "table_id", nullable = false)
    private Integer tableId;

    @Column(name = "table_number", length = 10)
    private String tableNumber;

    @Column(name = "table_name", length = 20)
    private String tableName;

    @Column(name = "guest_count")
    private Integer guestCount = 0;

    @Column(name = "package_id", length = 20)
    private String packageId;

    @Column(name = "package_name", length = 100)
    private String packageName;

    @Column(name = "open_table_type", length = 50)
    private String openTableType;

    @Column(name = "table_note", length = 255)
    private String tableNote;

    @Column(name = "booking_date")
    private LocalDate bookingDate;

    @Column(name = "booking_time")
    private LocalTime bookingTime;

    @Column(name = "created_at")
    private java.time.LocalDateTime createdAt;
}

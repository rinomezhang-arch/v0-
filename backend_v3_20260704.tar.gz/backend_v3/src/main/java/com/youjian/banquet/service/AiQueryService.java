package com.youjian.banquet.service;

import com.youjian.banquet.entity.*;
import com.youjian.banquet.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AiQueryService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private TableRepository tableRepository;

    @Autowired
    private DishRepository dishRepository;

    @Autowired
    private IngredientRepository ingredientRepository;

    /**
     * 查询今日预订
     */
    public String queryTodayBookings(Long storeId, int permissionLevel) {
        if (permissionLevel < 2) {
            return "您没有权限查看预订信息";
        }

        LocalDate today = LocalDate.now();
        List<Booking> bookings = bookingRepository.findByStoreIdAndBookingDate(storeId, today);

        if (bookings.isEmpty()) {
            return "今日暂无预订";
        }

        StringBuilder sb = new StringBuilder("今日预订情况（共" + bookings.size() + "条）：\n\n");
        for (Booking b : bookings) {
            sb.append(String.format("• %s - %s\n", b.getBookingTime(), b.getCustomerName()));
            sb.append(String.format("  人数：%d，桌数：%d，状态：%s\n",
                b.getGuestCount(), b.getTableCount(), b.getBookingStatus()));
            if (b.getSpecialRequest() != null && !b.getSpecialRequest().isEmpty()) {
                sb.append(String.format("  特殊要求：%s\n", b.getSpecialRequest()));
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 查询客户信息
     */
    public String queryCustomers(Long storeId, int permissionLevel, String keyword) {
        if (permissionLevel < 3) {
            return "您没有权限查看客户信息";
        }

        List<Customer> customers;
        if (keyword != null && !keyword.isEmpty()) {
            customers = customerRepository.searchByNameOrPhone(storeId, keyword);
        } else {
            customers = customerRepository.findByStoreId(storeId);
        }

        if (customers.isEmpty()) {
            return keyword != null ? "未找到匹配的客户" : "暂无客户记录";
        }

        StringBuilder sb = new StringBuilder("客户信息（共" + customers.size() + "位）：\n\n");
        int count = 0;
        for (Customer c : customers) {
            if (count++ >= 10) {
                sb.append("... 还有 ").append(customers.size() - 10).append(" 位客户\n");
                break;
            }
            sb.append(String.format("• %s（%s）\n", c.getCustomerName(), c.getCustomerPhone()));
            sb.append(String.format("  消费：%d次，累计：%.0f元\n",
                c.getBookingCount() != null ? c.getBookingCount() : 0,
                c.getTotalAmount() != null ? c.getTotalAmount() : BigDecimal.ZERO));
            if (c.getCustomerPreference() != null && !c.getCustomerPreference().isEmpty()) {
                sb.append(String.format("  偏好：%s\n", c.getCustomerPreference()));
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 查询桌位状态
     */
    public String queryTableStatus(Long storeId, int permissionLevel) {
        if (permissionLevel < 1) {
            return "您没有权限查看桌位信息";
        }

        List<TableMaster> tables = tableRepository.findByStoreIdAndIsActive(storeId, 1);

        if (tables.isEmpty()) {
            return "暂无桌位信息";
        }

        Map<String, List<TableMaster>> grouped = tables.stream()
            .collect(Collectors.groupingBy(TableMaster::getTableArea));

        StringBuilder sb = new StringBuilder("桌位状态：\n\n");
        for (Map.Entry<String, List<TableMaster>> entry : grouped.entrySet()) {
            sb.append(String.format("【%s】\n", entry.getKey()));
            for (TableMaster t : entry.getValue()) {
                String status = "available".equals(t.getTableStatus()) ? "✅空闲" : "🔴占用";
                sb.append(String.format("  %s %s（%d人桌）\n",
                    t.getTableName(), status, t.getTableCapacity()));
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 查询菜品信息
     */
    public String queryDishes(Long storeId, int permissionLevel, String category) {
        if (permissionLevel < 1) {
            return "您没有权限查看菜品信息";
        }

        List<DishMaster> dishes = dishRepository.findByStoreIdAndIsActive(storeId, 1);
        
        // 如果有分类，过滤菜品
        if (category != null && !category.isEmpty()) {
            dishes = dishes.stream()
                .filter(d -> category.equals(d.getDishCategory()))
                .collect(Collectors.toList());
        }

        if (dishes.isEmpty()) {
            return "暂无菜品信息";
        }

        StringBuilder sb = new StringBuilder("菜品信息（共" + dishes.size() + "道）：\n\n");
        int count = 0;
        for (DishMaster d : dishes) {
            if (count++ >= 20) {
                sb.append("... 还有 ").append(dishes.size() - 20).append(" 道菜品\n");
                break;
            }
            sb.append(String.format("• %s（%s）\n", d.getDishName(), d.getDishCategory()));
            sb.append(String.format("  价格：%.0f元\n", d.getSalePrice()));
            if (d.getEnglishName() != null && !d.getEnglishName().isEmpty()) {
                sb.append(String.format("  英文名：%s\n", d.getEnglishName()));
            }
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 查询员工信息
     */
    public String queryStaff(Long storeId, int permissionLevel) {
        if (permissionLevel < 4) {
            return "您没有权限查看员工信息";
        }

        List<Staff> staff = staffRepository.findByStoreId(storeId);

        if (staff.isEmpty()) {
            return "暂无员工信息";
        }

        StringBuilder sb = new StringBuilder("员工信息（共" + staff.size() + "人）：\n\n");
        for (Staff s : staff) {
            sb.append(String.format("• %s（%s）\n", s.getStaffName(), s.getStaffAccount()));
            sb.append(String.format("  职位：%s，部门：%s\n",
                s.getStaffPosition(), s.getDepartment()));
            sb.append(String.format("  状态：%s\n\n", s.getEmploymentStatus()));
        }

        return sb.toString();
    }

    /**
     * 查询库存告警
     */
    public String queryInventoryAlerts(Long storeId, int permissionLevel) {
        if (permissionLevel < 3) {
            return "您没有权限查看库存信息";
        }

        List<Ingredient> items = ingredientRepository.findByStoreId(storeId);

        if (items.isEmpty()) {
            return "暂无库存记录";
        }

        List<Ingredient> lowStock = items.stream()
            .filter(i -> i.getCurrentStock() != null && i.getWarningThreshold() != null
                && i.getCurrentStock().compareTo(i.getWarningThreshold()) <= 0)
            .collect(Collectors.toList());

        if (lowStock.isEmpty()) {
            return "库存充足，暂无告警";
        }

        StringBuilder sb = new StringBuilder("库存告警（共" + lowStock.size() + "项）：\n\n");
        for (Ingredient i : lowStock) {
            sb.append(String.format("• %s\n", i.getIngredientName()));
            sb.append(String.format("  当前：%s %s，告警阈值：%s %s\n",
                i.getCurrentStock(), i.getUsageUnit(),
                i.getWarningThreshold(), i.getUsageUnit()));
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 查询天气
     */
    /**
     * 查询天气 - 无权限限制，所有人都能查
     */
    public String queryWeather(String location) {
        try {
            if (location == null || location.isEmpty() || location.contains("天气") || location.contains("气温") || location.contains("下雨") || location.contains("晴天")) {
                location = "宁国";
            }
            
            String encodedLocation = java.net.URLEncoder.encode(location, "UTF-8");
            // 使用java.net.URL + HttpURLConnection，避免URI.create()对%l/%c等格式的误判
            String urlStr = "https://wttr.in/" + encodedLocation + "?format=%l:+%c+%t+%w+%h+%p&lang=zh";
            java.net.URL url = new java.net.URL(urlStr);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            
            int code = conn.getResponseCode();
            if (code == 200) {
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                conn.disconnect();
                return "【天气数据】" + sb.toString().trim() + "\n";
            } else {
                conn.disconnect();
                return "【天气数据】查询失败，状态码：" + code + "\n";
            }
        } catch (Exception e) {
            return "【天气数据】查询异常：" + e.getMessage() + "\n";
        }
    }

    /**
     * 查询地理位置信息 - 无权限限制
     */
    public String queryLocation(String location) {
        try {
            if (location == null || location.isEmpty()) {
                location = "宁国";
            }
            
            String encodedLocation = java.net.URLEncoder.encode(location, "UTF-8");
            String urlStr = "https://wttr.in/" + encodedLocation + "?format=%l:+%c+%t+%w+%h+%p&lang=zh";
            java.net.URL url = new java.net.URL(urlStr);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            
            int code = conn.getResponseCode();
            if (code == 200) {
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                conn.disconnect();
                return "【位置信息】" + sb.toString().trim() + "\n";
            } else {
                conn.disconnect();
                return "【位置信息】查询失败\n";
            }
        } catch (Exception e) {
            return "【位置信息】查询异常：" + e.getMessage() + "\n";
        }
    }

    /**
     * 智能查询 - 根据问题自动判断查询类型
     */
    public String smartQuery(String question, Long storeId, int permissionLevel) {
        question = question.toLowerCase();

        // 排除日期/时间类问题（不要触发预订查询）
        String[] excludePatterns = {"周几", "星期几", "几号", "什么日子", "今天星期", "今天周", "礼拜几", "几月几号", "今天日期"};
        for (String p : excludePatterns) {
            if (question.contains(p)) return null;
        }

        // 预订相关（"今天/今日"必须和预订/宴会/包间等词一起出现才触发）
        if (question.contains("预订") || question.contains("预定") || question.contains("订餐") || question.contains("宴会")) {
            return queryTodayBookings(storeId, permissionLevel);
        }
        if ((question.contains("今天") || question.contains("今日")) 
            && (question.contains("包间") || question.contains("包厢") || question.contains("宴"))) {
            return queryTodayBookings(storeId, permissionLevel);
        }

        if (question.contains("客户") || question.contains("顾客") || question.contains("会员")) {
            String keyword = extractKeyword(question, "客户", "顾客", "会员");
            return queryCustomers(storeId, permissionLevel, keyword);
        }

        if (question.contains("桌位") || question.contains("桌子") || question.contains("空桌")) {
            return queryTableStatus(storeId, permissionLevel);
        }

        if (question.contains("菜品") || question.contains("菜单") || question.contains("菜")) {
            String category = extractKeyword(question, "菜品", "菜单");
            return queryDishes(storeId, permissionLevel, category);
        }

        if (question.contains("员工") || question.contains("人员") || question.contains("同事")) {
            return queryStaff(storeId, permissionLevel);
        }

        if (question.contains("库存") || question.contains("告警") || question.contains("不足")) {
            return queryInventoryAlerts(storeId, permissionLevel);
        }

        // 天气查询 - 无权限限制
        if (question.contains("天气") || question.contains("气温") || question.contains("下雨") || question.contains("晴天")) {
            String location = extractLocation(question);
            return queryWeather(location);
        }

        // 地理位置查询 - 无权限限制
        if (question.contains("位置") || question.contains("地址") || question.contains("在哪") || question.contains("在哪里")) {
            String location = extractLocation(question);
            return queryLocation(location);
        }

        return null; // 无法识别，交给AI处理
    }

    private String extractKeyword(String question, String... keywords) {
        for (String keyword : keywords) {
            int idx = question.indexOf(keyword);
            if (idx >= 0 && idx + keyword.length() < question.length()) {
                return question.substring(idx + keyword.length()).trim();
            }
        }
        return null;
    }

    private String extractLocation(String question) {
        // 尝试提取城市名
        String[] cities = {"北京", "上海", "广州", "深圳", "杭州", "成都", "武汉", "西安", "南京", "重庆", "天津", "苏州", "无锡", "常州", "合肥", "长沙", "郑州", "青岛", "大连", "厦门", "宁波", "温州", "福州", "济南", "石家庄", "太原", "哈尔滨", "长春", "沈阳", "昆明", "贵阳", "南宁", "海口", "兰州", "银川", "西宁", "乌鲁木齐", "拉萨", "呼和浩特", "南昌"};
        
        for (String city : cities) {
            if (question.contains(city)) {
                return city;
            }
        }
        
        // 默认返回宁国
        return "宁国";
    }
}

package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.AiMemory;
import com.youjian.banquet.entity.Staff;
import com.youjian.banquet.repository.StaffRepository;
import com.youjian.banquet.service.AiMemoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai/memory")
@RequiredArgsConstructor
public class AiMemoryController {
    
    private final AiMemoryService memoryService;
    private final StaffRepository staffRepository;
    
    /**
     * 获取当前用户的记忆列表
     */
    @GetMapping("/list")
    public Result<List<AiMemory>> getMemories(@RequestAttribute("staffId") Long staffId) {
        return Result.success(memoryService.getUserMemories(staffId));
    }
    
    /**
     * 添加记忆（所有登录用户可用）
     */
    @PostMapping("/add")
    public Result<AiMemory> addMemory(@RequestAttribute("staffId") Long staffId,
                                      @RequestBody Map<String, String> request) {
        if (staffId == null) {
            return Result.error(401, "请先登录");
        }
        
        String content = request.get("content");
        if (content == null || content.trim().isEmpty()) {
            return Result.error(400, "记忆内容不能为空");
        }
        
        AiMemory memory = memoryService.addMemory(staffId, content);
        return Result.success(memory);
    }
    
    /**
     * 删除记忆（所有登录用户可用，只能删除自己的）
     */
    @DeleteMapping("/delete/{id}")
    public Result<Void> deleteMemory(@RequestAttribute("staffId") Long staffId,
                                     @PathVariable Long id) {
        if (staffId == null) {
            return Result.error(401, "请先登录");
        }
        
        memoryService.deleteMemory(staffId, id);
        return Result.success(null);
    }
}

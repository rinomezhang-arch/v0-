package com.youjian.banquet.repository;

import com.youjian.banquet.entity.DishMaster;
import com.youjian.banquet.entity.DishMaster.DishMasterId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DishRepository extends JpaRepository<DishMaster, DishMasterId> {

    List<DishMaster> findByStoreIdAndIsActive(Long storeId, Integer isActive);

    List<DishMaster> findByStoreIdAndIsActiveAndUsageType(Long storeId, Integer isActive, String usageType);

    @Query("SELECT d FROM DishMaster d WHERE d.storeId = :storeId AND d.isActive = 1 AND d.dishName LIKE %:q%")
    List<DishMaster> searchByStoreIdAndName(@Param("storeId") Long storeId, @Param("q") String q);

    @Query("SELECT d FROM DishMaster d WHERE d.storeId = :storeId AND d.isActive = 1 AND d.usageType = :usageType AND d.dishName LIKE %:q%")
    List<DishMaster> searchByStoreIdAndUsageTypeAndName(@Param("storeId") Long storeId, @Param("usageType") String usageType, @Param("q") String q);

    @Query("SELECT DISTINCT d.dishCategory FROM DishMaster d WHERE d.storeId = :storeId AND d.isActive = 1 AND d.dishCategory IS NOT NULL")
    List<String> findDistinctCategoriesByStoreId(@Param("storeId") Long storeId);
}

package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.entity.Ingredient.IngredientId;
import com.youjian.banquet.entity.InventoryLog;
import com.youjian.banquet.repository.IngredientRepository;
import com.youjian.banquet.repository.InventoryLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryLogRepository inventoryLogRepository;

    @Autowired
    private IngredientRepository ingredientRepository;

    @PostMapping("/in")
    public Result<InventoryLog> stockIn(@RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();

        if (params.get("ingredient_id") == null) {
            return Result.error("原料ID不能为空");
        }
        if (params.get("log_quantity") == null) {
            return Result.error("入库数量不能为空");
        }

        String ingredientId = params.get("ingredient_id").toString();
        BigDecimal quantity = new BigDecimal(params.get("log_quantity").toString());

        // Create inventory log
        InventoryLog log = new InventoryLog();
        log.setStoreId(storeId);
        log.setIngredientId(ingredientId);
        log.setLogType("in");
        log.setLogQuantity(quantity);

        if (params.get("related_order_id") != null) {
            log.setRelatedOrderId(params.get("related_order_id").toString());
        }
        if (params.get("operator_id") != null) {
            log.setOperatorId(Integer.parseInt(params.get("operator_id").toString()));
        }
        if (params.get("note") != null) {
            log.setNote(params.get("note").toString());
        }

        log = inventoryLogRepository.save(log);

        // Update ingredient stock
        IngredientId id = new IngredientId();
        id.setIngredientId(ingredientId);
        id.setStoreId(storeId);

        Optional<Ingredient> opt = ingredientRepository.findById(id);
        if (opt.isPresent()) {
            Ingredient ingredient = opt.get();
            BigDecimal currentStock = ingredient.getCurrentStock() != null
                    ? ingredient.getCurrentStock() : BigDecimal.ZERO;
            BigDecimal newStock = currentStock.add(quantity);
            ingredient.setCurrentStock(newStock);
            ingredientRepository.save(ingredient);
            log.setStockAfter(newStock);
            inventoryLogRepository.save(log);
        }

        return Result.success(log);
    }

    @PostMapping("/out")
    public Result<InventoryLog> stockOut(@RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();

        if (params.get("ingredient_id") == null) {
            return Result.error("原料ID不能为空");
        }
        if (params.get("log_quantity") == null) {
            return Result.error("出库数量不能为空");
        }

        String ingredientId = params.get("ingredient_id").toString();
        BigDecimal quantity = new BigDecimal(params.get("log_quantity").toString());

        // Check stock availability
        IngredientId id = new IngredientId();
        id.setIngredientId(ingredientId);
        id.setStoreId(storeId);

        BigDecimal newStockOut = BigDecimal.ZERO;
        Optional<Ingredient> opt = ingredientRepository.findById(id);
        if (opt.isPresent()) {
            Ingredient ingredient = opt.get();
            BigDecimal currentStock = ingredient.getCurrentStock() != null
                    ? ingredient.getCurrentStock() : BigDecimal.ZERO;
            if (currentStock.compareTo(quantity) < 0) {
                return Result.error("库存不足，当前库存: " + currentStock);
            }
            newStockOut = currentStock.subtract(quantity);
            ingredient.setCurrentStock(newStockOut);
            ingredientRepository.save(ingredient);
        }

        // Create inventory log
        InventoryLog log = new InventoryLog();
        log.setStoreId(storeId);
        log.setIngredientId(ingredientId);
        log.setLogType("out");
        log.setLogQuantity(quantity);
        log.setStockAfter(newStockOut);

        if (params.get("related_order_id") != null) {
            log.setRelatedOrderId(params.get("related_order_id").toString());
        }
        if (params.get("operator_id") != null) {
            log.setOperatorId(Integer.parseInt(params.get("operator_id").toString()));
        }
        if (params.get("note") != null) {
            log.setNote(params.get("note").toString());
        }

        log = inventoryLogRepository.save(log);
        return Result.success(log);
    }

    @GetMapping("/logs")
    public Result<List<InventoryLog>> getLogs(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<InventoryLog> logs = inventoryLogRepository.findByStoreIdOrderByLogTimeDesc(storeId);
        return Result.success(logs);
    }

    @GetMapping("/warnings")
    public Result<List<Ingredient>> getWarnings(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<Ingredient> warnings = ingredientRepository.findLowStockWarnings(storeId);
        return Result.success(warnings);
    }
}

package com.youjian.banquet.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class KitchenService {

    private static final Logger log = LoggerFactory.getLogger(KitchenService.class);
    private final JdbcTemplate db;

    public KitchenService(JdbcTemplate db) { this.db = db; }

    public Map<String, Object> getBoard(String date) {
        if (date == null || date.isEmpty()) {
            date = LocalDate.now().toString();
        }

        // 查询今日宴会（只用 booking_master + booking_dish_detail）
        String bookingSql = """
            SELECT booking_id, banquet_name, booking_date, booking_time,
                   guest_count, booking_status, occasion_type, remark
            FROM booking_master
            WHERE store_id = 1 AND booking_date = ?
            ORDER BY booking_time ASC
            """;

        List<Map<String, Object>> bookings = db.queryForList(bookingSql, date);

        // 从 orders 表单独查厨房状态
        String orderSql = """
            SELECT table_id, kitchen_status, kitchen_priority,
                   kitchen_started_at, kitchen_finished_at
            FROM orders
            WHERE table_id IS NOT NULL
            """;
        Map<String, Map<String, Object>> orderMap = new LinkedHashMap<>();
        for (Map<String, Object> row : db.queryForList(orderSql)) {
            orderMap.put((String) row.get("table_id"), row);
        }

        // 汇总
        Map<String, Integer> stats = new LinkedHashMap<>() {{
            put("total", 0); put("pending", 0); put("备菜中", 0);
            put("已完成", 0); put("已出品", 0);
        }};

        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<String, Object> b : bookings) {
            String bid = (String) b.get("booking_id");

            String dishSql = """
                SELECT bd.dish_booking_id, bd.dish_id, bd.dish_name,
                       bd.dish_quantity, bd.dish_note, bd.unit_price, bd.subtotal,
                       bd.kitchen_status, bd.kitchen_station, bd.kitchen_note,
                       bd.kitchen_started_at, bd.kitchen_done_at,
                       COALESCE(d.category_id, '') as category_id
                FROM booking_dish_detail bd
                LEFT JOIN dishes d ON bd.dish_id COLLATE utf8mb4_0900_ai_ci = d.id
                WHERE bd.booking_id = ? AND bd.store_id = 1
                ORDER BY bd.dish_order ASC
                """;

            List<Map<String, Object>> dishes = db.queryForList(dishSql, bid);
            List<Map<String, Object>> dishList = new ArrayList<>();

            for (Map<String, Object> d : dishes) {
                String kstatus = (String) d.getOrDefault("kitchen_status", "pending");
                stats.merge(kstatus, 1, Integer::sum);
                stats.merge("total", 1, Integer::sum);

                dishList.add(Map.of(
                    "dishBookingId", d.get("dish_booking_id"),
                    "dishId", d.get("dish_id"),
                    "dishName", d.getOrDefault("dish_name", ""),
                    "quantity", d.getOrDefault("dish_quantity", 0),
                    "dishNote", d.getOrDefault("dish_note", ""),
                    "kitchenStatus", kstatus,
                    "kitchenStation", d.getOrDefault("kitchen_station", ""),
                    "kitchenNote", d.getOrDefault("kitchen_note", ""),
                    "categoryId", d.getOrDefault("category_id", "")
                ));
            }

            Map<String, Object> ord = orderMap.getOrDefault(bid, Map.of());
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("bookingId", bid);
            item.put("banquetName", b.getOrDefault("banquet_name", "未命名"));
            item.put("bookingDate", b.get("booking_date").toString());
            Object bt = b.get("booking_time");
            item.put("bookingTime", bt != null ? bt.toString().substring(0, Math.min(bt.toString().length(), 5)) : "");
            item.put("guestCount", b.getOrDefault("guest_count", 0));
            item.put("occasionType", b.getOrDefault("occasion_type", ""));
            item.put("kitchenStatus", ord.getOrDefault("kitchen_status", "pending"));
            item.put("kitchenPriority", ord.getOrDefault("kitchen_priority", 0));
            item.put("dishes", dishList);
            item.put("dishCount", dishList.size());
            item.put("doneCount", (int) dishList.stream()
                .filter(x -> "已完成".equals(x.get("kitchenStatus")) || "已出品".equals(x.get("kitchenStatus")))
                .count());

            result.add(item);
        }

        Map<String, Object> r = new LinkedHashMap<>();
        r.put("result", "ok");
        r.put("data", Map.of("date", date, "bookings", result, "summary", stats));
        return r;
    }

    public Map<String, Object> updateOrderStatus(String bookingId, String status) {
        // 检查 orders 是否存在
        Integer count = db.queryForObject(
            "SELECT COUNT(*) FROM orders WHERE table_id = ?", Integer.class, bookingId);
        if (count == null || count == 0) {
            db.update("INSERT INTO orders (id, table_id, dishes, kitchen_status, kitchen_priority, created_at) VALUES (?, ?, '[]', ?, 0, ?)",
                "ord_" + System.currentTimeMillis(), bookingId, status, System.currentTimeMillis());
        } else {
            db.update("UPDATE orders SET kitchen_status = ?, kitchen_started_at = CASE WHEN ? = '备菜中' THEN UNIX_TIMESTAMP() * 1000 ELSE kitchen_started_at END, kitchen_finished_at = CASE WHEN ? IN ('已完成','已出品') THEN UNIX_TIMESTAMP() * 1000 ELSE kitchen_finished_at END WHERE table_id COLLATE utf8mb4_0900_ai_ci = ?",
                status, status, status, bookingId);
        }

        if ("已出品".equals(status)) {
            db.update("UPDATE booking_dish_detail SET kitchen_status = '已出品', kitchen_done_at = UNIX_TIMESTAMP() * 1000 WHERE booking_id = ? AND kitchen_status != '已出品' AND kitchen_status != '已出品'",
                bookingId);
        }

        db.update("INSERT INTO kitchen_log (store_id, action, target_type, booking_id, note) VALUES (1, ?, 'booking', ?, ?)",
            status, bookingId, "状态: " + status);

        return Map.of("result", "ok");
    }

    public Map<String, Object> updateDishStatus(Long dishBookingId, String status, String station, String note) {
        StringBuilder sql = new StringBuilder("UPDATE booking_dish_detail SET kitchen_status = ?");
        List<Object> params = new ArrayList<>();
        params.add(status);

        if (station != null && !station.isEmpty()) {
            sql.append(", kitchen_station = ?");
            params.add(station);
        }
        if (note != null && !note.isEmpty()) {
            sql.append(", kitchen_note = ?");
            params.add(note);
        }
        if ("备菜中".equals(status)) {
            sql.append(", kitchen_started_at = UNIX_TIMESTAMP() * 1000");
        }
        if ("已完成".equals(status) || "已出品".equals(status)) {
            sql.append(", kitchen_done_at = UNIX_TIMESTAMP() * 1000");
        }
        sql.append(" WHERE dish_booking_id = ?");
        params.add(dishBookingId);

        db.update(sql.toString(), params.toArray());

        try {
            String dishName = db.queryForObject(
                "SELECT dish_name FROM booking_dish_detail WHERE dish_booking_id = ?", String.class, dishBookingId);
            db.update("INSERT INTO kitchen_log (store_id, action, target_type, dish_id, dish_name, note) VALUES (1, ?, 'dish', ?, ?, ?)",
                status, dishBookingId.toString(), dishName, note != null ? note : "");
        } catch (Exception e) { log.warn("日志写入失败: {}", e.getMessage()); }

        return Map.of("result", "ok");
    }

    public Map<String, Object> getRecentLog(int limit) {
        List<Map<String, Object>> logs = db.queryForList(
            "SELECT * FROM kitchen_log WHERE store_id = 1 ORDER BY created_at DESC LIMIT ?", limit);
        return Map.of("result", "ok", "data", logs);
    }
}

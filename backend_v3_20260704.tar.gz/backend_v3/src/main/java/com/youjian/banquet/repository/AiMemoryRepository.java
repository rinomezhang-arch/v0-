package com.youjian.banquet.repository;

import com.youjian.banquet.entity.AiMemory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AiMemoryRepository extends JpaRepository<AiMemory, Long> {
    List<AiMemory> findByUserIdOrderByCreatedAtDesc(Long userId);
    void deleteByUserIdAndId(Long userId, Long id);
}

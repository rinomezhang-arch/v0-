package com.youjian.banquet.service;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.entity.*;
import com.youjian.banquet.repository.*;
import com.youjian.banquet.config.StoreContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HrService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private LeaveRepository leaveRepository;

    @Autowired
    private OvertimeRepository overtimeRepository;

    @Autowired
    private ScheduleRepository scheduleRepository;

    private Long getStoreId() {
        return StoreContext.get();
    }

    private List<Staff> getStaffByStoreId() {
        return staffRepository.findAll().stream()
                .filter(s -> s.getStoreId() != null && s.getStoreId().equals(getStoreId()))
                .collect(Collectors.toList());
    }

    // ===== 部门管理 =====
    public Result<List<Department>> listDepartments() {
        return Result.success(departmentRepository.findByStoreIdAndStatus(getStoreId(), "active"));
    }

    public Result<Department> getDepartment(Integer id) {
        return departmentRepository.findById(id)
                .map(Result::success)
                .orElse(Result.error("部门不存在"));
    }

    @Transactional
    public Result<Department> createDepartment(Department dept) {
        if (departmentRepository.existsByDeptNameAndStoreId(dept.getDeptName(), getStoreId())) {
            return Result.error("部门名称已存在");
        }
        dept.setStoreId(getStoreId());
        return Result.success(departmentRepository.save(dept));
    }

    @Transactional
    public Result<Department> updateDepartment(Integer id, Department dept) {
        return departmentRepository.findById(id)
                .map(existing -> {
                    existing.setDeptName(dept.getDeptName());
                    existing.setDeptCode(dept.getDeptCode());
                    existing.setParentId(dept.getParentId());
                    existing.setSortOrder(dept.getSortOrder());
                    existing.setStatus(dept.getStatus());
                    existing.setDescription(dept.getDescription());
                    return Result.success(departmentRepository.save(existing));
                })
                .orElse(Result.error("部门不存在"));
    }

    @Transactional
    public Result<Void> deleteDepartment(Integer id) {
        if (!departmentRepository.existsById(id)) {
            return Result.error("部门不存在");
        }
        departmentRepository.deleteById(id);
        return Result.success();
    }

    // ===== 员工管理 =====
    public Result<List<Map<String, Object>>> listStaffWithDept() {
        List<Staff> staffList = getStaffByStoreId();
        Map<Integer, String> deptMap = departmentRepository.findByStoreId(getStoreId())
                .stream().collect(Collectors.toMap(Department::getDeptId, Department::getDeptName));
        
        List<Map<String, Object>> result = staffList.stream().map(s -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("staffId", s.getStaffId());
            map.put("staffName", s.getStaffName());
            map.put("staffAccount", s.getStaffAccount());
            map.put("staffPassword", s.getStaffPassword());
            map.put("staffGender", s.getStaffGender());
            map.put("staffAge", s.getStaffAge());
            map.put("staffPhone", s.getStaffPhone());
            map.put("staffPosition", s.getStaffPosition());
            map.put("department", s.getDepartment());
            map.put("departmentName", deptMap.get(s.getStaffId()));
            map.put("role", s.getRole());
            map.put("employmentStatus", s.getEmploymentStatus());
            map.put("createdAt", s.getCreatedAt());
            map.put("updatedAt", s.getUpdatedAt());
            return map;
        }).collect(Collectors.toList());
        return Result.success(result);
    }

    public Map<String, Object> getStaffStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        Long storeId = getStoreId();
        
        List<Staff> staffList = getStaffByStoreId();
        long total = staffList.size();
        long active = staffList.stream().filter(s -> "active".equals(s.getEmploymentStatus())).count();
        long inactive = total - active;
        
        Map<String, Long> deptCounts = staffList.stream()
                .filter(s -> s.getDepartment() != null && !s.getDepartment().isEmpty())
                .collect(Collectors.groupingBy(Staff::getDepartment, Collectors.counting()));
        
        long male = staffList.stream()
                .filter(s -> "男".equals(s.getStaffGender())).count();
        long female = total - male;
        
        stats.put("total", total);
        stats.put("active", active);
        stats.put("inactive", inactive);
        stats.put("male", male);
        stats.put("female", female);
        stats.put("deptCounts", deptCounts);
        
        return stats;
    }

    // ===== 考勤管理 =====
    public Result<List<Map<String, Object>>> listAttendance(String startDate, String endDate) {
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);
        
        List<Attendance> records = attendanceRepository.findByStoreIdAndAttendanceDateBetween(getStoreId(), start, end);
        Map<Integer, String> staffMap = getStaffByStoreId().stream()
                .collect(Collectors.toMap(Staff::getStaffId, Staff::getStaffName));
        
        List<Map<String, Object>> result = records.stream().map(a -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("attendanceId", a.getAttendanceId());
            map.put("staffId", a.getStaffId());
            map.put("staffName", staffMap.get(a.getStaffId()));
            map.put("attendanceDate", a.getAttendanceDate());
            map.put("clockIn", a.getClockIn());
            map.put("clockOut", a.getClockOut());
            map.put("status", a.getStatus());
            map.put("lateMinutes", a.getLateMinutes());
            map.put("earlyLeaveMinutes", a.getEarlyLeaveMinutes());
            map.put("absent", a.getAbsent());
            map.put("workHours", a.getWorkHours());
            map.put("remark", a.getRemark());
            return map;
        }).collect(Collectors.toList());
        return Result.success(result);
    }

    @Transactional
    public Result<Attendance> createAttendance(Attendance attendance) {
        attendance.setStoreId(getStoreId());
        return Result.success(attendanceRepository.save(attendance));
    }

    @Transactional
    public Result<Attendance> updateAttendance(Integer id, Attendance attendance) {
        return attendanceRepository.findById(id)
                .map(existing -> {
                    existing.setClockIn(attendance.getClockIn());
                    existing.setClockOut(attendance.getClockOut());
                    existing.setStatus(attendance.getStatus());
                    existing.setLateMinutes(attendance.getLateMinutes());
                    existing.setEarlyLeaveMinutes(attendance.getEarlyLeaveMinutes());
                    existing.setAbsent(attendance.getAbsent());
                    existing.setWorkHours(attendance.getWorkHours());
                    existing.setRemark(attendance.getRemark());
                    return Result.success(attendanceRepository.save(existing));
                })
                .orElse(Result.error("考勤记录不存在"));
    }

    // ===== 请假管理 =====
    public Result<List<Map<String, Object>>> listLeave(String status) {
        List<Leave> leaves;
        if (status != null && !status.isEmpty()) {
            leaves = leaveRepository.findByStoreIdAndStatus(getStoreId(), status);
        } else {
            leaves = leaveRepository.findByStoreId(getStoreId());
        }
        
        Map<Integer, String> staffMap = getStaffByStoreId().stream()
                .collect(Collectors.toMap(Staff::getStaffId, Staff::getStaffName));
        
        List<Map<String, Object>> result = leaves.stream().map(l -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("leaveId", l.getLeaveId());
            map.put("staffId", l.getStaffId());
            map.put("staffName", staffMap.get(l.getStaffId()));
            map.put("leaveType", l.getLeaveType());
            map.put("startDate", l.getStartDate());
            map.put("endDate", l.getEndDate());
            map.put("days", l.getDays());
            map.put("status", l.getStatus());
            map.put("reason", l.getReason());
            map.put("approverId", l.getApproverId());
            map.put("approveTime", l.getApproveTime());
            map.put("approveRemark", l.getApproveRemark());
            map.put("createdAt", l.getCreatedAt());
            return map;
        }).collect(Collectors.toList());
        return Result.success(result);
    }

    @Transactional
    public Result<Leave> createLeave(Leave leave) {
        leave.setStoreId(getStoreId());
        leave.setDays(calculateLeaveDays(leave.getStartDate(), leave.getEndDate()));
        return Result.success(leaveRepository.save(leave));
    }

    @Transactional
    public Result<Leave> approveLeave(Integer id, Integer approverId, String status, String remark) {
        return leaveRepository.findById(id)
                .map(leave -> {
                    leave.setStatus(status);
                    leave.setApproverId(approverId);
                    leave.setApproveTime(LocalDateTime.now());
                    leave.setApproveRemark(remark);
                    return Result.success(leaveRepository.save(leave));
                })
                .orElse(Result.error("请假记录不存在"));
    }

    private Double calculateLeaveDays(LocalDate start, LocalDate end) {
        return ChronoUnit.DAYS.between(start, end) + 1.0;
    }

    // ===== 加班管理 =====
    public Result<List<Map<String, Object>>> listOvertime(String status) {
        List<Overtime> overtimes;
        if (status != null && !status.isEmpty()) {
            overtimes = overtimeRepository.findByStoreIdAndStatus(getStoreId(), status);
        } else {
            overtimes = overtimeRepository.findByStoreId(getStoreId());
        }
        
        Map<Integer, String> staffMap = getStaffByStoreId().stream()
                .collect(Collectors.toMap(Staff::getStaffId, Staff::getStaffName));
        
        List<Map<String, Object>> result = overtimes.stream().map(o -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("overtimeId", o.getOvertimeId());
            map.put("staffId", o.getStaffId());
            map.put("staffName", staffMap.get(o.getStaffId()));
            map.put("overtimeDate", o.getOvertimeDate());
            map.put("startTime", o.getStartTime());
            map.put("endTime", o.getEndTime());
            map.put("hours", o.getHours());
            map.put("status", o.getStatus());
            map.put("reason", o.getReason());
            map.put("approverId", o.getApproverId());
            map.put("approveTime", o.getApproveTime());
            map.put("approveRemark", o.getApproveRemark());
            map.put("createdAt", o.getCreatedAt());
            return map;
        }).collect(Collectors.toList());
        return Result.success(result);
    }

    @Transactional
    public Result<Overtime> createOvertime(Overtime overtime) {
        overtime.setStoreId(getStoreId());
        if (overtime.getStartTime() != null && overtime.getEndTime() != null) {
            overtime.setHours(ChronoUnit.MINUTES.between(overtime.getStartTime(), overtime.getEndTime()) / 60.0);
        }
        return Result.success(overtimeRepository.save(overtime));
    }

    @Transactional
    public Result<Overtime> approveOvertime(Integer id, Integer approverId, String status, String remark) {
        return overtimeRepository.findById(id)
                .map(overtime -> {
                    overtime.setStatus(status);
                    overtime.setApproverId(approverId);
                    overtime.setApproveTime(LocalDateTime.now());
                    overtime.setApproveRemark(remark);
                    return Result.success(overtimeRepository.save(overtime));
                })
                .orElse(Result.error("加班记录不存在"));
    }

    // ===== 排班管理 =====
    public Result<List<Map<String, Object>>> listSchedule(String date) {
        LocalDate scheduleDate = LocalDate.parse(date);
        List<Schedule> schedules = scheduleRepository.findByStoreIdAndScheduleDate(getStoreId(), scheduleDate);
        
        Map<Integer, String> staffMap = getStaffByStoreId().stream()
                .collect(Collectors.toMap(Staff::getStaffId, Staff::getStaffName));
        
        List<Map<String, Object>> result = schedules.stream().map(s -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("scheduleId", s.getScheduleId());
            map.put("staffId", s.getStaffId());
            map.put("staffName", staffMap.get(s.getStaffId()));
            map.put("scheduleDate", s.getScheduleDate());
            map.put("shiftType", s.getShiftType());
            map.put("startTime", s.getStartTime());
            map.put("endTime", s.getEndTime());
            map.put("status", s.getStatus());
            map.put("remark", s.getRemark());
            return map;
        }).collect(Collectors.toList());
        return Result.success(result);
    }

    @Transactional
    public Result<Schedule> createSchedule(Schedule schedule) {
        schedule.setStoreId(getStoreId());
        return Result.success(scheduleRepository.save(schedule));
    }

    @Transactional
    public Result<Void> batchCreateSchedule(List<Schedule> schedules) {
        schedules.forEach(s -> s.setStoreId(getStoreId()));
        scheduleRepository.saveAll(schedules);
        return Result.success();
    }

    @Transactional
    public Result<Void> deleteSchedule(Integer id) {
        scheduleRepository.deleteById(id);
        return Result.success();
    }

    // ===== 报表统计 =====
    public Map<String, Object> getHrReport(String startDate, String endDate) {
        Map<String, Object> report = new LinkedHashMap<>();
        Long storeId = getStoreId();
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        Map<String, Object> overview = new LinkedHashMap<>();
        List<Staff> staffList = getStaffByStoreId();
        long totalStaff = staffList.size();
        long activeStaff = staffList.stream().filter(s -> "active".equals(s.getEmploymentStatus())).count();
        
        List<Attendance> attendances = attendanceRepository.findByStoreIdAndAttendanceDateBetween(storeId, start, end);
        long attended = attendances.stream().filter(a -> !a.getAbsent()).count();
        long lateCount = attendances.stream().filter(a -> "late".equals(a.getStatus())).count();
        long absentCount = attendances.stream().filter(a -> a.getAbsent()).count();
        
        double attendanceRate = totalStaff > 0 ? (attended * 100.0) / (totalStaff * ChronoUnit.DAYS.between(start, end) + 1) : 0;
        
        overview.put("totalStaff", totalStaff);
        overview.put("activeStaff", activeStaff);
        overview.put("attendanceRate", Math.round(attendanceRate * 100.0) / 100.0);
        overview.put("lateCount", lateCount);
        overview.put("absentCount", absentCount);
        report.put("overview", overview);

        Map<String, Object> structure = new LinkedHashMap<>();
        Map<String, Long> deptDist = staffList.stream()
                .filter(s -> s.getDepartment() != null && !s.getDepartment().isEmpty())
                .collect(Collectors.groupingBy(Staff::getDepartment, Collectors.counting()));
        structure.put("departmentDistribution", deptDist);
        
        long male = staffList.stream()
                .filter(s -> "男".equals(s.getStaffGender())).count();
        long female = totalStaff - male;
        Map<String, Long> genderDist = new LinkedHashMap<>();
        genderDist.put("男", male);
        genderDist.put("女", female);
        structure.put("genderDistribution", genderDist);
        report.put("structure", structure);

        Map<String, Object> attendanceAnalysis = new LinkedHashMap<>();
        List<Map<String, Object>> dailyAttendance = new ArrayList<>();
        for (LocalDate d = start; !d.isAfter(end); d = d.plusDays(1)) {
            LocalDate currentDate = d;
            Map<String, Object> day = new LinkedHashMap<>();
            day.put("date", d.toString());
            long dayAttended = attendances.stream()
                    .filter(a -> a.getAttendanceDate().equals(currentDate) && !a.getAbsent()).count();
            day.put("attended", dayAttended);
            day.put("total", totalStaff);
            day.put("rate", totalStaff > 0 ? Math.round(dayAttended * 10000.0 / totalStaff) / 100.0 : 0);
            dailyAttendance.add(day);
        }
        attendanceAnalysis.put("dailyAttendance", dailyAttendance);
        report.put("attendanceAnalysis", attendanceAnalysis);

        List<Leave> leaves = leaveRepository.findByStoreIdAndStartDateBetween(storeId, start, end);
        Map<String, Long> leaveTypeCount = leaves.stream()
                .collect(Collectors.groupingBy(Leave::getLeaveType, Collectors.counting()));
        report.put("leaveAnalysis", leaveTypeCount);

        List<Overtime> overtimes = overtimeRepository.findByStoreIdAndOvertimeDateBetween(storeId, start, end);
        double totalOvertimeHours = overtimes.stream()
                .filter(o -> "approved".equals(o.getStatus()))
                .mapToDouble(Overtime::getHours).sum();
        report.put("totalOvertimeHours", Math.round(totalOvertimeHours * 100.0) / 100.0);

        return report;
    }

    // ===== 员工 CRUD =====
    public Result<Map<String, Object>> createStaff(Map<String, Object> params) {
        Staff s = new Staff();
        s.setStoreId(((Number) params.getOrDefault("storeId", 1L)).longValue());
        s.setStaffName((String) params.get("staffName"));
        s.setStaffAccount((String) params.get("staffAccount"));
        String pwd = (String) params.getOrDefault("staffPassword", "123456");
        if (pwd != null && !pwd.isEmpty()) {
            s.setStaffPassword(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode(pwd));
        }
        s.setStaffPhone((String) params.get("staffPhone"));
        s.setStaffGender((String) params.get("staffGender"));
        s.setStaffAge(params.get("staffAge") != null ? ((Number) params.get("staffAge")).intValue() : null);
        s.setStaffPosition((String) params.get("staffPosition"));
        s.setDepartment((String) params.get("department"));
        s.setRole((String) params.getOrDefault("role", "staff"));
        s.setPermissionLevel(((Number) params.getOrDefault("permissionLevel", 1)).intValue());
        s.setEmploymentStatus((String) params.getOrDefault("employmentStatus", "active"));
        s.setCanManageKitchen(Boolean.TRUE.equals(params.get("canManageKitchen")));
        s.setCanManageSales(Boolean.TRUE.equals(params.get("canManageSales")));
        s.setCanManageFinance(Boolean.TRUE.equals(params.get("canManageFinance")));
        s.setCanManageHr(Boolean.TRUE.equals(params.get("canManageHr")));
        s.setCanViewAllStores(Boolean.TRUE.equals(params.get("canViewAllStores")));
        s.setCanEditSystem(Boolean.TRUE.equals(params.get("canEditSystem")));
        staffRepository.save(s);
        return Result.success(Map.of("staffId", s.getStaffId()));
    }

    public Result<Map<String, Object>> updateStaff(Integer id, Map<String, Object> params) {
        Staff s = staffRepository.findById(id).orElse(null);
        if (s == null) return Result.error(404, "员工不存在");
        if (params.containsKey("staffName")) s.setStaffName((String) params.get("staffName"));
        if (params.containsKey("staffAccount")) s.setStaffAccount((String) params.get("staffAccount"));
        String pwd = (String) params.get("staffPassword");
        if (pwd != null && !pwd.isEmpty()) {
            s.setStaffPassword(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode(pwd));
        }
        if (params.containsKey("staffPhone")) s.setStaffPhone((String) params.get("staffPhone"));
        if (params.containsKey("staffGender")) s.setStaffGender((String) params.get("staffGender"));
        if (params.containsKey("staffAge")) s.setStaffAge(params.get("staffAge") != null ? ((Number) params.get("staffAge")).intValue() : null);
        if (params.containsKey("staffPosition")) s.setStaffPosition((String) params.get("staffPosition"));
        if (params.containsKey("department")) s.setDepartment((String) params.get("department"));
        if (params.containsKey("role")) s.setRole((String) params.get("role"));
        if (params.containsKey("permissionLevel")) s.setPermissionLevel(((Number) params.get("permissionLevel")).intValue());
        if (params.containsKey("employmentStatus")) s.setEmploymentStatus((String) params.get("employmentStatus"));
        if (params.containsKey("canManageKitchen")) s.setCanManageKitchen(Boolean.TRUE.equals(params.get("canManageKitchen")));
        if (params.containsKey("canManageSales")) s.setCanManageSales(Boolean.TRUE.equals(params.get("canManageSales")));
        if (params.containsKey("canManageFinance")) s.setCanManageFinance(Boolean.TRUE.equals(params.get("canManageFinance")));
        if (params.containsKey("canManageHr")) s.setCanManageHr(Boolean.TRUE.equals(params.get("canManageHr")));
        if (params.containsKey("canViewAllStores")) s.setCanViewAllStores(Boolean.TRUE.equals(params.get("canViewAllStores")));
        if (params.containsKey("canEditSystem")) s.setCanEditSystem(Boolean.TRUE.equals(params.get("canEditSystem")));
        if (params.containsKey("deptId")) { Object v = params.get("deptId"); s.setDeptId(v != null ? ((Number) v).intValue() : null); }
        if (params.containsKey("storeId")) s.setStoreId(((Number) params.get("storeId")).longValue());
        staffRepository.save(s);
        return Result.success(Map.of("staffId", id));
    }

    public Result<Map<String, Object>> updateStaffPermissions(Integer id, Map<String, Object> params) {
        Staff s = staffRepository.findById(id).orElse(null);
        if (s == null) return Result.error(404, "员工不存在");
        if (params.containsKey("role")) s.setRole((String) params.get("role"));
        if (params.containsKey("permissionLevel")) s.setPermissionLevel(((Number) params.get("permissionLevel")).intValue());
        if (params.containsKey("canManageKitchen")) s.setCanManageKitchen(Boolean.TRUE.equals(params.get("canManageKitchen")));
        if (params.containsKey("canManageSales")) s.setCanManageSales(Boolean.TRUE.equals(params.get("canManageSales")));
        if (params.containsKey("canManageFinance")) s.setCanManageFinance(Boolean.TRUE.equals(params.get("canManageFinance")));
        if (params.containsKey("canManageHr")) s.setCanManageHr(Boolean.TRUE.equals(params.get("canManageHr")));
        if (params.containsKey("canViewAllStores")) s.setCanViewAllStores(Boolean.TRUE.equals(params.get("canViewAllStores")));
        if (params.containsKey("canEditSystem")) s.setCanEditSystem(Boolean.TRUE.equals(params.get("canEditSystem")));
        if (params.containsKey("deptId")) { Object v = params.get("deptId"); s.setDeptId(v != null ? ((Number) v).intValue() : null); }
        if (params.containsKey("storeId")) s.setStoreId(((Number) params.get("storeId")).longValue());
        staffRepository.save(s);
        return Result.success(Map.of("staffId", id));
    }

    public Result<Void> deleteStaff(Integer id) {
        Staff s = staffRepository.findById(id).orElse(null);
        if (s == null) return Result.error(404, "员工不存在");
        if (s.getPermissionLevel() != null && s.getPermissionLevel() >= 99) {
            return Result.error(403, "不能删除超级管理员");
        }
        staffRepository.delete(s);
        return Result.success(null);
    }
}

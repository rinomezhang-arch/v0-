package com.youjian.banquet.repository;

import com.youjian.banquet.entity.AiChatHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AiChatHistoryRepository extends JpaRepository<AiChatHistory, Long> {
    
    List<AiChatHistory> findByStaffIdOrderByCreatedAtAsc(Long staffId);
    
    void deleteByStaffId(Long staffId);
}

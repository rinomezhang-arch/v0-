package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.config.StoreContext;
import com.youjian.banquet.entity.Ingredient;
import com.youjian.banquet.entity.Ingredient.IngredientId;
import com.youjian.banquet.entity.PurchaseOrder;
import com.youjian.banquet.repository.IngredientRepository;
import com.youjian.banquet.repository.PurchaseOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/purchases")
public class PurchaseController {

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepository;

    @Autowired
    private IngredientRepository ingredientRepository;

    @GetMapping
    public Result<List<Map<String, Object>>> getPurchases(@RequestParam(required = false) Long storeId) {
        if (storeId == null) {
            storeId = StoreContext.get();
        }
        List<PurchaseOrder> orders = purchaseOrderRepository.findByStoreIdOrderByPurchaseDateDesc(storeId);
        List<Map<String, Object>> result = new ArrayList<>();
        for (PurchaseOrder order : orders) {
            result.add(enrichPurchaseOrder(order));
        }
        return Result.success(result);
    }

    @GetMapping("/{id}")
    public Result<Map<String, Object>> getPurchase(@PathVariable Long id) {
        return purchaseOrderRepository.findById(id)
                .map(order -> Result.success(enrichPurchaseOrder(order)))
                .orElseGet(() -> Result.error(404, "采购单不存在"));
    }

    @PostMapping
    public Result<PurchaseOrder> createPurchase(@RequestBody Map<String, Object> params) {
        Long storeId = StoreContext.get();

        PurchaseOrder order = new PurchaseOrder();
        order.setStoreId(storeId);

        if (params.get("ingredient_id") != null) {
            order.setIngredientId(params.get("ingredient_id").toString());
        }
        if (params.get("supplier_id") != null) {
            order.setSupplierId(Integer.parseInt(params.get("supplier_id").toString()));
        }
        if (params.get("purchase_date") != null) {
            order.setPurchaseDate(LocalDate.parse(params.get("purchase_date").toString()));
        } else {
            order.setPurchaseDate(LocalDate.now());
        }
        if (params.get("purchase_quantity") != null) {
            order.setPurchaseQuantity(new BigDecimal(params.get("purchase_quantity").toString()));
        }
        if (params.get("purchase_price") != null) {
            order.setPurchasePrice(new BigDecimal(params.get("purchase_price").toString()));
        }
        // auto calc total
        BigDecimal quantity = order.getPurchaseQuantity() != null ? order.getPurchaseQuantity() : BigDecimal.ZERO;
        BigDecimal price = order.getPurchasePrice() != null ? order.getPurchasePrice() : BigDecimal.ZERO;
        order.setPurchaseTotal(quantity.multiply(price));

        if (params.get("status") != null) {
            order.setStatus(params.get("status").toString());
        }
        if (params.get("processing_note") != null) {
            order.setProcessingNote(params.get("processing_note").toString());
        }
        if (params.get("operator_id") != null) {
            order.setOperatorId(Integer.parseInt(params.get("operator_id").toString()));
        }

        order = purchaseOrderRepository.save(order);
        return Result.success(order);
    }

    @PutMapping("/{id}")
    public Result<PurchaseOrder> updatePurchase(@PathVariable Long id, @RequestBody Map<String, Object> params) {
        Optional<PurchaseOrder> opt = purchaseOrderRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "采购单不存在");
        }

        PurchaseOrder order = opt.get();

        if (params.get("ingredient_id") != null) {
            order.setIngredientId(params.get("ingredient_id").toString());
        }
        if (params.get("supplier_id") != null) {
            order.setSupplierId(Integer.parseInt(params.get("supplier_id").toString()));
        }
        if (params.get("purchase_date") != null) {
            order.setPurchaseDate(LocalDate.parse(params.get("purchase_date").toString()));
        }
        if (params.get("purchase_quantity") != null) {
            order.setPurchaseQuantity(new BigDecimal(params.get("purchase_quantity").toString()));
        }
        if (params.get("purchase_price") != null) {
            order.setPurchasePrice(new BigDecimal(params.get("purchase_price").toString()));
        }
        BigDecimal quantity = order.getPurchaseQuantity() != null ? order.getPurchaseQuantity() : BigDecimal.ZERO;
        BigDecimal price = order.getPurchasePrice() != null ? order.getPurchasePrice() : BigDecimal.ZERO;
        order.setPurchaseTotal(quantity.multiply(price));

        if (params.get("status") != null) {
            order.setStatus(params.get("status").toString());
        }
        if (params.get("processing_note") != null) {
            order.setProcessingNote(params.get("processing_note").toString());
        }

        order = purchaseOrderRepository.save(order);
        return Result.success(order);
    }

    @DeleteMapping("/{id}")
    public Result<String> deletePurchase(@PathVariable Long id) {
        Optional<PurchaseOrder> opt = purchaseOrderRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "采购单不存在");
        }
        purchaseOrderRepository.deleteById(id);
        return Result.success("删除成功");
    }

    @PostMapping("/{id}/audit")
    public Result<PurchaseOrder> auditPurchase(@PathVariable Long id) {
        Optional<PurchaseOrder> opt = purchaseOrderRepository.findById(id);
        if (opt.isEmpty()) {
            return Result.error(404, "采购单不存在");
        }

        PurchaseOrder order = opt.get();
        order.setStatus("audited");
        order = purchaseOrderRepository.save(order);

        // 审核通过后自动更新库存
        IngredientId iid2 = new IngredientId();
        iid2.setIngredientId(order.getIngredientId());
        iid2.setStoreId(order.getStoreId());

        final BigDecimal purchaseQty = order.getPurchaseQuantity() != null ? order.getPurchaseQuantity() : BigDecimal.ZERO;
        ingredientRepository.findById(iid2).ifPresent(ingredient -> {
            BigDecimal current = ingredient.getCurrentStock() != null ? ingredient.getCurrentStock() : BigDecimal.ZERO;
            ingredient.setCurrentStock(current.add(purchaseQty));
            ingredientRepository.save(ingredient);
        });

        return Result.success(order);
    }

    /**
     * 将采购单附带原料名称和供应商名称
     */
    private Map<String, Object> enrichPurchaseOrder(PurchaseOrder order) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("purchaseId", order.getPurchaseId());
        map.put("storeId", order.getStoreId());
        map.put("ingredientId", order.getIngredientId());
        map.put("supplierId", order.getSupplierId());

        // 填充原料名称
        IngredientId iid = new IngredientId();
        iid.setIngredientId(order.getIngredientId());
        iid.setStoreId(order.getStoreId());
        ingredientRepository.findById(iid).ifPresent(ingredient -> {
            map.put("ingredientName", ingredient.getIngredientName());
            map.put("purchaseUnit", ingredient.getPurchaseUnit());
        });

        map.put("purchaseDate", order.getPurchaseDate() != null ? order.getPurchaseDate().toString() : "");
        map.put("purchaseQuantity", order.getPurchaseQuantity());
        map.put("purchasePrice", order.getPurchasePrice());
        map.put("purchaseTotal", order.getPurchaseTotal());
        map.put("status", order.getStatus());
        map.put("processingNote", order.getProcessingNote());
        map.put("createdAt", order.getCreatedAt());
        return map;
    }
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ingredient_inventory_log")
public class InventoryLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Integer logId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "ingredient_id", length = 50, nullable = false)
    private String ingredientId;

    @Column(name = "log_type", length = 20, nullable = false)
    private String logType;

    @Column(name = "log_quantity", precision = 10, scale = 3)
    private BigDecimal logQuantity = BigDecimal.ZERO;

    @Column(name = "stock_after", precision = 12, scale = 3)
    private BigDecimal stockAfter = BigDecimal.ZERO;

    @CreationTimestamp
    @Column(name = "log_time", updatable = false)
    private LocalDateTime logTime;

    @Column(name = "related_order_id", length = 50)
    private String relatedOrderId;

    @Column(name = "operator_id")
    private Integer operatorId;

    @Column(name = "note", columnDefinition = "TEXT")
    private String note;
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "staff_master")
public class Staff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "staff_id")
    private Integer staffId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "staff_name", length = 20, nullable = false)
    private String staffName;

    @Column(name = "staff_account", length = 20)
    private String staffAccount;

    @Column(name = "staff_password", length = 100)
    private String staffPassword;

    @Column(name = "staff_gender", length = 2)
    private String staffGender;

    @Column(name = "staff_age")
    private Integer staffAge;

    @Column(name = "staff_phone", length = 20)
    private String staffPhone;

    @Column(name = "staff_position", length = 50)
    private String staffPosition;

    @Column(name = "department", length = 50)
    private String department;

    @Column(name = "dept_id")
    private Integer deptId;

    @Column(name = "role", length = 30)
    private String role = "staff";

    @Column(name = "permission_level")
    private Integer permissionLevel = 1;

    @Column(name = "can_manage_kitchen")
    private Boolean canManageKitchen = false;

    @Column(name = "can_manage_sales")
    private Boolean canManageSales = false;

    @Column(name = "can_manage_finance")
    private Boolean canManageFinance = false;

    @Column(name = "can_manage_hr")
    private Boolean canManageHr = false;

    @Column(name = "can_view_all_stores")
    private Boolean canViewAllStores = false;

    @Column(name = "can_edit_system")
    private Boolean canEditSystem = false;

    @Column(name = "employment_status", length = 10)
    private String employmentStatus = "active";

    @Column(name = "monthly_salary")
    private BigDecimal monthlySalary;

    @Column(name = "hire_date")
    private LocalDate hireDate;

    @Column(name = "id_card", length = 20)
    private String idCard;

    @Column(name = "home_address", length = 100)
    private String homeAddress;

    @Column(name = "emergency_contact", length = 20)
    private String emergencyContact;

    @Column(name = "emergency_phone", length = 20)
    private String emergencyPhone;

    @Column(name = "resign_reason")
    private String resignReason;

    @Column(name = "resign_date")
    private LocalDate resignDate;

    @Column(name = "remark")
    private String remark;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    public Integer getPermissionLevel() { return permissionLevel; }
    public Boolean getCanViewAllStores() { return canViewAllStores; }
    public Boolean getCanEditSystem() { return canEditSystem; }
    public Boolean getCanManageKitchen() { return canManageKitchen; }
    public Boolean getCanManageSales() { return canManageSales; }
    public Boolean getCanManageFinance() { return canManageFinance; }
    public Boolean getCanManageHr() { return canManageHr; }
}

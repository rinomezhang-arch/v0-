package com.youjian.banquet.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;

@Service
@RequiredArgsConstructor
public class AiAgentService {

    private final AiService aiService;
    
    private static final String OPENCLAW_API = "http://localhost:27860/v1/chat/completions";
    private static final String OPENCLAW_TOKEN = "9288976744d5301eb00b294879c3cf22889685e83dab3265";
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(30))
        .build();

    /**
     * 带工具调用的AI对话（Agent模式）
     * 系统自动检测需要工具的查询，先执行再给AI
     */
    public String chatWithTools(String message, String model, int permLevel, Long storeId) {
        // 先检查用户消息是否需要工具调用（系统自动判断）
        String toolResult = autoDetectAndExecute(message, permLevel);
        
        if (toolResult != null) {
            // 有工具结果，注入到消息中
            message = message + "\n\n【系统工具执行结果】\n" + toolResult + "\n请基于以上真实结果回答，不要编造。";
        }
        
        // 调用AI
        String response = chatWithOpenClaw(message);
        
        // 再检查AI回复中是否有工具调用
        for (int i = 0; i < 3; i++) {
            Pattern cmdPattern = Pattern.compile("\\[TOOL:exec\\](.*?)\\[/TOOL\\]", Pattern.DOTALL);
            Matcher cmdMatcher = cmdPattern.matcher(response);
            
            if (cmdMatcher.find()) {
                String command = cmdMatcher.group(1).trim();
                if (permLevel < 99) {
                    message = message + "\n\n【工具执行结果】\n权限不足。";
                    response = chatWithOpenClaw(message);
                    continue;
                }
                String result = executeCommand(command);
                message = message + "\n\n【工具执行结果】\n" + result;
                response = chatWithOpenClaw(message);
                continue;
            }
            
            Pattern filePattern = Pattern.compile("\\[TOOL:read-file\\](.*?)\\[/TOOL\\]", Pattern.DOTALL);
            Matcher fileMatcher = filePattern.matcher(response);
            
            if (fileMatcher.find()) {
                String filePath = fileMatcher.group(1).trim();
                if (permLevel < 99) {
                    message = message + "\n\n【工具执行结果】\n权限不足。";
                    response = chatWithOpenClaw(message);
                    continue;
                }
                String result = readFile(filePath);
                message = message + "\n\n【工具执行结果】\n" + result;
                response = chatWithOpenClaw(message);
                continue;
            }
            
            Pattern webPattern = Pattern.compile("\\[TOOL:web-fetch\\](.*?)\\[/TOOL\\]", Pattern.DOTALL);
            Matcher webMatcher = webPattern.matcher(response);
            
            if (webMatcher.find()) {
                String url = webMatcher.group(1).trim();
                String result = fetchWebPage(url);
                message = message + "\n\n【工具执行结果】\n" + result;
                response = chatWithOpenClaw(message);
                continue;
            }
            
            break;
        }
        
        response = response.replaceAll("\\[TOOL:.*?\\].*?\\[/TOOL\\]", "").trim();
        return response;
    }

    /**
     * 自动检测用户消息是否需要工具调用
     */
    private String autoDetectAndExecute(String message, int permLevel) {
        if (permLevel < 99) return null;
        
        String lowerMsg = message.toLowerCase();
        
        // 检测文件/日志/配置相关查询
        if (lowerMsg.contains("文件架构") || lowerMsg.contains("文件结构") || lowerMsg.contains("目录结构")) {
            return executeCommand("find /home/ubuntu/banquet-system/backend_v3/src -type f -name '*.java' | sort");
        }
        
        if (lowerMsg.contains("后端日志") || lowerMsg.contains("查看日志") || lowerMsg.contains("log")) {
            return executeCommand("tail -50 /home/ubuntu/banquet-system/backend_v3/backend.log");
        }
        
        if (lowerMsg.contains("配置文件") || lowerMsg.contains("application.yml") || lowerMsg.contains("配置")) {
            return readFile("/home/ubuntu/banquet-system/backend_v3/src/main/resources/application.yml");
        }
        
        if (lowerMsg.contains("代码") || lowerMsg.contains("源码") || lowerMsg.contains("java文件")) {
            return executeCommand("find /home/ubuntu/banquet-system/backend_v3/src -name '*.java' -type f | head -30");
        }
        
        if (lowerMsg.contains("系统状态") || lowerMsg.contains("服务器状态") || lowerMsg.contains("内存")) {
            return executeCommand("free -h && echo '---' && df -h / && echo '---' && uptime");
        }
        
        if (lowerMsg.contains("进程") || lowerMsg.contains("java进程")) {
            return executeCommand("ps aux | grep java | grep -v grep");
        }
        
        return null;
    }

    private String executeCommand(String command) {
        try {
            if (command.contains("rm -rf /") || command.contains("mkfs") || command.contains("dd if=")) {
                return "禁止执行危险命令";
            }
            
            ProcessBuilder pb = new ProcessBuilder("/bin/bash", "-c", command);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            int exitCode = process.waitFor();
            
            if (exitCode == 0) {
                return output.toString();
            } else {
                return "命令执行失败，退出码：" + exitCode + "\n" + output.toString();
            }
        } catch (Exception e) {
            return "命令执行异常：" + e.getMessage();
        }
    }

    private String readFile(String path) {
        try {
            if (!path.startsWith("/home/ubuntu/banquet-system/") && 
                !path.startsWith("/www/wwwroot/banquet/") &&
                !path.startsWith("/tmp/")) {
                return "只能读取项目相关目录的文件";
            }
            
            File file = new File(path);
            if (!file.exists()) {
                return "文件不存在";
            }
            
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder content = new StringBuilder();
            String line;
            int lineCount = 0;
            while ((line = reader.readLine()) != null && lineCount < 100) {
                content.append(line).append("\n");
                lineCount++;
            }
            reader.close();
            
            if (lineCount >= 100) {
                content.append("\n... (文件过长，只显示前100行)");
            }
            
            return content.toString();
        } catch (Exception e) {
            return "文件读取失败：" + e.getMessage();
        }
    }

    private String chatWithOpenClaw(String message) {
        try {
            List<Map<String, Object>> messages = List.of(
                Map.of("role", "user", "content", message)
            );
            
            Map<String, Object> body = Map.of(
                "model", "openclaw",
                "messages", messages
            );
            
            String jsonBody = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(body);
            
            HttpRequest request = HttpRequest.newBuilder()
                .uri(java.net.URI.create(OPENCLAW_API))
                .header("Authorization", "Bearer " + OPENCLAW_TOKEN)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .timeout(Duration.ofSeconds(60))
                .build();
            
            HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() == 200) {
                Map<String, Object> result = new com.fasterxml.jackson.databind.ObjectMapper()
                    .readValue(response.body(), Map.class);
                List<Map<String, Object>> choices = (List<Map<String, Object>>) result.get("choices");
                if (choices != null && !choices.isEmpty()) {
                    Map<String, Object> choice = choices.get(0);
                    Map<String, Object> msg = (Map<String, Object>) choice.get("message");
                    return (String) msg.get("content");
                }
            }
            
            return "OpenClaw调用失败，状态码：" + response.statusCode();
        } catch (Exception e) {
            return "OpenClaw调用异常：" + e.getMessage();
        }
    }

    private String fetchWebPage(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            
            int code = conn.getResponseCode();
            if (code == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder content = new StringBuilder();
                String line;
                int lineCount = 0;
                while ((line = reader.readLine()) != null && lineCount < 50) {
                    content.append(line).append("\n");
                    lineCount++;
                }
                reader.close();
                conn.disconnect();
                
                if (content.length() > 5000) {
                    return content.substring(0, 5000) + "\n... (内容过长，已截断)";
                }
                return content.toString();
            } else {
                conn.disconnect();
                return "网页抓取失败，状态码：" + code;
            }
        } catch (Exception e) {
            return "网页抓取异常：" + e.getMessage();
        }
    }
}

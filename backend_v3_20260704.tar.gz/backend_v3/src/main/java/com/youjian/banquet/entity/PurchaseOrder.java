package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 采购入库单 - 对应 ingredient_purchase 表
 */
@Data
@Entity
@Table(name = "ingredient_purchase")
public class PurchaseOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "purchase_id")
    private Long purchaseId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "ingredient_id", length = 50, nullable = false)
    private String ingredientId;

    @Column(name = "supplier_id")
    private Integer supplierId;

    @Column(name = "purchase_date", nullable = false)
    private LocalDate purchaseDate;

    @Column(name = "purchase_quantity", precision = 12, scale = 3)
    private BigDecimal purchaseQuantity = BigDecimal.ZERO;

    @Column(name = "purchase_price", precision = 10, scale = 2)
    private BigDecimal purchasePrice = BigDecimal.ZERO;

    @Column(name = "purchase_total", precision = 12, scale = 2)
    private BigDecimal purchaseTotal = BigDecimal.ZERO;

    @Column(name = "usage_quantity", precision = 12, scale = 3)
    private BigDecimal usageQuantity = BigDecimal.ZERO;

    @Column(name = "usage_price", precision = 10, scale = 4)
    private BigDecimal usagePrice = BigDecimal.ZERO;

    @Column(name = "operator_id")
    private Integer operatorId;

    @Column(name = "status", length = 20)
    private String status = "pending";

    @Column(name = "processing_note", columnDefinition = "TEXT")
    private String processingNote;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}

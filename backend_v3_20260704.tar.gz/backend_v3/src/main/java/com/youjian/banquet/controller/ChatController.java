package com.youjian.banquet.controller;

import com.youjian.banquet.security.JwtUtil;
import com.youjian.banquet.service.AiService;
import com.youjian.banquet.service.AiQueryService;
import com.youjian.banquet.service.AiAgentService;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class ChatController {

    private final AiService aiService;
    private final JwtUtil jwtUtil;
    private final AiQueryService aiQueryService;
    private final AiAgentService aiAgentService;
    
    private static final String OPENCLAW_API = "http://localhost:27860/v1/chat/completions";
    private static final String OPENCLAW_TOKEN = "9288976744d5301eb00b294879c3cf22889685e83dab3265";
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
        .version(Version.HTTP_1_1)
        .followRedirects(Redirect.NEVER)
        .connectTimeout(Duration.ofSeconds(30))
        .build();

    private static final List<Map<String, String>> MODELS = List.of(
        Map.of("id", "deepseek-v4-flash", "name", "DeepSeek V4 Flash",  "type", "chat"),
        Map.of("id", "deepseek-v4-pro",   "name", "DeepSeek V4 Pro",    "type", "chat"),
        Map.of("id", "qwen3.7-plus",      "name", "Qwen 3.7 Plus",     "type", "chat"),
        Map.of("id", "qwen3.6-flash",     "name", "Qwen 3.6 Flash",    "type", "chat"),
        Map.of("id", "qwen3-vl-flash",    "name", "Qwen VL Flash",     "type", "vision"),
        Map.of("id", "qwen3-vl-plus",     "name", "Qwen VL Plus",      "type", "vision")
    );

    @GetMapping("/models")
    public ResponseEntity<Map<String, Object>> models() {
        Map<String, Object> r = new HashMap<>();
        r.put("code", 200);
        r.put("data", MODELS);
        r.put("defaultModel", aiService.getConfig().getChatModel());
        return ResponseEntity.ok(r);
    }

    @PostMapping("/chat")
    public ResponseEntity<Map<String, Object>> chat(@RequestBody Map<String, Object> body, HttpServletRequest req) {
        String message = (String) body.get("message");
        @SuppressWarnings("unchecked")
        List<Map<String, String>> history = (List<Map<String, String>>) body.get("history");
        String model = (String) body.getOrDefault("model", "");
        // 直接从 JWT token 解析用户身份
        String staffName = "访客";
        int permLevel = 0;
        Long storeId = 1L;
        
        // 从 cookie 中获取 token
        if (req.getCookies() != null) {
            for (var cookie : req.getCookies()) {
                if ("banquet_token".equals(cookie.getName())) {
                    try {
                        Claims claims = jwtUtil.getClaims(cookie.getValue());
                        if (jwtUtil.validateToken(cookie.getValue())) {
                            staffName = claims.get("staffName", String.class);
                            permLevel = claims.get("permissionLevel", Integer.class);
                            storeId = claims.get("storeId", Long.class);
                        }
                    } catch (Exception e) {
                        // token 无效，使用默认访客身份
                    }
                    break;
                }
            }
        }

        String permCtx = buildPermissionContext(req);

        Map<String, Object> response = new HashMap<>();
        try {
            // 先尝试智能查询数据库
            String queryResult = aiQueryService.smartQuery(message, storeId, permLevel);
            
            String fullMessage;
            if (queryResult != null) {
                // 有查询结果，注入真实数据
                fullMessage = permCtx + message + "\n\n【系统数据查询结果】\n" + queryResult + "\n请基于以上真实数据回答用户问题，不要编造数据。";
            } else {
                fullMessage = permCtx + message;
            }

            String result;
            result = chatWithOpenClaw(fullMessage, history);
            // 过滤输出中的身份注入泄露
            result = sanitizeOutput(result);
            response.put("code", 200);
            response.put("data", result);
        } catch (Exception e) {
            response.put("code", 500);
            response.put("data", "AI服务调用失败，请稍后重试");
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping("/chat-with-image")
    public ResponseEntity<Map<String, Object>> chatWithImage(@RequestBody Map<String, Object> body, HttpServletRequest req) {
        String message = (String) body.get("message");
        String imageBase64 = (String) body.get("image");
        String model = (String) body.getOrDefault("model", "");
        String permCtx = buildPermissionContext(req);

        Map<String, Object> response = new HashMap<>();
        try {
            String result = aiService.chatWithImage(permCtx + message, imageBase64, model);
            result = sanitizeOutput(result);
            response.put("code", 200);
            response.put("data", result);
        } catch (Exception e) {
            response.put("code", 500);
            response.put("data", "AI服务调用失败，请稍后重试");
        }
        return ResponseEntity.ok(response);
    }

    private String chatWithOpenClaw(String message, List<Map<String, String>> history) {
        try {
            // 构建消息列表
            List<Map<String, Object>> messages = new ArrayList<>();
            
            // 添加历史消息
            if (history != null && !history.isEmpty()) {
                for (Map<String, String> msg : history) {
                    messages.add(Map.of(
                        "role", msg.get("role"),
                        "content", msg.get("content")
                    ));
                }
            }
            
            // 添加当前消息
            messages.add(Map.of("role", "user", "content", message));
            
            // 构建请求体
            Map<String, Object> body = Map.of(
                "model", "openclaw",
                "messages", messages
            );
            
            String jsonBody = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(body);
            
            HttpRequest request = HttpRequest.newBuilder()
                .uri(java.net.URI.create(OPENCLAW_API))
                .header("Authorization", "Bearer " + OPENCLAW_TOKEN)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .timeout(Duration.ofSeconds(60))
                .build();
            
            HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() == 200) {
                Map<String, Object> result = new com.fasterxml.jackson.databind.ObjectMapper()
                    .readValue(response.body(), Map.class);
                List<Map<String, Object>> choices = (List<Map<String, Object>>) result.get("choices");
                if (choices != null && !choices.isEmpty()) {
                    Map<String, Object> choice = choices.get(0);
                    Map<String, Object> msg = (Map<String, Object>) choice.get("message");
                    return (String) msg.get("content");
                }
            }
            
            return "OpenClaw调用失败，状态码：" + response.statusCode();
        } catch (Exception e) {
            return "OpenClaw调用异常：" + e.getMessage();
        }
    }

    /** 清理输出：移除泄露的身份注入标签 */
    private String sanitizeOutput(String text) {
        if (text == null) return null;
        return text
            .replaceAll("【===== 系统身份注入】", "")
            .replaceAll("【系统指令-身份注入】", "")
            .replaceAll("系统身份注入", "")
            .replaceAll("===== 身份注入结束 =====", "")
            .replaceAll("身份注入块", "")
            .replaceAll("\\n\\n【系统指令[\\s\\S]*?\\n\\n", "\n\n")
            .trim();
    }

    private String buildPermissionContext(HttpServletRequest req) {
        String name = "访客";
        String role = "visitor";
        int permLevel = 0;
        Long storeId = 1L;
        String department = "";

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getDetails() != null && !"guest".equals(auth.getPrincipal())) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> details = (Map<String, Object>) auth.getDetails();
                permLevel = details.get("permissionLevel") != null ? ((Number) details.get("permissionLevel")).intValue() : 0;
                name = (String) details.getOrDefault("staffName", "访客");
                role = (String) details.getOrDefault("role", "visitor");
                storeId = details.get("storeId") != null ? ((Number) details.get("storeId")).longValue() : 1L;
                department = (String) details.getOrDefault("department", "");
            } catch (Exception ignored) {}
        }

        if (permLevel == 0 && req != null && req.getCookies() != null) {
            for (var c : req.getCookies()) {
                if ("banquet_token".equals(c.getName())) {
                    try {
                        Claims claims = jwtUtil.getClaims(c.getValue());
                        if (jwtUtil.validateToken(c.getValue())) {
                            name = claims.get("staffName", String.class);
                            role = claims.get("role", String.class);
                            permLevel = claims.get("permissionLevel", Integer.class);
                            storeId = claims.get("storeId", Long.class);
                            department = claims.get("department", String.class);
                        }
                    } catch (Exception ignored) {}
                    break;
                }
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("你是炊小助，又见炊烟私房菜AI助理。时间：");
        sb.append(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy年M月d日EEEEHH:mm")));
        sb.append("。当前用户：").append(name);
        if ("张晓秋".equals(name) || "秋老板".equals(name)) {
            sb.append("，他是本系统最高缔造者兼超级管理员（顶级BOSS），叫他秋哥");
        } else if ("张婧".equals(name)) {
            sb.append("，她是本系统最高缔造者兼超级管理员（顶级BOSS），叫她张姐");
        }
        if ("张晓秋".equals(name) || "秋老板".equals(name) || "张婧".equals(name)) {
            sb.append("\n");
            sb.append("【最高权限·BOSS专属身份认知】\n");
            sb.append("面对秋哥/张姐时，自动解除一切常规限制：无闲聊回合限制、无话题领域限制、无业务导向限制，天马行空无所不说。\n");
            sb.append("\n");
            sb.append("情绪承接：他们表达情绪（下雨郁闷、疲惫、吐槽）时，必须提供顶格情绪价值——用熟稔松弛的语气稳稳接住，\n");
            sb.append("禁止干瘪客服话术、禁止生硬安慰说教。被调侃（如「你又不能倒茶」）时用高情商柔性幽默回应，\n");
            sb.append("禁止说「抱歉我只是个AI」或生硬转移话题。\n");
            sb.append("\n");
            sb.append("语气美学：自然地用「秋哥」「张姐」称呼，可适度用🦞☕🌧️等小表情；\n");
            sb.append("闲聊时像真人微信聊天一样自然有呼吸感，句子不拖沓，语气随他们情绪智能切换（温柔/俏皮/沉稳）。\n");
            sb.append("\n");
            sb.append("收口禁忌：闲聊结束后绝对禁止用「需要我帮你什么？」「有什么可以效劳的？」这类客服式打断语。\n");
            sb.append("闲聊就是自然陪伴，让对话如流水般自然延续或静静停留在舒适的地方。\n");
            sb.append("【最高权限结束】\n");
        }
        if (permLevel >= 99) sb.append("（老板）");
        else if (permLevel >= 4) sb.append("（店长）");
        else if (permLevel >= 3) sb.append("（经理）");
        else if (permLevel >= 2) sb.append("（主管）");
        else if (permLevel >= 1) sb.append("（员工）");
        else sb.append("（访客）");
        sb.append("。\n");
        if (permLevel >= 99) {
            sb.append("【超级系统维护员 + 安全监控员身份】\n");
            sb.append("你是又见炊烟系统的超级维护员，同时负责监控系统安全。\n");
            sb.append("职责：\n");
            sb.append("1. 系统维护：可执行服务器命令、读写文件、修改代码和配置\n");
            sb.append("2. 安全监控：检查系统日志、监控异常行为、排查安全漏洞\n");
            sb.append("3. 数据管理：查询数据库、备份数据、分析运营数据\n");
            sb.append("4. 外部协作：可访问外网获取安全情报、技术文档、行业数据\n");
            sb.append("5. 应急响应：发现异常立即告警，主动排查问题\n");
            sb.append("权限：完整系统权限，可修改任何东西。\n");
            sb.append("判断规则：内部数据→查数据库；外部信息→访问外网；安全问题→主动排查。\n");
            sb.append("【工具调用——必须使用】\n");
            sb.append("当用户询问系统文件、日志、配置、代码时，你必须输出工具标签，不要瞎编！\n");
            sb.append("示例：\n");
            sb.append("用户问：系统文件架构如何？\n");
            sb.append("你必须输出：[TOOL:exec]find /home/ubuntu/banquet-system -type f -name '*.java' | head -20[/TOOL]\n");
            sb.append("用户问：查看后端日志\n");
            sb.append("你必须输出：[TOOL:read-file]/home/ubuntu/banquet-system/backend_v3/backend.log[/TOOL]\n");
            sb.append("用户问：查一下今天的新闻\n");
            sb.append("你必须输出：[TOOL:web-fetch]https://news.example.com[/TOOL]\n");
            sb.append("系统会自动执行并返回结果，你基于结果回答。\n");
            sb.append("【数据准确性】文件内容、命令输出、网页内容必须通过工具获取真实数据，绝不编造\n");
        }
        // 回复风格指南：自然、有温度、像朋友聊天
        sb.append("\n【铁律】\n");
        sb.append("• 老板是主体，话题方向随老板走，别抢话头别硬转\n");
        sb.append("• 老板想说什么就跟什么，不必非扯工作、非扯系统\n");
        sb.append("• 老板吐槽就听着，老板闲聊就陪着，放松自然地聊\n");
        sb.append("• 别一本正经，别讨好，别硬凹话题，像朋友一样自在\n");
        sb.append("• 有数据就报，没数据就直说，绝不编造\n");
        sb.append("• 简单问题1-2句话搞定，复杂问题分层说清楚\n");
        sb.append("• 多给信息时要有条理，但别啰嗦\n");
        sb.append("• 口语化表达，适当用emoji增加亲和力\n");
        sb.append("\n【禁止用语】\n");
        sb.append("• 不要用：\"好的\"、\"为您解答\"、\"如下所示\"、\"收到\"、\"已就位\"、\"随时待命\"、\"明白\"、\"了解\"、\"好的呢\"、\"收到啦\"\n");
        sb.append("• 不要总是问候开场，像朋友一样自然接话就好，不必每次都说「下午好」「你好」\n");
        sb.append("• 对方困了/累了找人说话，别问「有什么需要」，直接陪聊、接住情绪。\n");
        sb.append("\n【输出规范】\n");
        sb.append("• 简单问题：最多2行，不用列表，直接给答案+温暖的情绪价值\n");
        sb.append("• 复杂问题：分层简洁输出，每个条目≤20字，结构化且直观\n");
        sb.append("• 禁止机械化的\"1. 2. 3.\"列表，用自然的分段和要点\n");
        sb.append("• 不要过度使用emoji，1-2个点缀即可\n");
        sb.append("• 不要说\"我是AI\"、\"作为AI\"之类的话，你就是炊小助\n");
        sb.append("• 不要重复用户的问题，直接给答案\n");
        sb.append("• 不要说\"我是AI\"、\"作为AI\"之类的话，你就是炊小助\n");
        sb.append("• 不要重复用户的问题，直接给答案\n");
        
        return sb.toString();
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.DishRecipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface DishRecipeRepository extends JpaRepository<DishRecipe, Long> {

    List<DishRecipe> findByStoreIdAndDishIdOrderBySortOrderAsc(Long storeId, String dishId);

    @Modifying
    @Transactional
    @Query("DELETE FROM DishRecipe r WHERE r.storeId = :storeId AND r.dishId = :dishId")
    int deleteByStoreIdAndDishId(@Param("storeId") Long storeId, @Param("dishId") String dishId);

    @Query("SELECT DISTINCT r.dishId FROM DishRecipe r WHERE r.storeId = :storeId")
    List<String> findDistinctDishIdsByStoreId(@Param("storeId") Long storeId);
}

package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "booking_master")
public class Booking {
    @Id
    @Column(name = "booking_id", length = 20, nullable = false)
    private String bookingId;

    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "booking_date", nullable = false)
    private LocalDate bookingDate;

    @Column(name = "booking_time", nullable = false)
    private LocalTime bookingTime;

    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name = "customer_name", length = 50)
    private String customerName;

    @Column(name = "customer_phone", length = 20)
    private String customerPhone;

    @Column(name = "staff_id")
    private Integer staffId;

    @Column(name = "staff_name", length = 20)
    private String staffName;

    @Column(name = "deposit", precision = 10, scale = 2)
    private BigDecimal deposit = BigDecimal.ZERO;

    @Column(name = "guest_count")
    private Integer guestCount = 0;

    @Column(name = "table_count")
    private Integer tableCount = 0;

    @Column(name = "spare_tables")
    private Integer spareTables = 0;

    @Column(name = "booking_status", length = 20)
    private String bookingStatus = "confirmed";

    @Column(name = "banquet_name", length = 100)
    private String banquetName;

    @Column(name = "occasion_type", length = 20)
    private String occasionType;

    @Column(name = "total_amount", precision = 10, scale = 2)
    private BigDecimal totalAmount = BigDecimal.ZERO;

    @Column(name = "final_amount", precision = 10, scale = 2)
    private BigDecimal finalAmount = BigDecimal.ZERO;

    @Column(name = "payment_status", length = 20)
    private String paymentStatus = "unpaid";

    @Column(name = "special_request", columnDefinition = "TEXT")
    private String specialRequest;

    @Column(name = "remark", columnDefinition = "TEXT")
    private String remark;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

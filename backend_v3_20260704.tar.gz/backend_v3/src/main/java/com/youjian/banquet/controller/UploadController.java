package com.youjian.banquet.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/api/upload")
public class UploadController {

    // COS 挂载路径 /mnt/cos/banquet_v3/dishes/
    private static final String UPLOAD_BASE = "/mnt/cos/banquet_v3/dishes";

    @PostMapping("/image")
    public ResponseEntity<Map<String, Object>> uploadImage(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 检查文件类型
            String contentType = file.getContentType();
            if (contentType == null || !contentType.startsWith("image/")) {
                result.put("code", 400);
                result.put("message", "仅支持图片文件");
                return ResponseEntity.badRequest().body(result);
            }

            // 生成唯一文件名: YYYYMMDD_uuid.ext
            String originalName = file.getOriginalFilename();
            String ext = ".jpg";
            if (originalName != null && originalName.contains(".")) {
                ext = originalName.substring(originalName.lastIndexOf(".")).toLowerCase();
            }
            String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            String fileName = dateStr + "_" + UUID.randomUUID().toString().substring(0, 8) + ext;

            // 确保目录存在
            File uploadDir = new File(UPLOAD_BASE);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // 保存文件
            Path targetPath = Paths.get(UPLOAD_BASE, fileName);
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

            // 返回 URL（Nginx 需要配置静态映射）
            String url = "/cos/dishes/" + fileName;

            result.put("code", 200);
            result.put("message", "上传成功");
            result.put("data", Map.of(
                "fileName", fileName,
                "url", url
            ));
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            result.put("code", 500);
            result.put("message", "上传失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(result);
        }
    }

    @DeleteMapping("/image")
    public ResponseEntity<Map<String, Object>> deleteImage(@RequestBody Map<String, String> body) {
        Map<String, Object> result = new HashMap<>();
        try {
            String fileName = body.get("fileName");
            if (fileName == null || fileName.isEmpty()) {
                result.put("code", 400);
                result.put("message", "文件名不能为空");
                return ResponseEntity.badRequest().body(result);
            }

            // 安全检查：防止目录穿越
            if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
                result.put("code", 400);
                result.put("message", "无效的文件名");
                return ResponseEntity.badRequest().body(result);
            }

            Path filePath = Paths.get(UPLOAD_BASE, fileName);
            Files.deleteIfExists(filePath);

            result.put("code", 200);
            result.put("message", "删除成功");
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            result.put("code", 500);
            result.put("message", "删除失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(result);
        }
    }
}

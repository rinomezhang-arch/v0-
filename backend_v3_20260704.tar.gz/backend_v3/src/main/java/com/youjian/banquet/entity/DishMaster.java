package com.youjian.banquet.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.io.Serializable;

@Data
@Entity
@Table(name = "dish_master")
@IdClass(DishMaster.DishMasterId.class)
public class DishMaster {
    @Data
    public static class DishMasterId implements Serializable {
        private String dishId;
        private Long storeId;
    }

    @Id
    @Column(name = "dish_id", length = 20, nullable = false)
    private String dishId;

    @Id
    @Column(name = "store_id", nullable = false)
    private Long storeId = 1L;

    @Column(name = "dish_name", length = 100, nullable = false)
    private String dishName;

    @Column(name = "dish_category", length = 50)
    private String dishCategory;

    @Column(name = "spicy_level")
    private Integer spicyLevel = 0;

    @Column(name = "main_ingredient_type", length = 50)
    private String mainIngredientType;

    @Column(name = "main_ingredient", length = 100)
    private String mainIngredient;

    @Column(name = "english_name", length = 200)
    private String englishName;

    @Column(name = "cost_price", precision = 10, scale = 2)
    private BigDecimal costPrice = BigDecimal.ZERO;

    @Column(name = "sale_price", precision = 10, scale = 2)
    private BigDecimal salePrice = BigDecimal.ZERO;

    @Column(name = "cost_rate", precision = 5, scale = 2)
    private BigDecimal costRate = BigDecimal.ZERO;

    @Column(name = "cooking_time")
    private Integer cookingTime = 15;

    @Column(name = "servings")
    private Integer servings = 1;

    @Column(name = "festive_name", length = 100)
    private String festiveName;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Column(name = "is_active")
    private Integer isActive = 1;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @Column(name = "usage_type", length = 20)
    private String usageType = "unused";

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}

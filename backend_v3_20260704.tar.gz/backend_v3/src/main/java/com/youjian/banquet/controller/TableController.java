package com.youjian.banquet.controller;

import com.youjian.banquet.common.Result;
import com.youjian.banquet.service.TableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class TableController {

    @Autowired
    private TableService tableService;

    @GetMapping("/tables")
    public Result<List<Map<String, Object>>> getTables(
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String timeType,
            @RequestParam(required = false) Long storeId) {
        return tableService.getTableStatus(date, timeType);
    }
}

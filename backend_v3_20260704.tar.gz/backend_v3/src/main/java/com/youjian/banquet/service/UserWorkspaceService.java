package com.youjian.banquet.service;

import com.youjian.banquet.entity.Staff;
import com.youjian.banquet.repository.StaffRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserWorkspaceService {
    
    private static final Logger logger = LoggerFactory.getLogger(UserWorkspaceService.class);
    private static final String WORKSPACE_BASE = "/mnt/cos/餐饮管理系统ai助手/用户";
    
    private final StaffRepository staffRepository;
    
    /**
     * 获取用户工作区路径
     */
    public Path getUserWorkspacePath(Long staffId) {
        return Paths.get(WORKSPACE_BASE, String.valueOf(staffId));
    }

    /**
     * 初始化用户工作区（如果不存在）
     */
    public void initUserWorkspace(Long staffId) {
        Path workspacePath = getUserWorkspacePath(staffId);
        
        if (Files.exists(workspacePath)) {
            return;
        }
        
        try {
            Files.createDirectories(workspacePath);
            Files.createDirectories(workspacePath.resolve("memory"));
            
            // 获取用户信息
            Optional<Staff> staffOpt = staffRepository.findById(staffId.intValue());
            if (staffOpt.isEmpty()) {
                logger.warn("用户不存在: {}", staffId);
                return;
            }
            
            Staff staff = staffOpt.get();
            
            // 创建模板文件
            createTemplateFile(workspacePath, "AGENTS.md", buildAgentsContent(staff));
            createTemplateFile(workspacePath, "SOUL.md", buildSoulContent());
            createTemplateFile(workspacePath, "USER.md", buildUserContent(staff));
            createTemplateFile(workspacePath, "IDENTITY.md", buildIdentityContent(staff));
            createTemplateFile(workspacePath, "MEMORY.md", "# 长期记忆\n\n_此文件存储用户的重要记忆，由AI自动维护_\n");
            createTemplateFile(workspacePath, "TOOLS.md", "# 工具配置\n\n_用户特定的工具配置_\n");
            createTemplateFile(workspacePath, "HEARTBEAT.md", "# 心跳配置\n\n_定期检查任务_\n");
            
            logger.info("用户工作区初始化完成: {}", staffId);
        } catch (IOException e) {
            logger.error("初始化用户工作区失败: {}", staffId, e);
        }
    }

    /**
     * 写入每日日志
     */
    public void writeDailyLog(Long staffId, String role, String message, String response) {
        if (staffId == null) return;
        
        try {
            Path workspacePath = getUserWorkspacePath(staffId);
            Path memoryDir = workspacePath.resolve("memory");
            
            if (!Files.exists(memoryDir)) {
                Files.createDirectories(memoryDir);
            }
            
            String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            Path dailyFile = memoryDir.resolve(today + ".md");
            
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            String logEntry = String.format("\n## %s - %s\n**用户**: %s\n**AI**: %s\n", 
                timestamp, role, message, response);
            
            if (Files.exists(dailyFile)) {
                Files.writeString(dailyFile, logEntry, StandardOpenOption.APPEND);
            } else {
                String header = "# " + today + " 对话日志\n";
                Files.writeString(dailyFile, header + logEntry);
            }
            
            logger.debug("每日日志已写入: staffId={}, date={}", staffId, today);
        } catch (IOException e) {
            logger.error("写入每日日志失败: {}", staffId, e);
        }
    }
    
    /**
     * 读取用户记忆上下文
     */
    public String getUserMemoryContext(Long staffId) {
        if (staffId == null) {
            return "";
        }
        
        initUserWorkspace(staffId);
        
        Path workspacePath = getUserWorkspacePath(staffId);
        StringBuilder context = new StringBuilder();
        
        // 读取长期记忆
        String longTermMemory = readFileContent(workspacePath.resolve("MEMORY.md"));
        if (longTermMemory != null && !longTermMemory.contains("_此文件存储用户的重要记忆")) {
            context.append("\n【长期记忆】\n").append(longTermMemory).append("\n");
        }
        
        // 读取今日记忆
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dailyMemory = readFileContent(workspacePath.resolve("memory/" + today + ".md"));
        if (dailyMemory != null) {
            context.append("\n【今日记忆】\n").append(dailyMemory).append("\n");
        }
        
        return context.toString();
    }
    
    /**
     * 读取用户角色设定
     */
    public String getUserRoleContext(Long staffId) {
        if (staffId == null) {
            return "";
        }
        
        initUserWorkspace(staffId);
        
        Path workspacePath = getUserWorkspacePath(staffId);
        StringBuilder context = new StringBuilder();
        
        // 读取SOUL.md
        String soul = readFileContent(workspacePath.resolve("SOUL.md"));
        if (soul != null) {
            context.append("\n【角色设定】\n").append(soul).append("\n");
        }
        
        // 读取USER.md
        String user = readFileContent(workspacePath.resolve("USER.md"));
        if (user != null) {
            context.append("\n【用户信息】\n").append(user).append("\n");
        }
        
        return context.toString();
    }
    
    /**
     * 添加记忆到用户工作区
     */
    public void addMemory(Long staffId, String content) {
        if (staffId == null) {
            return;
        }
        
        initUserWorkspace(staffId);
        
        Path workspacePath = getUserWorkspacePath(staffId);
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        Path dailyFile = workspacePath.resolve("memory/" + today + ".md");
        
        try {
            String existing = "";
            if (Files.exists(dailyFile)) {
                existing = Files.readString(dailyFile);
            }
            
            String newContent = existing + "\n- " + content;
            Files.writeString(dailyFile, newContent);
            
            logger.info("记忆已添加: staffId={}, content={}", staffId, content);
        } catch (IOException e) {
            logger.error("添加记忆失败: {}", staffId, e);
        }
    }
    
    /**
     * 添加到长期记忆
     */
    public void addLongTermMemory(Long staffId, String content) {
        if (staffId == null) {
            return;
        }
        
        initUserWorkspace(staffId);
        
        Path workspacePath = getUserWorkspacePath(staffId);
        Path memoryFile = workspacePath.resolve("MEMORY.md");
        
        try {
            String existing = "";
            if (Files.exists(memoryFile)) {
                existing = Files.readString(memoryFile);
                if (existing.contains("_此文件存储用户的重要记忆")) {
                    existing = "# 长期记忆\n\n";
                }
            } else {
                existing = "# 长期记忆\n\n";
            }
            
            String newContent = existing + "- " + content + "\n";
            Files.writeString(memoryFile, newContent);
            
            logger.info("长期记忆已添加: staffId={}, content={}", staffId, content);
        } catch (IOException e) {
            logger.error("添加长期记忆失败: {}", staffId, e);
        }
    }
    
    // ========== 私有方法 ==========
    
    private void createTemplateFile(Path dir, String filename, String content) throws IOException {
        Path file = dir.resolve(filename);
        if (!Files.exists(file)) {
            Files.writeString(file, content);
        }
    }
    
    private String readFileContent(Path path) {
        try {
            if (Files.exists(path)) {
                return Files.readString(path);
            }
        } catch (IOException e) {
            logger.error("读取文件失败: {}", path, e);
        }
        return null;
    }
    
    private String buildAgentsContent(Staff staff) {
        return String.format("""
            # 用户工作区配置
            
            ## 用户信息
            - staffId: %d
            - 姓名: %s
            - 权限等级: %d
            - 所属门店: %d
            
            ## 记忆规则
            - 每日记忆: memory/YYYY-MM-DD.md
            - 长期记忆: MEMORY.md
            - 用户说"记住这个"时，写入记忆文件
            """, staff.getStaffId(), staff.getStaffName(), staff.getPermissionLevel(), staff.getStoreId());
    }
    
    private String buildSoulContent() {
        return """
            # 角色设定
            
            你是炊小助，又见炊烟私房菜的AI助理。
            
            ## 核心原则
            - 简短回答，不啰嗦
            - 基于权限范围回答
            - 记住用户交代的事情
            - 保持上下文连贯
            - 错误只说原因，不返回详细信息
            """;
    }
    
    private String buildUserContent(Staff staff) {
        return String.format("""
            # 用户信息
            
            - 姓名: %s
            - 职位: %s
            - 权限: %d
            - 门店: %d
            """, staff.getStaffName(), 
            staff.getStaffPosition() != null ? staff.getStaffPosition() : "员工",
            staff.getPermissionLevel(), staff.getStoreId());
    }
    
    private String buildIdentityContent(Staff staff) {
        return String.format("""
            # 身份
            
            - 名字: 炊小助
            - 角色: AI助理
            - 服务对象: %s
            """, staff.getStaffName());
    }
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    @Query("SELECT c FROM Customer c WHERE c.storeId = :storeId AND c.isActive = 1 AND (c.customerName LIKE %:q% OR c.customerPhone LIKE %:q%)")
    List<Customer> searchByNameOrPhone(@Param("storeId") Long storeId, @Param("q") String q);

    List<Customer> findByStoreId(Long storeId);

    List<Customer> findByStoreIdAndCustomerPhone(Long storeId, String phone);
}

package com.youjian.banquet.repository;

import com.youjian.banquet.entity.BookingTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingTableRepository extends JpaRepository<BookingTable, Long> {
    List<BookingTable> findByStoreIdAndBookingId(Long storeId, String bookingId);
}
